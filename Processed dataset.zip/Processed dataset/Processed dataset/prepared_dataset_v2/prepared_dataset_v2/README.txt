OTİZM ŞİDDET SINIFLANDIRMASI - VERİ SETİ V2
============================================================

VERİ DAĞILIMI:
  Training:       65 örnek (30 Tipik + 30 ASD + 5 Severe)
  Test:           22 örnek (10 Tipik + 10 ASD + 2 Severe)
  External Test:  22 örnek (10 Tipik + 10 ASD + 2 Severe)
  TOPLAM:        109 örnek

ÖZELLİK SAYISI: 463

SINIFLAR:
  0 = Tipik (Normal gelişim, otizm YOK)
  1 = ASD (Otizm spektrum bozukluğu, hafif-orta)
  2 = Severe (Şiddetli otizm)

DOSYALAR:
  • X_train.npy, y_train.npy - Training verisi
  • X_test.npy, y_test.npy - Test verisi
  • X_external.npy, y_external.npy - External test
  • train_data.csv - Training (sütun isimleriyle)
  • test_data.csv - Test (sütun isimleriyle)
  • external_data.csv - External test (sütun isimleriyle)
  • column_names.txt - Sütun isimleri listesi
  • metadata.pkl - Metadata

KULLANIM:
  import numpy as np
  X_train = np.load('X_train.npy')
  y_train = np.load('y_train.npy')

ÖNEMLİ:
  • External test SADECE final değerlendirme için!
  • Severe ASD placeholder veriler (pose estimation gerekli)
  • Class weighting önerilir: {0: 1.0, 1: 1.0, 2: 7.0}
