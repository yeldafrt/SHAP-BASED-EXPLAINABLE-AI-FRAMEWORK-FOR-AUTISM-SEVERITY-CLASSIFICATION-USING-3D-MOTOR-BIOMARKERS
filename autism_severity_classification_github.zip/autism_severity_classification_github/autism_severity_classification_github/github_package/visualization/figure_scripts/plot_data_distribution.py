#!/usr/bin/env python3
"""
Class Distribution & Data Split Visualization (3 panels) - REVIEWER 3 FIXED
Changed "External" → "Held-Out" throughout
(a) Overall Class Distribution
(b) Train/Test/Held-Out Split
(c) Class Balance Analysis
"""

import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Publication settings
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 9

print("Creating Class Distribution & Data Split Visualization (REVIEWER 3 FIXED)...")
print("Changed: 'External' → 'Held-Out'\n")

# Load data
DATA_DIR = Path("prepared_dataset_v2")
FIGURES_DIR = Path("figures")

y_train = np.load(DATA_DIR / "y_train.npy")
y_test = np.load(DATA_DIR / "y_test.npy")
y_external = np.load(DATA_DIR / "y_external.npy")

class_names = ['Typical', 'ASD', 'Severe']
colors = ['#06A77D', '#F77F00', '#D62828']

# ============================================================================
# COMPUTE STATISTICS
# ============================================================================

print("  Computing data statistics...")

# Overall distribution
y_all = np.concatenate([y_train, y_test, y_external])
overall_counts = [np.sum(y_all == i) for i in range(3)]

# Per-split distribution
train_counts = [np.sum(y_train == i) for i in range(3)]
test_counts = [np.sum(y_test == i) for i in range(3)]
heldout_counts = [np.sum(y_external == i) for i in range(3)]  # CHANGED: external_counts → heldout_counts

# ============================================================================
# CREATE FIGURE
# ============================================================================

fig = plt.figure(figsize=(16, 5))
gs = fig.add_gridspec(1, 3, wspace=0.3)

# ============================================================================
# PANEL A: OVERALL CLASS DISTRIBUTION
# ============================================================================

print("  [1/3] Creating overall class distribution...")

ax1 = fig.add_subplot(gs[0, 0])

# Pie chart
wedges, texts, autotexts = ax1.pie(overall_counts, labels=class_names, 
                                     autopct='%1.1f%%', colors=colors,
                                     startangle=90, textprops={'fontsize': 11, 'fontweight': 'bold'},
                                     explode=[0.05, 0.05, 0.1])

# Make percentage text white and bold
for autotext in autotexts:
    autotext.set_color('white')
    autotext.set_fontweight('bold')
    autotext.set_fontsize(12)

ax1.set_title('(a) Overall Class Distribution', fontweight='bold', loc='left', pad=10)

# Add counts in legend
legend_labels = [f'{name}: n={count}' for name, count in zip(class_names, overall_counts)]
ax1.legend(legend_labels, loc='upper left', bbox_to_anchor=(0.85, 1), 
          frameon=True, fancybox=True, shadow=True)

# ============================================================================
# PANEL B: TRAIN/TEST/HELD-OUT SPLIT (CHANGED)
# ============================================================================

print("  [2/3] Creating train/test/held-out split...")

ax2 = fig.add_subplot(gs[0, 1])

splits = ['Train', 'Test', 'Held-Out']  # CHANGED: 'External' → 'Held-Out'
x = np.arange(len(splits))
width = 0.6

# Stacked bar chart
bottom = np.zeros(3)
for i, (class_name, color) in enumerate(zip(class_names, colors)):
    counts = [train_counts[i], test_counts[i], heldout_counts[i]]  # CHANGED: external_counts → heldout_counts
    bars = ax2.bar(x, counts, width, label=class_name, color=color, 
                   bottom=bottom, alpha=0.9, edgecolor='black', linewidth=1)
    
    # Add count labels
    for j, (bar, count) in enumerate(zip(bars, counts)):
        if count > 0:
            height = bar.get_height()
            ax2.text(bar.get_x() + bar.get_width()/2., bottom[j] + height/2,
                    f'{count}', ha='center', va='center', 
                    fontsize=10, fontweight='bold', color='white')
    
    bottom += counts

ax2.set_ylabel('Number of Samples', fontweight='bold')
ax2.set_xticks(x)
ax2.set_xticklabels(splits, fontweight='bold')
ax2.legend(loc='upper right', frameon=True, fancybox=True, shadow=True)
ax2.grid(axis='y', alpha=0.3, linestyle='--')
ax2.set_title('(b) Train/Test/Held-Out Split', fontweight='bold', loc='left', pad=10)  # CHANGED

# Add total counts on top
totals = [sum(train_counts), sum(test_counts), sum(heldout_counts)]  # CHANGED
for i, total in enumerate(totals):
    ax2.text(i, total + 1, f'Total: {total}', ha='center', va='bottom', 
            fontsize=9, fontweight='bold')

# ============================================================================
# PANEL C: CLASS BALANCE ANALYSIS (CHANGED LEGEND)
# ============================================================================

print("  [3/3] Creating class balance analysis...")

ax3 = fig.add_subplot(gs[0, 2])

# Grouped bar chart
x = np.arange(len(class_names))
width = 0.25

train_bars = ax3.bar(x - width, train_counts, width, label='Train', 
                     color='#2E86AB', alpha=0.8, edgecolor='black', linewidth=1)
test_bars = ax3.bar(x, test_counts, width, label='Test', 
                    color='#F77F00', alpha=0.8, edgecolor='black', linewidth=1)
heldout_bars = ax3.bar(x + width, heldout_counts, width, label='Held-Out',  # CHANGED: 'External' → 'Held-Out'
                        color='#06A77D', alpha=0.8, edgecolor='black', linewidth=1)

ax3.set_ylabel('Number of Samples', fontweight='bold')
ax3.set_xlabel('Class', fontweight='bold')
ax3.set_xticks(x)
ax3.set_xticklabels(class_names, fontweight='bold')
ax3.legend(loc='upper right', frameon=True, fancybox=True, shadow=True)
ax3.grid(axis='y', alpha=0.3, linestyle='--')
ax3.set_title('(c) Class Balance Analysis', fontweight='bold', loc='left', pad=10)

# Add count labels on bars
for bars in [train_bars, test_bars, heldout_bars]:  # CHANGED
    for bar in bars:
        height = bar.get_height()
        if height > 0:
            ax3.text(bar.get_x() + bar.get_width()/2., height + 0.5,
                    f'{int(height)}', ha='center', va='bottom', 
                    fontsize=9, fontweight='bold')

# Add imbalance ratio annotation
imbalance_ratio = max(overall_counts) / min(overall_counts)
ax3.text(0.98, 0.98, f'Imbalance Ratio: {imbalance_ratio:.1f}:1', 
        transform=ax3.transAxes, ha='right', va='top',
        bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5),
        fontsize=9, fontweight='bold')

# Save figure
output_path = FIGURES_DIR / 'Data_Distribution_REVIEWER3_FIXED.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight')

# Also save to home directory
home_path = Path("/home/ubuntu") / 'Figure2_Data_Distribution_FIXED.png'
plt.savefig(home_path, dpi=300, bbox_inches='tight')

plt.close()

print(f"\n✅ Figures saved:")
print(f"   1. {output_path}")
print(f"   2. {home_path}")
print(f"   Size: {output_path.stat().st_size / 1024:.1f} KB")
print(f"   Resolution: 300 DPI")
print(f"   Panels: 3 (a, b, c)")

# Print summary
print(f"\n📊 DATA DISTRIBUTION SUMMARY:")
print(f"\nOverall:")
for name, count in zip(class_names, overall_counts):
    percentage = count / sum(overall_counts) * 100
    print(f"   {name:10s}: {count:3d} ({percentage:5.1f}%)")

print(f"\nTrain Set (n={len(y_train)}):")
for name, count in zip(class_names, train_counts):
    print(f"   {name:10s}: {count:3d}")

print(f"\nTest Set (n={len(y_test)}):")
for name, count in zip(class_names, test_counts):
    print(f"   {name:10s}: {count:3d}")

print(f"\nHeld-Out Set (n={len(y_external)}):")  # CHANGED
for name, count in zip(class_names, heldout_counts):  # CHANGED
    print(f"   {name:10s}: {count:3d}")

print(f"\nImbalance Ratio: {imbalance_ratio:.1f}:1")

print(f"\n✅ REVIEWER 3 CHANGES APPLIED:")
print(f"   ✓ Panel (b) title: 'Train/Test/Held-Out Split'")
print(f"   ✓ Panel (b) x-axis label: 'Held-Out' instead of 'External'")
print(f"   ✓ Panel (c) legend: 'Held-Out' instead of 'External'")
print(f"   ✓ All print messages updated")
