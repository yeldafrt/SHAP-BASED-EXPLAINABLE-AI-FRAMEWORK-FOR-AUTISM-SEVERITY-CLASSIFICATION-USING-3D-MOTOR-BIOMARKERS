"""
Kinect V2 Skeleton with SHAP-Identified Motor Biomarkers
Figure for Frontiers Journal Submission - VERSION 2 (CORRECTED)

Based on ACTUAL SHAP analysis results from manuscript:

TYPICAL: WristRight_Y, ElRTFoR_X, KneeRight_Y, HandTipRight_Y, ElLTFoL_X
MODERATE: FoRTKeR_X, KneeRight_Y, FoLTShR_X, ElLTFoL_X, RomMidx_X
SEVERE: ElLTFoL_X, FoRTKeR_X, RomHaRx_X, FoLTShR_X, FoRTThL_X

Key joints: Wrist, Elbow, Foot, Knee, Hand, Shoulder, Thigh

Requirements:
- 300 DPI minimum
- 180 mm width (2 columns)
- Professional appearance
- Panel labels (A), (B) format
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from matplotlib.patches import FancyBboxPatch, Circle, FancyArrowPatch
from matplotlib.lines import Line2D

# Set up figure - 180mm width = 7.09 inches
fig_width = 7.09  # 180mm in inches
fig_height = 5.5  # Height for two panels side by side
fig, axes = plt.subplots(1, 2, figsize=(fig_width, fig_height))

# Kinect V2 25 Joint Points (normalized coordinates for visualization)
joints = {
    # Head and Neck
    'Head': (0.5, 0.95),
    'Neck': (0.5, 0.85),
    
    # Spine
    'SpineShoulder': (0.5, 0.80),
    'SpineMid': (0.5, 0.65),
    'SpineBase': (0.5, 0.50),
    
    # Left Arm
    'ShoulderLeft': (0.35, 0.78),
    'ElbowLeft': (0.25, 0.65),
    'WristLeft': (0.18, 0.52),
    'HandLeft': (0.15, 0.47),
    'HandTipLeft': (0.13, 0.43),
    'ThumbLeft': (0.18, 0.45),
    
    # Right Arm
    'ShoulderRight': (0.65, 0.78),
    'ElbowRight': (0.75, 0.65),
    'WristRight': (0.82, 0.52),
    'HandRight': (0.85, 0.47),
    'HandTipRight': (0.87, 0.43),
    'ThumbRight': (0.82, 0.45),
    
    # Left Leg
    'HipLeft': (0.42, 0.48),
    'KneeLeft': (0.40, 0.30),
    'AnkleLeft': (0.38, 0.12),
    'FootLeft': (0.35, 0.05),
    
    # Right Leg
    'HipRight': (0.58, 0.48),
    'KneeRight': (0.60, 0.30),
    'AnkleRight': (0.62, 0.12),
    'FootRight': (0.65, 0.05),
}

# Bone connections (pairs of joints)
bones = [
    # Spine
    ('Head', 'Neck'), ('Neck', 'SpineShoulder'), ('SpineShoulder', 'SpineMid'), ('SpineMid', 'SpineBase'),
    # Left Arm
    ('SpineShoulder', 'ShoulderLeft'), ('ShoulderLeft', 'ElbowLeft'), ('ElbowLeft', 'WristLeft'),
    ('WristLeft', 'HandLeft'), ('HandLeft', 'HandTipLeft'), ('HandLeft', 'ThumbLeft'),
    # Right Arm
    ('SpineShoulder', 'ShoulderRight'), ('ShoulderRight', 'ElbowRight'), ('ElbowRight', 'WristRight'),
    ('WristRight', 'HandRight'), ('HandRight', 'HandTipRight'), ('HandRight', 'ThumbRight'),
    # Left Leg
    ('SpineBase', 'HipLeft'), ('HipLeft', 'KneeLeft'), ('KneeLeft', 'AnkleLeft'), ('AnkleLeft', 'FootLeft'),
    # Right Leg
    ('SpineBase', 'HipRight'), ('HipRight', 'KneeRight'), ('KneeRight', 'AnkleRight'), ('AnkleRight', 'FootRight'),
]

# SHAP-identified key biomarkers (CORRECTED from manuscript)
# Based on actual SHAP analysis results across all three classes
key_biomarker_joints = {
    # Wrist - WristRight_Y (Typical #1)
    'WristRight': 'Wrist position',
    
    # Elbow - ElRTFoR_X, ElLTFoL_X (All classes)
    'ElbowLeft': 'Elbow-foot distance',
    'ElbowRight': 'Elbow-foot distance',
    
    # Knee - KneeRight_Y, FoRTKeR_X (Typical, Moderate, Severe)
    'KneeRight': 'Knee position/distance',
    
    # Foot - Multiple distance features
    'FootLeft': 'Foot distances',
    'FootRight': 'Foot distances',
    
    # Hand - HandTipRight_Y (Typical), RomHaRx_X (Severe)
    'HandTipRight': 'Hand movement',
    'HandRight': 'Hand ROM',
    
    # Shoulder - FoLTShR_X (Moderate, Severe)
    'ShoulderRight': 'Foot-shoulder distance',
    
    # Hip/Thigh - FoRTThL_X (Severe)
    'HipLeft': 'Foot-thigh distance',
}

# Colors
color_normal = '#4A90A4'  # Blue-gray for normal joints
color_biomarker = '#E74C3C'  # Red for key biomarkers
color_bone = '#7F8C8D'  # Gray for bones

# ============================================================================
# PANEL (A): Full Kinect V2 Skeleton with 25 Joint Points
# ============================================================================
ax1 = axes[0]
ax1.set_xlim(0, 1)
ax1.set_ylim(0, 1)
ax1.set_aspect('equal')
ax1.axis('off')

# Draw bones
for bone in bones:
    j1, j2 = bone
    x1, y1 = joints[j1]
    x2, y2 = joints[j2]
    ax1.plot([x1, x2], [y1, y2], color=color_bone, linewidth=2.5, zorder=1)

# Draw joints with numbers
joint_numbers = {
    'SpineBase': 0, 'SpineMid': 1, 'Neck': 2, 'Head': 3,
    'ShoulderLeft': 4, 'ElbowLeft': 5, 'WristLeft': 6, 'HandLeft': 7,
    'ShoulderRight': 8, 'ElbowRight': 9, 'WristRight': 10, 'HandRight': 11,
    'HipLeft': 12, 'KneeLeft': 13, 'AnkleLeft': 14, 'FootLeft': 15,
    'HipRight': 16, 'KneeRight': 17, 'AnkleRight': 18, 'FootRight': 19,
    'SpineShoulder': 20, 'HandTipLeft': 21, 'ThumbLeft': 22,
    'HandTipRight': 23, 'ThumbRight': 24
}

for joint_name, (x, y) in joints.items():
    circle = Circle((x, y), 0.022, color=color_normal, zorder=2)
    ax1.add_patch(circle)
    # Add joint number
    num = joint_numbers.get(joint_name, '')
    ax1.text(x, y, str(num), fontsize=6, ha='center', va='center', color='white', fontweight='bold', zorder=3)

# Panel title
ax1.set_title('(A) Kinect V2 Skeleton\n(25 Joint Points)', fontsize=11, fontweight='bold', pad=10)

# Legend for Panel A
legend_elements_a = [
    Line2D([0], [0], marker='o', color='w', markerfacecolor=color_normal, markersize=10, label='Joint point (n=25)'),
    Line2D([0], [0], color=color_bone, linewidth=2.5, label='Bone connection'),
]
ax1.legend(handles=legend_elements_a, loc='lower center', fontsize=8, frameon=True, ncol=1, 
           bbox_to_anchor=(0.5, -0.02))

# ============================================================================
# PANEL (B): Skeleton with SHAP-Identified Key Biomarkers Highlighted
# ============================================================================
ax2 = axes[1]
ax2.set_xlim(0, 1)
ax2.set_ylim(0, 1)
ax2.set_aspect('equal')
ax2.axis('off')

# Draw bones (highlight biomarker-related bones)
biomarker_bones = [
    # Elbow-Wrist-Hand segments (upper extremity)
    ('ElbowLeft', 'WristLeft'), ('WristLeft', 'HandLeft'), ('HandLeft', 'HandTipLeft'),
    ('ElbowRight', 'WristRight'), ('WristRight', 'HandRight'), ('HandRight', 'HandTipRight'),
    # Knee-Ankle-Foot segments (lower extremity)
    ('HipRight', 'KneeRight'), ('KneeRight', 'AnkleRight'), ('AnkleRight', 'FootRight'),
    ('HipLeft', 'KneeLeft'), ('KneeLeft', 'AnkleLeft'), ('AnkleLeft', 'FootLeft'),
    # Shoulder segment
    ('SpineShoulder', 'ShoulderRight'),
]

for bone in bones:
    j1, j2 = bone
    x1, y1 = joints[j1]
    x2, y2 = joints[j2]
    if bone in biomarker_bones or (bone[1], bone[0]) in biomarker_bones:
        ax2.plot([x1, x2], [y1, y2], color=color_biomarker, linewidth=3.5, zorder=1, alpha=0.8)
    else:
        ax2.plot([x1, x2], [y1, y2], color=color_bone, linewidth=2, zorder=1, alpha=0.4)

# Draw joints (highlight key biomarkers)
for joint_name, (x, y) in joints.items():
    if joint_name in key_biomarker_joints:
        # Outer red circle
        circle = Circle((x, y), 0.028, color=color_biomarker, zorder=3)
        ax2.add_patch(circle)
        # Inner white circle
        circle_inner = Circle((x, y), 0.018, color='white', zorder=4)
        ax2.add_patch(circle_inner)
    else:
        circle = Circle((x, y), 0.015, color=color_normal, zorder=2, alpha=0.5)
        ax2.add_patch(circle)

# Add annotations for key biomarkers (based on manuscript)
annotations = [
    ('WristRight', 'Wrist position\n(Typical #1)', (0.95, 0.58), 'left'),
    ('KneeRight', 'Knee position\n& foot-knee\ndistance', (0.78, 0.22), 'left'),
    ('FootRight', 'Foot-shoulder,\nfoot-thigh\ndistances', (0.82, 0.05), 'left'),
    ('HandTipRight', 'Hand tip\nposition', (0.98, 0.40), 'left'),
    ('ShoulderRight', 'Foot-shoulder\ndistance', (0.82, 0.78), 'left'),
]

for joint, label, text_pos, ha in annotations:
    jx, jy = joints[joint]
    tx, ty = text_pos
    ax2.annotate(label, xy=(jx, jy), xytext=(tx, ty),
                fontsize=7, ha=ha, va='center',
                bbox=dict(boxstyle='round,pad=0.3', facecolor='#FADBD8', edgecolor=color_biomarker, linewidth=1),
                arrowprops=dict(arrowstyle='->', color=color_biomarker, lw=1.2))

# Draw key inter-joint distance lines (dashed) - ElLTFoL_X (common across ALL classes)
ax2.plot([joints['ElbowLeft'][0], joints['FootLeft'][0]], 
         [joints['ElbowLeft'][1], joints['FootLeft'][1]], 
         color=color_biomarker, linewidth=2.5, linestyle='--', zorder=1, alpha=0.9,
         label='ElLTFoL_X')

# Add annotation for the common biomarker
mid_x = (joints['ElbowLeft'][0] + joints['FootLeft'][0]) / 2 - 0.08
mid_y = (joints['ElbowLeft'][1] + joints['FootLeft'][1]) / 2
ax2.annotate('Elbow-foot\ndistance\n(Common\nbiomarker)', 
             xy=(mid_x + 0.05, mid_y), xytext=(0.02, mid_y),
             fontsize=7, ha='left', va='center',
             bbox=dict(boxstyle='round,pad=0.3', facecolor='#D5F5E3', edgecolor='#27AE60', linewidth=1),
             arrowprops=dict(arrowstyle='->', color='#27AE60', lw=1.2))

# Panel title
ax2.set_title('(B) Key Motor Biomarkers', fontsize=11, fontweight='bold', pad=10)

# Legend for Panel B
legend_elements_b = [
    Line2D([0], [0], marker='o', color='w', markerfacecolor=color_normal, markersize=8, alpha=0.5, label='Standard joint'),
    Line2D([0], [0], marker='o', color='w', markerfacecolor=color_biomarker, markersize=10, label='Key biomarker'),
    Line2D([0], [0], color=color_biomarker, linewidth=3.5, alpha=0.8, label='Biomarker segment'),
    Line2D([0], [0], color=color_biomarker, linewidth=2.5, linestyle='--', label='Inter-joint distance'),
]
ax2.legend(handles=legend_elements_b, loc='lower center', fontsize=7, frameon=True, ncol=2,
           bbox_to_anchor=(0.5, -0.02))

# Adjust layout
plt.tight_layout()

# Save figure - Frontiers requirements: 300 DPI, TIFF or JPEG
output_path_tiff = '/home/ubuntu/Figure_Skeleton_Biomarkers_v3.tiff'
output_path_jpg = '/home/ubuntu/Figure_Skeleton_Biomarkers_v3.jpg'

# Save as TIFF (300 DPI)
plt.savefig(output_path_tiff, dpi=300, format='tiff', bbox_inches='tight', 
            facecolor='white', edgecolor='none')

# Save as JPEG (300 DPI) - backup
plt.savefig(output_path_jpg, dpi=300, format='jpeg', bbox_inches='tight',
            facecolor='white', edgecolor='none')

print(f"✅ Figure saved (VERSION 2 - CORRECTED):")
print(f"   TIFF: {output_path_tiff}")
print(f"   JPEG: {output_path_jpg}")
print(f"\n📐 Specifications:")
print(f"   - Resolution: 300 DPI")
print(f"   - Width: 180 mm (2 columns)")
print(f"   - Format: TIFF and JPEG")
print(f"   - Panels: (A) and (B)")
print(f"\n🔬 SHAP Biomarkers included:")
print(f"   - WristRight (Typical #1)")
print(f"   - ElbowLeft/Right (Elbow-foot distance)")
print(f"   - KneeRight (Position & foot-knee distance)")
print(f"   - FootLeft/Right (Multiple distance features)")
print(f"   - HandTipRight/HandRight (Hand movement & ROM)")
print(f"   - ShoulderRight (Foot-shoulder distance)")
print(f"   - HipLeft (Foot-thigh distance)")
print(f"   - ElLTFoL_X: COMMON biomarker across ALL classes (highlighted in green)")

plt.close()
