#!/usr/bin/env python3.11
"""
SHAP Analysis for Typical (Non-ASD) Class Detection
Creates combined figure with 3 panels: Bar Plot, Summary Plot, Waterfall Plot
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import shap
import pickle
from pathlib import Path

# Paths
DATA_DIR = Path("/home/ubuntu/prepared_dataset_v2")
MODEL_DIR = Path("/home/ubuntu/model_results")
OUTPUT_DIR = Path("/home/ubuntu/figures")
OUTPUT_DIR.mkdir(exist_ok=True)

print("="*80)
print("SHAP ANALYSIS FOR TYPICAL (NON-ASD) CLASS")
print("="*80)

# Load data
print("\n1. Loading data...")
X_external = np.load(DATA_DIR / "X_external.npy", allow_pickle=True)
y_external = np.load(DATA_DIR / "y_external.npy", allow_pickle=True)

# Load feature names
features_df = pd.read_csv(DATA_DIR / "feature_names.csv")
feature_names = features_df['feature_name'].values

print(f"   External set: {X_external.shape}")
print(f"   Feature names: {len(feature_names)}")

# Load model
print("\n2. Loading Random Forest model...")
with open(MODEL_DIR / "RandomForest_model.pkl", "rb") as f:
    rf_model = pickle.load(f)
print(f"   Model loaded: {rf_model}")

# Get Typical samples (label=0)
typical_indices = np.where(y_external == 0)[0]
X_typical = X_external[typical_indices]
print(f"\n3. Typical samples: {len(typical_indices)}")

# Calculate SHAP values
print("\n4. Calculating SHAP values...")
explainer = shap.TreeExplainer(rf_model)
shap_values = explainer.shap_values(X_external)

# For multi-class, shap_values has shape (n_samples, n_features, n_classes)
# We want class 0 (Typical)
if len(shap_values.shape) == 3:
    shap_values_typical = shap_values[:, :, 0]  # Class 0 = Typical
else:
    shap_values_typical = shap_values

print(f"   SHAP values shape: {shap_values_typical.shape}")

# Get SHAP values for Typical samples only
shap_values_typical_samples = shap_values_typical[typical_indices]

# Calculate mean absolute SHAP values
mean_abs_shap = np.abs(shap_values_typical_samples).mean(axis=0)

# Create DataFrame and sort
shap_df = pd.DataFrame({
    'feature': feature_names,
    'mean_abs_shap': mean_abs_shap
}).sort_values('mean_abs_shap', ascending=False)

print(f"\n5. Top 5 features for Typical:")
for i, row in shap_df.head(5).iterrows():
    print(f"   {row['feature']}: {row['mean_abs_shap']:.4f}")

# Save to CSV
csv_path = OUTPUT_DIR / "typical_feature_importance_shap.csv"
shap_df.to_csv(csv_path, index=False)
print(f"\n6. Saved to: {csv_path}")

# Create combined figure
print("\n7. Creating combined SHAP figure...")
fig = plt.figure(figsize=(18, 6))

# Panel (a): Bar Plot - Top 20 Features
ax1 = plt.subplot(1, 3, 1)
top_20 = shap_df.head(20)
colors = plt.cm.RdYlGn_r(np.linspace(0, 1, 20))

bars = ax1.barh(range(20), top_20['mean_abs_shap'].values, color=colors, edgecolor='black', linewidth=0.5)
ax1.set_yticks(range(20))
ax1.set_yticklabels(top_20['feature'].values, fontsize=10)
ax1.set_xlabel('Mean |SHAP value| for Typical Class', fontsize=12, fontweight='bold')
ax1.set_title('(a) Top 20 Feature Importance', fontsize=14, fontweight='bold', loc='left')
ax1.invert_yaxis()
ax1.grid(axis='x', alpha=0.3)

# Add values on bars
for i, (bar, val) in enumerate(zip(bars, top_20['mean_abs_shap'].values)):
    ax1.text(val + 0.0002, i, f'{val:.4f}', va='center', fontsize=9)

# Panel (b): Summary Plot - Top 20 Features
ax2 = plt.subplot(1, 3, 2)
top_20_features = top_20['feature'].values

for i, feat_name in enumerate(top_20_features):
    feat_idx = np.where(feature_names == feat_name)[0][0]
    shap_vals = shap_values_typical_samples[:, feat_idx]
    feat_vals = X_typical[:, feat_idx]
    
    # Normalize feature values for color
    if feat_vals.max() != feat_vals.min():
        feat_vals_norm = (feat_vals - feat_vals.min()) / (feat_vals.max() - feat_vals.min())
    else:
        feat_vals_norm = np.ones_like(feat_vals) * 0.5
    
    colors_scatter = plt.cm.coolwarm(feat_vals_norm)
    ax2.scatter(shap_vals, [i]*len(shap_vals), c=colors_scatter, alpha=0.6, s=50, edgecolors='black', linewidth=0.5)

ax2.set_yticks(range(20))
ax2.set_yticklabels(top_20_features, fontsize=10)
ax2.set_xlabel('SHAP Value (Impact on Typical Prediction)', fontsize=12, fontweight='bold')
ax2.set_title('(b) SHAP Summary Plot', fontsize=14, fontweight='bold', loc='left')
ax2.axvline(x=0, color='gray', linestyle='--', linewidth=1)
ax2.grid(alpha=0.3)

# Add colorbar
sm = plt.cm.ScalarMappable(cmap=plt.cm.coolwarm, norm=plt.Normalize(vmin=0, vmax=1))
sm.set_array([])
cbar = plt.colorbar(sm, ax=ax2, pad=0.02)
cbar.set_label('Feature Value', fontsize=10)
cbar.set_ticks([0, 0.5, 1])
cbar.set_ticklabels(['Low', 'Medium', 'High'])

# Panel (c): Waterfall Plot - Example Typical Case
ax3 = plt.subplot(1, 3, 3)

# Select an example Typical case (first one)
example_idx = typical_indices[0]
example_shap = shap_values_typical[example_idx]
example_features = X_external[example_idx]

# Sort by absolute SHAP value
sorted_indices = np.argsort(np.abs(example_shap))[::-1][:14]  # Top 14
sorted_shap = example_shap[sorted_indices]
sorted_features = example_features[sorted_indices]
sorted_names = [feature_names[i] for i in sorted_indices]

# Calculate cumulative sum
base_value = explainer.expected_value[0] if isinstance(explainer.expected_value, (list, np.ndarray)) else explainer.expected_value
cumsum = np.cumsum(sorted_shap)
final_value = base_value + example_shap.sum()

# Plot waterfall
y_pos = np.arange(len(sorted_shap) + 2)  # +2 for base and others

# Base value
ax3.barh(len(sorted_shap) + 1, base_value, left=0, color='lightgray', edgecolor='black', linewidth=1)
ax3.text(base_value/2, len(sorted_shap) + 1, f'E[f(X)] = {base_value:.3f}', 
         ha='center', va='center', fontsize=10, fontweight='bold')

# Individual features
current_pos = base_value
for i, (shap_val, feat_val, feat_name) in enumerate(zip(sorted_shap, sorted_features, sorted_names)):
    color = '#ff6b6b' if shap_val > 0 else '#4ecdc4'
    ax3.barh(len(sorted_shap) - i, abs(shap_val), left=current_pos if shap_val > 0 else current_pos + shap_val, 
             color=color, edgecolor='black', linewidth=0.5, alpha=0.8)
    ax3.text(current_pos + shap_val/2, len(sorted_shap) - i, f'{shap_val:+.3f}', 
             ha='center', va='center', fontsize=9, fontweight='bold', color='white')
    ax3.text(-0.02, len(sorted_shap) - i, f'{feat_val:.3f} = {feat_name}', 
             ha='right', va='center', fontsize=9)
    current_pos += shap_val

# Other features
other_shap = example_shap.sum() - sorted_shap.sum()
other_count = len(example_shap) - len(sorted_shap)
ax3.barh(0, abs(other_shap), left=current_pos if other_shap > 0 else current_pos + other_shap, 
         color='#ff6b6b' if other_shap > 0 else '#4ecdc4', edgecolor='black', linewidth=0.5, alpha=0.8)
ax3.text(current_pos + other_shap/2, 0, f'{other_shap:+.3f}', 
         ha='center', va='center', fontsize=9, fontweight='bold', color='white')
ax3.text(-0.02, 0, f'{other_count} other features', ha='right', va='center', fontsize=9)

# Final value
ax3.text(final_value + 0.02, len(sorted_shap) + 1, f'f(x) = {final_value:.3f}', 
         ha='left', va='center', fontsize=11, fontweight='bold',
         bbox=dict(boxstyle='round,pad=0.5', facecolor='yellow', alpha=0.7, edgecolor='black', linewidth=2))

ax3.set_yticks([])
ax3.set_xlabel('Model Output (Typical Probability)', fontsize=12, fontweight='bold')
ax3.set_title('(c) SHAP Waterfall Plot (Example Typical Case)', fontsize=14, fontweight='bold', loc='left')
ax3.grid(axis='x', alpha=0.3)
ax3.axvline(x=base_value, color='gray', linestyle='--', linewidth=1, alpha=0.5)

# Legend
from matplotlib.patches import Patch
legend_elements = [
    Patch(facecolor='#ff6b6b', edgecolor='black', label='Positive contribution'),
    Patch(facecolor='#4ecdc4', edgecolor='black', label='Negative contribution')
]
ax3.legend(handles=legend_elements, loc='lower right', fontsize=9)

plt.tight_layout()

# Save figure
output_path = OUTPUT_DIR / "SHAP_Typical_Combined_Analysis.png"
plt.savefig(output_path, dpi=300, bbox_inches='tight')
print(f"\n8. Saved combined figure: {output_path}")

plt.close()

print("\n" + "="*80)
print("SHAP ANALYSIS FOR TYPICAL COMPLETED!")
print("="*80)
print(f"\nOutputs:")
print(f"  - Figure: {output_path}")
print(f"  - CSV: {csv_path}")
print(f"\nTop 5 Typical biomarkers:")
for i, row in shap_df.head(5).iterrows():
    print(f"  {i+1}. {row['feature']}: {row['mean_abs_shap']:.4f}")

