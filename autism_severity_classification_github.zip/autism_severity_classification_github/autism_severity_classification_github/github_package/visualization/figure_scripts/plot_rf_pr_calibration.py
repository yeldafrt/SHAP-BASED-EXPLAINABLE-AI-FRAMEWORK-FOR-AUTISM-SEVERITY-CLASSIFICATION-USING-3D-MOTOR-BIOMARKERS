#!/usr/bin/env python3
"""
Random Forest - Precision-Recall and Calibration Curves
(a) Precision-Recall Curves (One-vs-Rest)
(b) Calibration Curves (Reliability Diagram)
"""

import numpy as np
import matplotlib.pyplot as plt
import pickle
from pathlib import Path
from sklearn.metrics import precision_recall_curve, average_precision_score
from sklearn.calibration import calibration_curve
from sklearn.preprocessing import label_binarize
import warnings
warnings.filterwarnings('ignore')

# Publication settings
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 9

print("Creating Precision-Recall and Calibration Curves...")

# Load data
DATA_DIR = Path("prepared_dataset_v2")
RESULTS_DIR = Path("model_results")
FIGURES_DIR = Path("figures")

X_test = np.load(DATA_DIR / "X_test.npy")
y_test = np.load(DATA_DIR / "y_test.npy")

# Load scaler and model
with open(RESULTS_DIR / "scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

with open(RESULTS_DIR / "RandomForest_model.pkl", "rb") as f:
    rf_model = pickle.load(f)

X_test_scaled = scaler.transform(X_test)
y_prob = rf_model.predict_proba(X_test_scaled)

class_names = ['Typical', 'ASD', 'Severe']
colors = ['#06A77D', '#F77F00', '#D62828']

# Binarize labels
y_test_bin = label_binarize(y_test, classes=[0, 1, 2])

# Create figure
fig = plt.figure(figsize=(14, 6))
gs = fig.add_gridspec(1, 2, wspace=0.3)

# ============================================================================
# PANEL A: PRECISION-RECALL CURVES
# ============================================================================

print("  [1/2] Creating Precision-Recall curves...")

ax1 = fig.add_subplot(gs[0, 0])

# Plot PR curve for each class
for i, (class_name, color) in enumerate(zip(class_names, colors)):
    precision, recall, _ = precision_recall_curve(y_test_bin[:, i], y_prob[:, i])
    avg_precision = average_precision_score(y_test_bin[:, i], y_prob[:, i])
    
    ax1.plot(recall, precision, color=color, linewidth=2.5, 
            label=f'{class_name} (AP = {avg_precision:.3f})')

# Plot baseline (random classifier)
baseline = np.sum(y_test_bin, axis=0) / len(y_test)
for i, (class_name, color) in enumerate(zip(class_names, colors)):
    ax1.axhline(y=baseline[i], color=color, linestyle='--', linewidth=1, alpha=0.3)

ax1.set_xlabel('Recall', fontweight='bold')
ax1.set_ylabel('Precision', fontweight='bold')
ax1.set_xlim([0.0, 1.0])
ax1.set_ylim([0.0, 1.05])
ax1.legend(loc='lower left', frameon=True, fancybox=True, shadow=True)
ax1.grid(alpha=0.3, linestyle='--')
ax1.set_title('(a) Precision-Recall Curves (One-vs-Rest)', 
              fontweight='bold', loc='left', pad=10)

# ============================================================================
# PANEL B: CALIBRATION CURVES
# ============================================================================

print("  [2/2] Creating Calibration curves...")

ax2 = fig.add_subplot(gs[0, 1])

# Plot perfect calibration
ax2.plot([0, 1], [0, 1], 'k--', linewidth=1.5, label='Perfect Calibration')

# Plot calibration curve for each class
for i, (class_name, color) in enumerate(zip(class_names, colors)):
    # Get probabilities for this class
    prob_true, prob_pred = calibration_curve(
        y_test_bin[:, i], y_prob[:, i], 
        n_bins=5, strategy='uniform'
    )
    
    ax2.plot(prob_pred, prob_true, 'o-', color=color, linewidth=2.5, 
            markersize=8, label=f'{class_name}')

ax2.set_xlabel('Mean Predicted Probability', fontweight='bold')
ax2.set_ylabel('Fraction of Positives', fontweight='bold')
ax2.set_xlim([0.0, 1.0])
ax2.set_ylim([0.0, 1.05])
ax2.legend(loc='upper left', frameon=True, fancybox=True, shadow=True)
ax2.grid(alpha=0.3, linestyle='--')
ax2.set_title('(b) Calibration Curves (Reliability Diagram)', 
              fontweight='bold', loc='left', pad=10)

# Save figure
output_path = FIGURES_DIR / 'RandomForest_PR_Calibration.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight')
plt.close()

print(f"\n✅ Figure saved: {output_path}")
print(f"   Size: {output_path.stat().st_size / 1024:.1f} KB")
print(f"   Resolution: 300 DPI")
print(f"   Panels: 2 (a, b)")

# Print Average Precision scores
print(f"\n📊 Average Precision (AP) Scores:")
for i, class_name in enumerate(class_names):
    ap = average_precision_score(y_test_bin[:, i], y_prob[:, i])
    print(f"   {class_name:10s}: {ap:.3f}")

