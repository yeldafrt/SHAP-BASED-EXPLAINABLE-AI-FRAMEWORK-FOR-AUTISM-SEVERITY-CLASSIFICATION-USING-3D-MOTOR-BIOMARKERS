"""
Learning Curve Visualization Script
====================================

Bu script, Random Forest modelinin öğrenme eğrisini oluşturur.

Kullanım:
    python3.11 plot_learning_curve.py

Gereksinimler:
    - RandomForest_model.pkl
    - scaler.pkl
    - prepared_dataset_v2.tar.gz

Çıktı:
    - figures/Learning_Curve_Clean.png (300 DPI)
"""

import pickle
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import learning_curve
import tarfile
import os

# ============================================================================
# AYARLAR
# ============================================================================

# Dosya yolları
MODEL_PATH = 'model_results/RandomForest_model.pkl'
SCALER_PATH = 'model_results/scaler.pkl'
DATASET_PATH = 'prepared_dataset_v2.tar.gz'
OUTPUT_PATH = 'figures/Learning_Curve_Clean.png'

# Grafik ayarları
FIGURE_SIZE = (8, 6)
DPI = 300
TRAIN_COLOR = '#2E86AB'  # Mavi
CV_COLOR = '#A23B72'     # Mor
ALPHA = 0.2              # Gölgeleme şeffaflığı

# Learning curve ayarları
TRAIN_SIZES = np.linspace(0.1, 1.0, 10)  # %10'dan %100'e 10 adımda
CV_FOLDS = 5
RANDOM_STATE = 42

# ============================================================================
# FONKSİYONLAR
# ============================================================================

def load_model_and_scaler():
    """Model ve scaler'ı yükle"""
    print("Loading model and scaler...")
    
    with open(MODEL_PATH, 'rb') as f:
        model = pickle.load(f)
    
    with open(SCALER_PATH, 'rb') as f:
        scaler = pickle.load(f)
    
    print(f"✓ Model loaded: {type(model).__name__}")
    print(f"  - n_estimators: {model.n_estimators}")
    print(f"  - max_depth: {model.max_depth}")
    print(f"  - class_weight: {model.class_weight}")
    
    return model, scaler


def load_dataset():
    """Dataset'i yükle ve scale et"""
    print("\nLoading dataset...")
    
    # Extract tar.gz
    tar = tarfile.open(DATASET_PATH, 'r:gz')
    tar.extractall('/tmp/learning_curve_data')
    tar.close()
    
    # Load training data
    X_train = np.load('/tmp/learning_curve_data/prepared_dataset_v2/X_train.npy')
    y_train = np.load('/tmp/learning_curve_data/prepared_dataset_v2/y_train.npy')
    
    print(f"✓ Dataset loaded")
    print(f"  - Training samples: {len(X_train)}")
    print(f"  - Features: {X_train.shape[1]}")
    print(f"  - Classes: {np.unique(y_train)}")
    
    return X_train, y_train


def calculate_learning_curve(model, X_train_scaled, y_train):
    """Learning curve hesapla"""
    print("\nCalculating learning curve...")
    print(f"  - Train sizes: {TRAIN_SIZES}")
    print(f"  - CV folds: {CV_FOLDS}")
    print(f"  - This may take a few minutes...")
    
    train_sizes_abs, train_scores, cv_scores = learning_curve(
        model, 
        X_train_scaled, 
        y_train,
        train_sizes=TRAIN_SIZES,
        cv=CV_FOLDS,
        n_jobs=-1,
        random_state=RANDOM_STATE,
        shuffle=True
    )
    
    # Calculate mean and std
    train_mean = np.mean(train_scores, axis=1)
    train_std = np.std(train_scores, axis=1)
    cv_mean = np.mean(cv_scores, axis=1)
    cv_std = np.std(cv_scores, axis=1)
    
    print(f"✓ Learning curve calculated")
    print(f"  - Data points: {len(train_sizes_abs)}")
    print(f"  - Train sizes (absolute): {train_sizes_abs}")
    print(f"\nResults:")
    print(f"  - Training accuracy: {train_mean.min():.3f} - {train_mean.max():.3f}")
    print(f"  - CV accuracy: {cv_mean.min():.3f} - {cv_mean.max():.3f}")
    print(f"  - Final gap: {train_mean[-1] - cv_mean[-1]:.3f} ({(train_mean[-1] - cv_mean[-1])*100:.1f}%)")
    
    return train_sizes_abs, train_mean, train_std, cv_mean, cv_std


def plot_learning_curve(train_sizes, train_mean, train_std, cv_mean, cv_std):
    """Learning curve grafiğini oluştur"""
    print("\nCreating plot...")
    
    # Create figure
    fig, ax = plt.subplots(figsize=FIGURE_SIZE, dpi=DPI)
    
    # Plot training score
    ax.plot(train_sizes, train_mean, 'o-', 
            color=TRAIN_COLOR, 
            linewidth=2.5, 
            markersize=8, 
            label='Training Score')
    ax.fill_between(train_sizes, 
                    train_mean - train_std, 
                    train_mean + train_std,
                    alpha=ALPHA, 
                    color=TRAIN_COLOR)
    
    # Plot cross-validation score
    ax.plot(train_sizes, cv_mean, 's-', 
            color=CV_COLOR,
            linewidth=2.5, 
            markersize=8, 
            label='Cross-Validation Score')
    ax.fill_between(train_sizes,
                    cv_mean - cv_std,
                    cv_mean + cv_std,
                    alpha=ALPHA, 
                    color=CV_COLOR)
    
    # Formatting
    ax.set_xlabel('Training Set Size', fontsize=14, fontweight='bold')
    ax.set_ylabel('Accuracy', fontsize=14, fontweight='bold')
    ax.legend(loc='lower right', fontsize=11, frameon=True, shadow=True)
    ax.grid(True, alpha=0.3, linestyle='--')
    ax.set_ylim([0.4, 1.05])
    
    # Tick formatting
    ax.tick_params(labelsize=11)
    
    # Tight layout
    plt.tight_layout()
    
    print(f"✓ Plot created")
    
    return fig


def save_plot(fig, output_path):
    """Grafiği kaydet"""
    print(f"\nSaving plot to {output_path}...")
    
    # Create output directory if not exists
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    # Save
    fig.savefig(output_path, dpi=DPI, bbox_inches='tight', facecolor='white')
    plt.close()
    
    # Get file size
    file_size = os.path.getsize(output_path) / 1024  # KB
    
    print(f"✓ Plot saved successfully")
    print(f"  - File: {output_path}")
    print(f"  - Size: {file_size:.1f} KB")
    print(f"  - DPI: {DPI}")


# ============================================================================
# MAIN
# ============================================================================

def main():
    """Ana fonksiyon"""
    print("=" * 80)
    print("LEARNING CURVE GENERATION")
    print("=" * 80)
    
    # 1. Load model and scaler
    model, scaler = load_model_and_scaler()
    
    # 2. Load dataset
    X_train, y_train = load_dataset()
    
    # 3. Scale data
    print("\nScaling data...")
    X_train_scaled = scaler.transform(X_train)
    print("✓ Data scaled")
    
    # 4. Calculate learning curve
    train_sizes, train_mean, train_std, cv_mean, cv_std = calculate_learning_curve(
        model, X_train_scaled, y_train
    )
    
    # 5. Create plot
    fig = plot_learning_curve(train_sizes, train_mean, train_std, cv_mean, cv_std)
    
    # 6. Save plot
    save_plot(fig, OUTPUT_PATH)
    
    print("\n" + "=" * 80)
    print("COMPLETED SUCCESSFULLY!")
    print("=" * 80)
    
    # Print summary
    print("\nSummary:")
    print(f"  Final Training Accuracy: {train_mean[-1]:.3f} ({train_mean[-1]*100:.1f}%)")
    print(f"  Final CV Accuracy: {cv_mean[-1]:.3f} ({cv_mean[-1]*100:.1f}%)")
    print(f"  Gap: {train_mean[-1] - cv_mean[-1]:.3f} ({(train_mean[-1] - cv_mean[-1])*100:.1f}%)")
    print(f"\n  Interpretation:")
    if train_mean[-1] - cv_mean[-1] < 0.05:
        print("  ✓ Excellent! Very low overfitting.")
    elif train_mean[-1] - cv_mean[-1] < 0.15:
        print("  ✓ Good! Acceptable overfitting for small dataset.")
    elif train_mean[-1] - cv_mean[-1] < 0.25:
        print("  ⚠ Moderate overfitting. Consider regularization.")
    else:
        print("  ✗ Severe overfitting! Model needs improvement.")


if __name__ == '__main__':
    main()

