#!/usr/bin/env python3
"""
Misclassification Analysis (3 panels)
(a) Confusion Matrix with Error Highlighting
(b) Prediction Confidence Distribution (Correct vs Incorrect)
(c) Misclassification Patterns
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pickle
from pathlib import Path
from sklearn.metrics import confusion_matrix
import warnings
warnings.filterwarnings('ignore')

# Publication settings
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 9

print("Creating Misclassification Analysis...")

# Load data
DATA_DIR = Path("prepared_dataset_v2")
RESULTS_DIR = Path("model_results")
FIGURES_DIR = Path("figures")

X_test = np.load(DATA_DIR / "X_test.npy")
y_test = np.load(DATA_DIR / "y_test.npy")

# Load scaler and model
with open(RESULTS_DIR / "scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

with open(RESULTS_DIR / "RandomForest_model.pkl", "rb") as f:
    rf_model = pickle.load(f)

X_test_scaled = scaler.transform(X_test)
y_pred = rf_model.predict(X_test_scaled)
y_prob = rf_model.predict_proba(X_test_scaled)

class_names = ['Typical', 'ASD', 'Severe']
colors = ['#06A77D', '#F77F00', '#D62828']

# ============================================================================
# COMPUTE STATISTICS
# ============================================================================

print("  Computing misclassification statistics...")

# Confusion matrix
cm = confusion_matrix(y_test, y_pred)

# Correct and incorrect predictions
correct_mask = (y_test == y_pred)
incorrect_mask = ~correct_mask

# Prediction confidences
pred_confidences = np.max(y_prob, axis=1)
correct_confidences = pred_confidences[correct_mask]
incorrect_confidences = pred_confidences[incorrect_mask]

# Misclassification pairs
misclass_pairs = []
for i in range(len(y_test)):
    if not correct_mask[i]:
        misclass_pairs.append((y_test[i], y_pred[i]))

# ============================================================================
# CREATE FIGURE
# ============================================================================

fig = plt.figure(figsize=(16, 5))
gs = fig.add_gridspec(1, 3, wspace=0.3)

# ============================================================================
# PANEL A: CONFUSION MATRIX WITH ERROR HIGHLIGHTING
# ============================================================================

print("  [1/3] Creating confusion matrix with error highlighting...")

ax1 = fig.add_subplot(gs[0, 0])

# Create custom colormap for errors
cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]

# Plot heatmap
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=True,
            xticklabels=class_names, yticklabels=class_names, 
            ax=ax1, annot_kws={'fontsize': 12, 'fontweight': 'bold'},
            cbar_kws={'label': 'Count'})

# Highlight errors (off-diagonal) with red borders
for i in range(3):
    for j in range(3):
        if i != j and cm[i, j] > 0:
            ax1.add_patch(plt.Rectangle((j, i), 1, 1, fill=False, 
                                       edgecolor='red', lw=3))

ax1.set_ylabel('True Label', fontweight='bold')
ax1.set_xlabel('Predicted Label', fontweight='bold')
ax1.set_title('(a) Confusion Matrix (Errors Highlighted)', 
              fontweight='bold', loc='left', pad=10)

# Add accuracy
accuracy = np.trace(cm) / np.sum(cm)
ax1.text(0.5, -0.15, f'Accuracy: {accuracy:.1%} | Errors: {np.sum(~correct_mask)}/{len(y_test)}', 
         ha='center', va='top', transform=ax1.transAxes,
         fontsize=10, fontweight='bold',
         bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

# ============================================================================
# PANEL B: PREDICTION CONFIDENCE DISTRIBUTION
# ============================================================================

print("  [2/3] Creating prediction confidence distribution...")

ax2 = fig.add_subplot(gs[0, 1])

# Histogram
bins = np.linspace(0, 1, 21)
ax2.hist(correct_confidences, bins=bins, alpha=0.7, color='#06A77D', 
        label=f'Correct (n={len(correct_confidences)})', edgecolor='black', linewidth=1)
ax2.hist(incorrect_confidences, bins=bins, alpha=0.7, color='#D62828', 
        label=f'Incorrect (n={len(incorrect_confidences)})', edgecolor='black', linewidth=1)

ax2.set_xlabel('Prediction Confidence', fontweight='bold')
ax2.set_ylabel('Frequency', fontweight='bold')
ax2.legend(loc='upper left', frameon=True, fancybox=True, shadow=True)
ax2.grid(axis='y', alpha=0.3, linestyle='--')
ax2.set_title('(b) Prediction Confidence Distribution', 
              fontweight='bold', loc='left', pad=10)

# Add mean confidence lines
if len(correct_confidences) > 0:
    mean_correct = np.mean(correct_confidences)
    ax2.axvline(mean_correct, color='#06A77D', linestyle='--', linewidth=2,
               label=f'Mean Correct: {mean_correct:.3f}')
if len(incorrect_confidences) > 0:
    mean_incorrect = np.mean(incorrect_confidences)
    ax2.axvline(mean_incorrect, color='#D62828', linestyle='--', linewidth=2,
               label=f'Mean Incorrect: {mean_incorrect:.3f}')

ax2.legend(loc='upper left', frameon=True, fancybox=True, shadow=True)

# ============================================================================
# PANEL C: MISCLASSIFICATION PATTERNS
# ============================================================================

print("  [3/3] Creating misclassification patterns...")

ax3 = fig.add_subplot(gs[0, 2])

# Count misclassification pairs
misclass_matrix = np.zeros((3, 3))
for true_label, pred_label in misclass_pairs:
    misclass_matrix[true_label, pred_label] += 1

# Only show off-diagonal (errors)
error_matrix = misclass_matrix.copy()
np.fill_diagonal(error_matrix, 0)

# Create flow diagram
y_positions = [2, 1, 0]  # Reverse for better visualization
bar_height = 0.6

# Plot bars for each true class
for i, (true_class, y_pos) in enumerate(zip(class_names, y_positions)):
    # True class bar (left)
    true_count = np.sum(y_test == i)
    ax3.barh(y_pos, true_count, bar_height, left=0, 
            color=colors[i], alpha=0.3, edgecolor='black', linewidth=2,
            label=f'{true_class} (n={true_count})')
    
    # Correct predictions (middle)
    correct_count = cm[i, i]
    ax3.barh(y_pos, correct_count, bar_height * 0.8, left=true_count + 0.5, 
            color=colors[i], alpha=0.9, edgecolor='green', linewidth=2)
    
    # Add text
    ax3.text(true_count/2, y_pos, f'{true_count}', 
            ha='center', va='center', fontsize=10, fontweight='bold')
    ax3.text(true_count + 0.5 + correct_count/2, y_pos, f'{correct_count} ✓', 
            ha='center', va='center', fontsize=9, fontweight='bold', color='white')

# Draw error arrows
for i in range(3):
    for j in range(3):
        if i != j and error_matrix[i, j] > 0:
            # Arrow from true class to predicted class
            y_start = y_positions[i]
            y_end = y_positions[j]
            x_start = np.sum(y_test == i) + 0.5 + cm[i, i]
            x_end = x_start + 2
            
            ax3.annotate('', xy=(x_end, y_end), xytext=(x_start, y_start),
                        arrowprops=dict(arrowstyle='->', lw=2, color='red', alpha=0.7))
            ax3.text((x_start + x_end)/2, (y_start + y_end)/2, 
                    f'{int(error_matrix[i, j])} ✗',
                    ha='center', va='center', fontsize=9, fontweight='bold',
                    bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))

ax3.set_yticks(y_positions)
ax3.set_yticklabels(class_names, fontweight='bold')
ax3.set_xlabel('Sample Flow', fontweight='bold')
ax3.set_xlim([0, max(np.sum(y_test == i) for i in range(3)) + 10])
ax3.grid(axis='x', alpha=0.3, linestyle='--')
ax3.set_title('(c) Misclassification Patterns', 
              fontweight='bold', loc='left', pad=10)

# Add legend
ax3.text(0.98, 0.02, 'Left: True samples\nMiddle: Correct predictions\nArrows: Misclassifications', 
        transform=ax3.transAxes, ha='right', va='bottom',
        bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5),
        fontsize=8)

# Save figure
output_path = FIGURES_DIR / 'Misclassification_Analysis.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight')
plt.close()

print(f"\n✅ Figure saved: {output_path}")
print(f"   Size: {output_path.stat().st_size / 1024:.1f} KB")
print(f"   Resolution: 300 DPI")
print(f"   Panels: 3 (a, b, c)")

# Print summary
print(f"\n📊 MISCLASSIFICATION SUMMARY:")
print(f"\nTotal predictions: {len(y_test)}")
print(f"Correct: {np.sum(correct_mask)} ({np.sum(correct_mask)/len(y_test)*100:.1f}%)")
print(f"Incorrect: {np.sum(incorrect_mask)} ({np.sum(incorrect_mask)/len(y_test)*100:.1f}%)")

if len(correct_confidences) > 0:
    print(f"\nCorrect predictions confidence: {np.mean(correct_confidences):.3f} ± {np.std(correct_confidences):.3f}")
if len(incorrect_confidences) > 0:
    print(f"Incorrect predictions confidence: {np.mean(incorrect_confidences):.3f} ± {np.std(incorrect_confidences):.3f}")

print(f"\nMisclassification pairs:")
for true_label, pred_label in set(misclass_pairs):
    count = misclass_pairs.count((true_label, pred_label))
    print(f"   {class_names[true_label]} → {class_names[pred_label]}: {count}")

