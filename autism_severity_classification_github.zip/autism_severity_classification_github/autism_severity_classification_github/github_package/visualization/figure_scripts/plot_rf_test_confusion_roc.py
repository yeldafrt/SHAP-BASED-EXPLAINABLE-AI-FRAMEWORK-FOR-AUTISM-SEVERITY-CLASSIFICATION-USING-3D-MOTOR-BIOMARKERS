#!/usr/bin/env python3
"""
Random Forest - Confusion Matrix and ROC Curves (TEST SET)
(a) Confusion Matrix (Test Set)
(b) ROC Curves (One-vs-Rest, Test Set)
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pickle
from pathlib import Path
from sklearn.metrics import confusion_matrix, roc_curve, auc
from sklearn.preprocessing import label_binarize
import warnings
warnings.filterwarnings('ignore')

# Publication settings
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 9

print("Creating Random Forest Confusion Matrix and ROC Curves (Test Set)...")

# Load data
DATA_DIR = Path("prepared_dataset_v2")
RESULTS_DIR = Path("model_results")
FIGURES_DIR = Path("figures")

X_test = np.load(DATA_DIR / "X_test.npy")
y_test = np.load(DATA_DIR / "y_test.npy")

# Load scaler and model
with open(RESULTS_DIR / "scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

with open(RESULTS_DIR / "RandomForest_model.pkl", "rb") as f:
    rf_model = pickle.load(f)

X_test_scaled = scaler.transform(X_test)

# Get predictions
y_pred = rf_model.predict(X_test_scaled)
y_prob = rf_model.predict_proba(X_test_scaled)

class_names = ['Typical', 'ASD', 'Severe']

# Create figure
fig = plt.figure(figsize=(14, 6))
gs = fig.add_gridspec(1, 2, wspace=0.3)

# ============================================================================
# PANEL A: CONFUSION MATRIX
# ============================================================================

print("  [1/2] Creating confusion matrix...")

ax1 = fig.add_subplot(gs[0, 0])

# Compute confusion matrix
cm = confusion_matrix(y_test, y_pred)

# Plot with seaborn
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=True,
            xticklabels=class_names, yticklabels=class_names, 
            ax=ax1, annot_kws={'fontsize': 12, 'fontweight': 'bold'},
            cbar_kws={'label': 'Count'})

ax1.set_ylabel('True Label', fontweight='bold')
ax1.set_xlabel('Predicted Label', fontweight='bold')
ax1.set_title('(a) Confusion Matrix (Test Set)', 
              fontweight='bold', loc='left', pad=10)

# Add accuracy text
accuracy = np.trace(cm) / np.sum(cm)
ax1.text(0.5, -0.15, f'Overall Accuracy: {accuracy:.1%}', 
         ha='center', va='top', transform=ax1.transAxes,
         fontsize=10, fontweight='bold')

# ============================================================================
# PANEL B: ROC CURVES
# ============================================================================

print("  [2/2] Creating ROC curves...")

ax2 = fig.add_subplot(gs[0, 1])

# Binarize labels for One-vs-Rest
y_test_bin = label_binarize(y_test, classes=[0, 1, 2])

# Colors for each class
colors = ['#06A77D', '#F77F00', '#D62828']

# Plot ROC curve for each class
for i, (class_name, color) in enumerate(zip(class_names, colors)):
    fpr, tpr, _ = roc_curve(y_test_bin[:, i], y_prob[:, i])
    roc_auc = auc(fpr, tpr)
    
    ax2.plot(fpr, tpr, color=color, linewidth=2.5, 
            label=f'{class_name} (AUC = {roc_auc:.3f})')

# Plot diagonal (chance)
ax2.plot([0, 1], [0, 1], 'k--', linewidth=1.5, label='Chance (AUC = 0.500)')

ax2.set_xlabel('False Positive Rate', fontweight='bold')
ax2.set_ylabel('True Positive Rate', fontweight='bold')
ax2.set_xlim([0.0, 1.0])
ax2.set_ylim([0.0, 1.05])
ax2.legend(loc='lower right', frameon=True, fancybox=True, shadow=True)
ax2.grid(alpha=0.3, linestyle='--')
ax2.set_title('(b) ROC Curves (One-vs-Rest, Test Set)', 
              fontweight='bold', loc='left', pad=10)

# Save figure
output_path = FIGURES_DIR / 'RandomForest_Test_ConfusionMatrix_ROC.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight')
plt.close()

print(f"\n✅ Figure saved: {output_path}")
print(f"   Size: {output_path.stat().st_size / 1024:.1f} KB")
print(f"   Resolution: 300 DPI")
print(f"   Panels: 2 (a, b)")

# Print metrics
print(f"\n📊 Confusion Matrix (Test Set):")
print(cm)
print(f"\n🎯 Overall Accuracy: {accuracy:.1%}")

# Print per-class results
print(f"\n📋 Per-Class Results:")
for i, class_name in enumerate(class_names):
    true_positives = cm[i, i]
    false_negatives = np.sum(cm[i, :]) - true_positives
    false_positives = np.sum(cm[:, i]) - true_positives
    true_negatives = np.sum(cm) - true_positives - false_negatives - false_positives
    
    precision = true_positives / (true_positives + false_positives) if (true_positives + false_positives) > 0 else 0
    recall = true_positives / (true_positives + false_negatives) if (true_positives + false_negatives) > 0 else 0
    
    print(f"   {class_name:10s}: Precision={precision:.3f}, Recall={recall:.3f}")

# Print AUC scores
print(f"\n📈 AUC Scores (Test Set):")
for i, class_name in enumerate(class_names):
    fpr, tpr, _ = roc_curve(y_test_bin[:, i], y_prob[:, i])
    roc_auc = auc(fpr, tpr)
    print(f"   {class_name:10s}: {roc_auc:.3f}")

