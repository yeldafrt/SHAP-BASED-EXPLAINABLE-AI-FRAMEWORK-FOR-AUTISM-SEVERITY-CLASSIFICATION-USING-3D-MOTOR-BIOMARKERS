#!/usr/bin/env python3
"""
SHAP Analysis for Severe ASD Class
Version 2: Matching Typical Development and Moderate ASD visualization style exactly
- Uses RandomForest_model.pkl (same as Typical and Moderate)
- Uses X_external dataset (same as Typical and Moderate)
- Uses column_names.txt for feature names (same as Typical and Moderate)
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import shap
import pickle
from pathlib import Path
from matplotlib.patches import Patch

# Set up paths
MODEL_PATH = "/home/ubuntu/upload/github_extract/autism_severity_classification_github/autism_severity_classification_github/github_package/models/trained_models/RandomForest_model.pkl"
SCALER_PATH = "/home/ubuntu/upload/github_extract/autism_severity_classification_github/autism_severity_classification_github/github_package/models/trained_models/scaler.pkl"
DATA_DIR = "/home/ubuntu/upload/dataset_extract/islenmis_dataset/prepared_dataset_v2"
OUTPUT_DIR = Path("/home/ubuntu/figures")

# Create output directory
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

print("="*80)
print("SHAP ANALYSIS FOR SEVERE ASD CLASS")
print("="*80)

print("\n1. Loading model and data...")
# Load model
with open(MODEL_PATH, 'rb') as f:
    model = pickle.load(f)

# Load scaler
with open(SCALER_PATH, 'rb') as f:
    scaler = pickle.load(f)

# Load external test data
X_external = np.load(f"{DATA_DIR}/X_external.npy")
y_external = np.load(f"{DATA_DIR}/y_external.npy")

# Load feature names
with open(f"{DATA_DIR}/column_names.txt", 'r') as f:
    feature_names = np.array([line.strip() for line in f.readlines()])

print(f"   - Loaded {len(feature_names)} feature names")
print(f"   - X_external shape: {X_external.shape}")
print(f"   - y_external shape: {y_external.shape}")

# Filter for Severe ASD class (class 2)
severe_indices = np.where(y_external == 2)[0]
X_severe = X_external[severe_indices]
y_severe = y_external[severe_indices]

print(f"\n2. Filtered Severe ASD samples: {len(severe_indices)}")

# Create SHAP explainer
print("\n3. Creating SHAP explainer...")
explainer = shap.TreeExplainer(model)

# Calculate SHAP values for all external test samples
print("\n4. Calculating SHAP values for all external samples...")
shap_values_all = explainer.shap_values(X_external)

# Extract SHAP values for Severe ASD class (class 2)
if len(shap_values_all.shape) == 3:
    shap_values_severe_class = shap_values_all[:, :, 2]  # All samples, all features, class 2
else:
    # If it's a list
    if isinstance(shap_values_all, list):
        shap_values_severe_class = shap_values_all[2]
    else:
        shap_values_severe_class = shap_values_all

# Get SHAP values for Severe ASD samples only
shap_values_severe_samples = shap_values_severe_class[severe_indices]

print(f"   - SHAP values shape (all samples, class 2): {shap_values_severe_class.shape}")
print(f"   - SHAP values shape (Severe samples only): {shap_values_severe_samples.shape}")

# Calculate mean absolute SHAP values
print("\n5. Calculating feature importance...")
mean_abs_shap = np.abs(shap_values_severe_samples).mean(axis=0)

# Create DataFrame
shap_df = pd.DataFrame({
    'feature': feature_names,
    'mean_abs_shap': mean_abs_shap
}).sort_values('mean_abs_shap', ascending=False).reset_index(drop=True)

# Save to CSV
csv_path = OUTPUT_DIR / "severe_asd_feature_importance_shap.csv"
shap_df.to_csv(csv_path, index=False)
print(f"   - Saved CSV: {csv_path}")

print("\n6. Top 10 features for Severe ASD:")
for i, row in shap_df.head(10).iterrows():
    print(f"   {i+1}. {row['feature']}: {row['mean_abs_shap']:.6f}")

# Create combined figure
print("\n7. Creating combined SHAP figure...")
fig = plt.figure(figsize=(18, 6))

# Panel (a): Bar Plot - Top 20 Features
ax1 = plt.subplot(1, 3, 1)
top_20 = shap_df.head(20)
colors = plt.cm.RdYlGn_r(np.linspace(0, 1, 20))

bars = ax1.barh(range(20), top_20['mean_abs_shap'].values, color=colors, edgecolor='black', linewidth=0.5)
ax1.set_yticks(range(20))
ax1.set_yticklabels(top_20['feature'].values, fontsize=10)
ax1.set_xlabel('Mean |SHAP value| for Severe ASD Class', fontsize=12, fontweight='bold')
ax1.set_title('(a) Top 20 Feature Importance', fontsize=14, fontweight='bold', loc='left')
ax1.invert_yaxis()
ax1.grid(axis='x', alpha=0.3)

# Add values on bars
for i, (bar, val) in enumerate(zip(bars, top_20['mean_abs_shap'].values)):
    ax1.text(val + 0.0002, i, f'{val:.4f}', va='center', fontsize=9)

# Panel (b): Summary Plot - Top 20 Features
ax2 = plt.subplot(1, 3, 2)
top_20_features = top_20['feature'].values

for i, feat_name in enumerate(top_20_features):
    feat_idx = np.where(feature_names == feat_name)[0][0]
    shap_vals = shap_values_severe_samples[:, feat_idx]
    feat_vals = X_severe[:, feat_idx]
    
    # Normalize feature values for color
    if feat_vals.max() != feat_vals.min():
        feat_vals_norm = (feat_vals - feat_vals.min()) / (feat_vals.max() - feat_vals.min())
    else:
        feat_vals_norm = np.ones_like(feat_vals) * 0.5
    
    colors_scatter = plt.cm.coolwarm(feat_vals_norm)
    ax2.scatter(shap_vals, [i]*len(shap_vals), c=colors_scatter, alpha=0.6, s=50, edgecolors='black', linewidth=0.5)

ax2.set_yticks(range(20))
ax2.set_yticklabels(top_20_features, fontsize=10)
ax2.set_xlabel('SHAP Value (Impact on Severe ASD Prediction)', fontsize=12, fontweight='bold')
ax2.set_title('(b) SHAP Summary Plot', fontsize=14, fontweight='bold', loc='left')
ax2.axvline(x=0, color='gray', linestyle='--', linewidth=1)
ax2.grid(alpha=0.3)

# Add colorbar
sm = plt.cm.ScalarMappable(cmap=plt.cm.coolwarm, norm=plt.Normalize(vmin=0, vmax=1))
sm.set_array([])
cbar = plt.colorbar(sm, ax=ax2, pad=0.02)
cbar.set_label('Feature Value', fontsize=10)
cbar.set_ticks([0, 0.5, 1])
cbar.set_ticklabels(['Low', 'Medium', 'High'])

# Panel (c): Waterfall Plot - Example Severe ASD Case
ax3 = plt.subplot(1, 3, 3)

# Select an example Severe ASD case (first one)
example_idx = severe_indices[0]
example_shap = shap_values_severe_class[example_idx]
example_features = X_external[example_idx]

# Sort by absolute SHAP value
sorted_indices = np.argsort(np.abs(example_shap))[::-1][:14]  # Top 14
sorted_shap = example_shap[sorted_indices]
sorted_features = example_features[sorted_indices]
sorted_names = [feature_names[i] for i in sorted_indices]

# Calculate cumulative sum
base_value = explainer.expected_value[2] if isinstance(explainer.expected_value, (list, np.ndarray)) else explainer.expected_value
cumsum = np.cumsum(sorted_shap)
final_value = base_value + example_shap.sum()

# Plot waterfall
y_pos = np.arange(len(sorted_shap) + 2)  # +2 for base and others

# Base value
ax3.barh(len(sorted_shap) + 1, base_value, left=0, color='lightgray', edgecolor='black', linewidth=1)
ax3.text(base_value/2, len(sorted_shap) + 1, f'E[f(X)] = {base_value:.3f}', 
         ha='center', va='center', fontsize=10, fontweight='bold')

# Individual features
current_pos = base_value
for i, (shap_val, feat_val, feat_name) in enumerate(zip(sorted_shap, sorted_features, sorted_names)):
    color = '#ff6b6b' if shap_val > 0 else '#4ecdc4'
    ax3.barh(len(sorted_shap) - i, abs(shap_val), left=current_pos if shap_val > 0 else current_pos + shap_val, 
             color=color, edgecolor='black', linewidth=0.5, alpha=0.8)
    ax3.text(current_pos + shap_val/2, len(sorted_shap) - i, f'{shap_val:+.3f}', 
             ha='center', va='center', fontsize=9, fontweight='bold', color='white')
    ax3.text(-0.02, len(sorted_shap) - i, f'{feat_val:.3f} = {feat_name}', 
             ha='right', va='center', fontsize=9)
    current_pos += shap_val

# Other features
other_shap = example_shap.sum() - sorted_shap.sum()
other_count = len(example_shap) - len(sorted_shap)
ax3.barh(0, abs(other_shap), left=current_pos if other_shap > 0 else current_pos + other_shap, 
         color='#ff6b6b' if other_shap > 0 else '#4ecdc4', edgecolor='black', linewidth=0.5, alpha=0.8)
ax3.text(current_pos + other_shap/2, 0, f'{other_shap:+.3f}', 
         ha='center', va='center', fontsize=9, fontweight='bold', color='white')
ax3.text(-0.02, 0, f'{other_count} other features', ha='right', va='center', fontsize=9)

# Final value
ax3.text(final_value + 0.02, len(sorted_shap) + 1, f'f(x) = {final_value:.3f}', 
         ha='left', va='center', fontsize=11, fontweight='bold',
         bbox=dict(boxstyle='round,pad=0.5', facecolor='yellow', alpha=0.7, edgecolor='black', linewidth=2))

ax3.set_yticks([])
ax3.set_xlabel('Model Output (Severe ASD Probability)', fontsize=12, fontweight='bold')
ax3.set_title('(c) SHAP Waterfall Plot (Example Severe ASD Case)', fontsize=14, fontweight='bold', loc='left')
ax3.grid(axis='x', alpha=0.3)
ax3.axvline(x=base_value, color='gray', linestyle='--', linewidth=1, alpha=0.5)

# Legend
legend_elements = [
    Patch(facecolor='#ff6b6b', edgecolor='black', label='Positive contribution'),
    Patch(facecolor='#4ecdc4', edgecolor='black', label='Negative contribution')
]
ax3.legend(handles=legend_elements, loc='lower right', fontsize=9)

plt.tight_layout()

# Save figure
output_path = OUTPUT_DIR / "SHAP_Severe_ASD_Combined_Analysis.png"
plt.savefig(output_path, dpi=300, bbox_inches='tight')
print(f"\n8. Saved combined figure: {output_path}")

plt.close()

print("\n" + "="*80)
print("SHAP ANALYSIS FOR SEVERE ASD COMPLETED!")
print("="*80)
print(f"\nOutputs:")
print(f"  - Figure: {output_path}")
print(f"  - CSV: {csv_path}")
print(f"\nTop 5 Severe ASD biomarkers:")
for i, row in shap_df.head(5).iterrows():
    print(f"  {i+1}. {row['feature']}: {row['mean_abs_shap']:.4f}")

print("\n✓ Analysis complete!")

