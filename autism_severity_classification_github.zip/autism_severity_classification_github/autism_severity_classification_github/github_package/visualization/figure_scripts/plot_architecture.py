#!/usr/bin/env python3
"""
Model Architecture - Ultra Clean and Simple Design
CORRECTED VERSION - All values match actual implementation
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from pathlib import Path

print("Creating Ultra Clean Architecture Diagram (CORRECTED)...")

FIGURES_DIR = Path("figures")

# Create figure
fig = plt.figure(figsize=(10, 12), dpi=300)
ax = fig.add_subplot(111)
ax.set_xlim(0, 10)
ax.set_ylim(0, 12)
ax.axis('off')

# Define precise positions
box_width = 5
box_x = 2.5  # Center at 5
arrow_x = 5

# Colors
c1 = '#E3F2FD'  # Blue
c2 = '#FFF3E0'  # Orange
c3 = '#E8F5E9'  # Green
c4 = '#F3E5F5'  # Purple

# ============================================================================
# BOX 1: INPUT
# ============================================================================
y1 = 10.5
h1 = 0.8

rect1 = mpatches.Rectangle((box_x, y1), box_width, h1, 
                           facecolor=c1, edgecolor='black', linewidth=2)
ax.add_patch(rect1)

ax.text(5, y1 + h1/2 + 0.15, 'INPUT DATA', ha='center', va='center',
        fontsize=12, fontweight='bold')
ax.text(5, y1 + h1/2 - 0.15, '463 Features (Kinect 3D Skeleton)', ha='center', va='center',
        fontsize=9)

# Arrow 1
ax.annotate('', xy=(arrow_x, y1), xytext=(arrow_x, y1 - 0.6),
            arrowprops=dict(arrowstyle='->', lw=2.5, color='black'))

# ============================================================================
# BOX 2: PREPROCESSING
# ============================================================================
y2 = y1 - 0.6 - 0.8
h2 = 0.8

rect2 = mpatches.Rectangle((box_x, y2), box_width, h2, 
                           facecolor=c2, edgecolor='black', linewidth=2)
ax.add_patch(rect2)

ax.text(5, y2 + h2/2 + 0.15, 'PREPROCESSING', ha='center', va='center',
        fontsize=12, fontweight='bold')
ax.text(5, y2 + h2/2 - 0.15, 'StandardScaler (μ=0, σ=1)', ha='center', va='center',
        fontsize=9)

# Arrow 2
ax.annotate('', xy=(arrow_x, y2), xytext=(arrow_x, y2 - 0.6),
            arrowprops=dict(arrowstyle='->', lw=2.5, color='black'))

# ============================================================================
# BOX 3: RANDOM FOREST
# ============================================================================
y3 = y2 - 0.6 - 3.2
h3 = 3.2

rect3 = mpatches.Rectangle((box_x, y3), box_width, h3, 
                           facecolor=c3, edgecolor='black', linewidth=2.5)
ax.add_patch(rect3)

# Title
ax.text(5, y3 + h3 - 0.25, 'RANDOM FOREST CLASSIFIER', ha='center', va='center',
        fontsize=13, fontweight='bold')

# Hyperparameters box
hyper_y = y3 + h3 - 0.7
hyper_h = 0.9
hyper_box = mpatches.Rectangle((box_x + 0.2, hyper_y - hyper_h), box_width - 0.4, hyper_h,
                               facecolor='white', edgecolor='#2E7D32', 
                               linewidth=1.5, linestyle='--')
ax.add_patch(hyper_box)

ax.text(5, hyper_y - 0.15, 'Hyperparameters', ha='center', va='center',
        fontsize=10, fontweight='bold', color='#2E7D32')

# Parameters - Left column
lx = box_x + 0.5
py = hyper_y - 0.35
ax.text(lx, py, '• n_estimators = 200', fontsize=8)
ax.text(lx, py - 0.2, '• max_depth = 15', fontsize=8)
ax.text(lx, py - 0.4, '• min_samples_split = 10', fontsize=8)

# Parameters - Right column
# ⚠️ CORRECTED: class_weight values from actual implementation
rx = 5.3
ax.text(rx, py, '• min_samples_leaf = 4', fontsize=8)
ax.text(rx, py - 0.2, '• class_weight = {0:0.72, 1:0.72, 2:4.33}', fontsize=8)
ax.text(rx, py - 0.4, '• random_state = 42', fontsize=8)

# Trees
tree_y = y3 + 1.2
ax.text(5, tree_y + 0.3, '200 Decision Trees', ha='center', va='center',
        fontsize=10, fontweight='bold', style='italic')

# Draw simple trees
for tx in [3, 3.8, 4.6, 5.4, 6.2, 7]:
    # Trunk
    trunk = mpatches.Rectangle((tx - 0.05, tree_y - 0.3), 0.1, 0.25,
                               facecolor='#6D4C41', edgecolor='black', linewidth=0.5)
    ax.add_patch(trunk)
    # Crown
    crown = mpatches.Polygon([(tx - 0.15, tree_y - 0.05), 
                              (tx + 0.15, tree_y - 0.05), 
                              (tx, tree_y + 0.15)],
                             facecolor='#388E3C', edgecolor='black', linewidth=0.5)
    ax.add_patch(crown)

# Voting
ax.text(5, y3 + 0.5, 'Majority Voting', ha='center', va='center',
        fontsize=9, fontweight='bold', style='italic', color='#1B5E20')

# Arrow 3
ax.annotate('', xy=(arrow_x, y3), xytext=(arrow_x, y3 - 0.6),
            arrowprops=dict(arrowstyle='->', lw=2.5, color='black'))

# ============================================================================
# BOX 4: OUTPUT
# ============================================================================
y4 = y3 - 0.6 - 1.1
h4 = 1.1

rect4 = mpatches.Rectangle((box_x, y4), box_width, h4, 
                           facecolor=c4, edgecolor='black', linewidth=2)
ax.add_patch(rect4)

ax.text(5, y4 + h4 - 0.2, 'OUTPUT CLASSES', ha='center', va='center',
        fontsize=12, fontweight='bold')

# Classes
cy = y4 + 0.6
ax.text(5, cy, 'Class 0: Typical Development', ha='center', va='center',
        fontsize=9, bbox=dict(boxstyle='round,pad=0.25', 
        facecolor='#81C784', edgecolor='black', linewidth=0.8))

ax.text(5, cy - 0.3, 'Class 1: ASD', ha='center', va='center',
        fontsize=9, bbox=dict(boxstyle='round,pad=0.25', 
        facecolor='#FFB74D', edgecolor='black', linewidth=0.8))

ax.text(5, cy - 0.6, 'Class 2: Severe ASD', ha='center', va='center',
        fontsize=9, bbox=dict(boxstyle='round,pad=0.25', 
        facecolor='#E57373', edgecolor='black', linewidth=0.8))

# ============================================================================
# BOTTOM PANELS
# ============================================================================

panel_y = 0.5
panel_h = 1.8
panel_w = 4

# Left panel - Performance
perf_x = 0.5
perf_rect = mpatches.Rectangle((perf_x, panel_y), panel_w, panel_h,
                               facecolor='#E3F2FD', edgecolor='#1565C0', linewidth=2)
ax.add_patch(perf_rect)

ax.text(perf_x + panel_w/2, panel_y + panel_h - 0.25, 'PERFORMANCE',
        ha='center', va='center', fontsize=11, fontweight='bold', color='#1565C0')

px = perf_x + 0.3
py_start = panel_y + panel_h - 0.6
ax.text(px, py_start, 'Test Accuracy:', fontsize=9, fontweight='bold')
ax.text(px + panel_w - 0.6, py_start, '86.4%', fontsize=9, ha='right', fontweight='bold', color='#2E7D32')

ax.text(px, py_start - 0.3, 'External Accuracy:', fontsize=9, fontweight='bold')
ax.text(px + panel_w - 0.6, py_start - 0.3, '86.4%', fontsize=9, ha='right', fontweight='bold', color='#2E7D32')

# ⚠️ CORRECTED: CV Score from actual cross-validation results
ax.text(px, py_start - 0.6, 'CV Score:', fontsize=9, fontweight='bold')
ax.text(px + panel_w - 0.6, py_start - 0.6, '84.6±10.9%', fontsize=9, ha='right')

ax.text(px, py_start - 0.95, 'F1-Scores:', fontsize=9, fontweight='bold')
ax.text(px + 0.05, py_start - 1.2, 'Typical: 0.842  |  ASD: 0.857  |  Severe: 1.000 ✓', fontsize=7.5)

# Right panel - Data Split
data_x = 10 - 0.5 - panel_w
data_rect = mpatches.Rectangle((data_x, panel_y), panel_w, panel_h,
                               facecolor='#F3E5F5', edgecolor='#6A1B9A', linewidth=2)
ax.add_patch(data_rect)

ax.text(data_x + panel_w/2, panel_y + panel_h - 0.25, 'DATA SPLIT',
        ha='center', va='center', fontsize=11, fontweight='bold', color='#6A1B9A')

dx = data_x + 0.3
dy_start = panel_y + panel_h - 0.6
ax.text(dx, dy_start, 'Training:', fontsize=9, fontweight='bold')
ax.text(dx + panel_w - 0.6, dy_start, '65 (60%)', fontsize=9, ha='right', fontweight='bold')

ax.text(dx, dy_start - 0.3, 'Test:', fontsize=9, fontweight='bold')
ax.text(dx + panel_w - 0.6, dy_start - 0.3, '22 (20%)', fontsize=9, ha='right', fontweight='bold')

ax.text(dx, dy_start - 0.6, 'External:', fontsize=9, fontweight='bold')
ax.text(dx + panel_w - 0.6, dy_start - 0.6, '22 (20%)', fontsize=9, ha='right', fontweight='bold')

ax.text(dx, dy_start - 0.95, 'Classes:', fontsize=9, fontweight='bold')
ax.text(dx + 0.05, dy_start - 1.2, 'Typical: 50  |  ASD: 50  |  Severe: 9', fontsize=8)

# Save
output_path = FIGURES_DIR / 'Model_Architecture_CORRECTED.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white', pad_inches=0.3)
plt.close()

print(f"✅ Saved: {output_path}")
print(f"   Size: {output_path.stat().st_size / 1024:.1f} KB")
print(f"   ✅ CORRECTED VALUES:")
print(f"      • class_weight = {{0:0.72, 1:0.72, 2:4.33}}")
print(f"      • CV Score: 84.6±10.9%")
print(f"   Ultra clean and aligned with actual implementation!")

