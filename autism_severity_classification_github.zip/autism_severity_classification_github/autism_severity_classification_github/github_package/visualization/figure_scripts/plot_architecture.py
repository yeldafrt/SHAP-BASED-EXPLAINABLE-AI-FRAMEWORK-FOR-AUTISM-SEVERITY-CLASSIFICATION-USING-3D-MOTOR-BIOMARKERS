#!/usr/bin/env python3
"""
Model Architecture - REVIEWER 3 FIXED (300 DPI)
Changed "External" → "Held-Out"
Improvements:
- Larger fonts for better readability
- Increased spacing and box sizes
- Better contrast and visual hierarchy
- Cleaner layout
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from pathlib import Path

print("Creating Architecture Diagram (REVIEWER 3 FIXED)...")
print("Changed: 'External' → 'Held-Out'\n")

FIGURES_DIR = Path("figures")
FIGURES_DIR.mkdir(exist_ok=True)

# Create figure with larger size
fig = plt.figure(figsize=(12, 14), dpi=300)
ax = fig.add_subplot(111)
ax.set_xlim(0, 12)
ax.set_ylim(0, 14)
ax.axis('off')

# Define precise positions
box_width = 6
box_x = 3  # Center at 6
arrow_x = 6

# Colors
c1 = '#E3F2FD'  # Blue
c2 = '#FFF3E0'  # Orange
c3 = '#E8F5E9'  # Green
c4 = '#F3E5F5'  # Purple

# ============================================================================
# BOX 1: INPUT
# ============================================================================
y1 = 12.5
h1 = 1.0

rect1 = mpatches.Rectangle((box_x, y1), box_width, h1, 
                           facecolor=c1, edgecolor='black', linewidth=2.5)
ax.add_patch(rect1)

ax.text(6, y1 + h1/2 + 0.2, 'INPUT DATA', ha='center', va='center',
        fontsize=14, fontweight='bold')
ax.text(6, y1 + h1/2 - 0.2, '463 Features (Kinect 3D Skeleton)', ha='center', va='center',
        fontsize=11)

# Arrow 1
ax.annotate('', xy=(arrow_x, y1), xytext=(arrow_x, y1 - 0.7),
            arrowprops=dict(arrowstyle='->', lw=3, color='black'))

# ============================================================================
# BOX 2: PREPROCESSING
# ============================================================================
y2 = y1 - 0.7 - 1.0
h2 = 1.0

rect2 = mpatches.Rectangle((box_x, y2), box_width, h2, 
                           facecolor=c2, edgecolor='black', linewidth=2.5)
ax.add_patch(rect2)

ax.text(6, y2 + h2/2 + 0.2, 'PREPROCESSING', ha='center', va='center',
        fontsize=14, fontweight='bold')
ax.text(6, y2 + h2/2 - 0.2, 'StandardScaler (μ=0, σ=1)', ha='center', va='center',
        fontsize=11)

# Arrow 2
ax.annotate('', xy=(arrow_x, y2), xytext=(arrow_x, y2 - 0.7),
            arrowprops=dict(arrowstyle='->', lw=3, color='black'))

# ============================================================================
# BOX 3: RANDOM FOREST
# ============================================================================
y3 = y2 - 0.7 - 3.8
h3 = 3.8

rect3 = mpatches.Rectangle((box_x, y3), box_width, h3, 
                           facecolor=c3, edgecolor='black', linewidth=3)
ax.add_patch(rect3)

# Title
ax.text(6, y3 + h3 - 0.3, 'RANDOM FOREST CLASSIFIER', ha='center', va='center',
        fontsize=15, fontweight='bold')

# Hyperparameters box
hyper_y = y3 + h3 - 0.85
hyper_h = 1.1
hyper_box = mpatches.Rectangle((box_x + 0.25, hyper_y - hyper_h), box_width - 0.5, hyper_h,
                               facecolor='white', edgecolor='#2E7D32', 
                               linewidth=2, linestyle='--')
ax.add_patch(hyper_box)

ax.text(6, hyper_y - 0.18, 'Hyperparameters', ha='center', va='center',
        fontsize=12, fontweight='bold', color='#2E7D32')

# Parameters - Left column
lx = box_x + 0.5
py = hyper_y - 0.45
ax.text(lx, py, '• n_estimators = 200', fontsize=10)
ax.text(lx, py - 0.25, '• max_depth = 15', fontsize=10)
ax.text(lx, py - 0.5, '• min_samples_split = 10', fontsize=10)

# Parameters - Right column
rx = 6.5
ax.text(rx, py, '• min_samples_leaf = 4', fontsize=10)
ax.text(rx, py - 0.25, '• class_weight = {0:0.72, 1:0.72, 2:4.33}', fontsize=10)
ax.text(rx, py - 0.5, '• random_state = 42', fontsize=10)

# Trees
tree_y = y3 + 1.4
ax.text(6, tree_y + 0.35, '200 Decision Trees', ha='center', va='center',
        fontsize=12, fontweight='bold', style='italic')

# Draw simple trees (larger)
for tx in [3.5, 4.3, 5.1, 5.9, 6.7, 7.5, 8.3]:
    # Trunk
    trunk = mpatches.Rectangle((tx - 0.07, tree_y - 0.35), 0.14, 0.3,
                               facecolor='#6D4C41', edgecolor='black', linewidth=0.8)
    ax.add_patch(trunk)
    # Crown
    crown = mpatches.Polygon([(tx - 0.2, tree_y - 0.05), 
                              (tx + 0.2, tree_y - 0.05), 
                              (tx, tree_y + 0.2)],
                             facecolor='#388E3C', edgecolor='black', linewidth=0.8)
    ax.add_patch(crown)

# Voting
ax.text(6, y3 + 0.6, 'Majority Voting', ha='center', va='center',
        fontsize=11, fontweight='bold', style='italic', color='#1B5E20')

# Arrow 3
ax.annotate('', xy=(arrow_x, y3), xytext=(arrow_x, y3 - 0.7),
            arrowprops=dict(arrowstyle='->', lw=3, color='black'))

# ============================================================================
# BOX 4: OUTPUT
# ============================================================================
y4 = y3 - 0.7 - 1.3
h4 = 1.3

rect4 = mpatches.Rectangle((box_x, y4), box_width, h4, 
                           facecolor=c4, edgecolor='black', linewidth=2.5)
ax.add_patch(rect4)

ax.text(6, y4 + h4 - 0.25, 'OUTPUT CLASSES', ha='center', va='center',
        fontsize=14, fontweight='bold')

# Classes
cy = y4 + 0.7
ax.text(6, cy, 'Class 0: Typical Development', ha='center', va='center',
        fontsize=11, bbox=dict(boxstyle='round,pad=0.3', 
        facecolor='#81C784', edgecolor='black', linewidth=1.2))

ax.text(6, cy - 0.35, 'Class 1: ASD', ha='center', va='center',
        fontsize=11, bbox=dict(boxstyle='round,pad=0.3', 
        facecolor='#FFB74D', edgecolor='black', linewidth=1.2))

ax.text(6, cy - 0.7, 'Class 2: Severe ASD', ha='center', va='center',
        fontsize=11, bbox=dict(boxstyle='round,pad=0.3', 
        facecolor='#E57373', edgecolor='black', linewidth=1.2))

# ============================================================================
# BOTTOM PANELS
# ============================================================================

panel_y = 0.6
panel_h = 2.2
panel_w = 4.8

# Left panel - Performance
perf_x = 0.6
perf_rect = mpatches.Rectangle((perf_x, panel_y), panel_w, panel_h,
                               facecolor='#E3F2FD', edgecolor='#1565C0', linewidth=2.5)
ax.add_patch(perf_rect)

ax.text(perf_x + panel_w/2, panel_y + panel_h - 0.3, 'PERFORMANCE',
        ha='center', va='center', fontsize=13, fontweight='bold', color='#1565C0')

px = perf_x + 0.35
py_start = panel_y + panel_h - 0.7
ax.text(px, py_start, 'Test Accuracy:', fontsize=11, fontweight='bold')
ax.text(px + panel_w - 0.7, py_start, '86.4%', fontsize=11, ha='right', fontweight='bold', color='#2E7D32')

ax.text(px, py_start - 0.35, 'Held-Out Accuracy:', fontsize=11, fontweight='bold')
ax.text(px + panel_w - 0.7, py_start - 0.35, '86.4%', fontsize=11, ha='right', fontweight='bold', color='#2E7D32')

ax.text(px, py_start - 0.7, 'CV Score:', fontsize=11, fontweight='bold')
ax.text(px + panel_w - 0.7, py_start - 0.7, '84.6±10.9%', fontsize=11, ha='right')

ax.text(px, py_start - 1.1, 'F1-Scores:', fontsize=11, fontweight='bold')
ax.text(px + 0.05, py_start - 1.4, 'Typical: 0.842  |  ASD: 0.857  |  Severe: 1.000 ✓', fontsize=9.5)

# Right panel - Data Split
data_x = 12 - 0.6 - panel_w
data_rect = mpatches.Rectangle((data_x, panel_y), panel_w, panel_h,
                               facecolor='#F3E5F5', edgecolor='#6A1B9A', linewidth=2.5)
ax.add_patch(data_rect)

ax.text(data_x + panel_w/2, panel_y + panel_h - 0.3, 'DATA SPLIT',
        ha='center', va='center', fontsize=13, fontweight='bold', color='#6A1B9A')

dx = data_x + 0.35
dy_start = panel_y + panel_h - 0.7
ax.text(dx, dy_start, 'Training:', fontsize=11, fontweight='bold')
ax.text(dx + panel_w - 0.7, dy_start, '65 (60%)', fontsize=11, ha='right', fontweight='bold')

ax.text(dx, dy_start - 0.35, 'Test:', fontsize=11, fontweight='bold')
ax.text(dx + panel_w - 0.7, dy_start - 0.35, '22 (20%)', fontsize=11, ha='right', fontweight='bold')

ax.text(dx, dy_start - 0.7, 'Held-Out:', fontsize=11, fontweight='bold')
ax.text(dx + panel_w - 0.7, dy_start - 0.7, '22 (20%)', fontsize=11, ha='right', fontweight='bold')

ax.text(dx, dy_start - 1.1, 'Classes:', fontsize=11, fontweight='bold')
ax.text(dx + 0.05, dy_start - 1.4, 'Typical: 50  |  ASD: 50  |  Severe: 9', fontsize=10)

# Save
output_path = FIGURES_DIR / 'Model_Architecture_REVIEWER3_FIXED.png'
home_path = Path("/home/ubuntu") / 'Figure3_Model_Architecture_FIXED.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white', pad_inches=0.4)
plt.savefig(home_path, dpi=300, bbox_inches='tight', facecolor='white', pad_inches=0.4)
plt.close()

print(f"✅ Figures saved:")
print(f"   1. {output_path}")
print(f"   2. {home_path}")
print(f"   Size: {output_path.stat().st_size / 1024:.1f} KB")
print(f"   Resolution: 300 DPI")
print(f"\n✅ REVIEWER 3 CHANGES APPLIED:")
print(f"   ✓ PERFORMANCE: 'External Accuracy' → 'Held-Out Accuracy'")
print(f"   ✓ DATA SPLIT: 'External' → 'Held-Out'")
print(f"   ✓ All terminology consistent with manuscript revisions")

