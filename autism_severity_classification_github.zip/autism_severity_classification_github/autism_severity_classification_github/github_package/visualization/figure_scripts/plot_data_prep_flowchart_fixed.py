#!/usr/bin/env python3
"""
Data Preparation Flowchart - Perfectly Aligned
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from pathlib import Path

print("Creating Perfectly Aligned Data Preparation Flowchart...")

FIGURES_DIR = Path("figures")
FIGURES_DIR.mkdir(exist_ok=True)

# Create figure
fig = plt.figure(figsize=(10, 14), dpi=300)
ax = fig.add_subplot(111)
ax.set_xlim(0, 10)
ax.set_ylim(0, 14)
ax.axis('off')

# Colors
c_raw = '#FFEBEE'
c_process = '#E3F2FD'
c_split = '#FFF3E0'
c_final = '#E8F5E9'

# Constants
box_w = 7
center_x = 5
box_left = center_x - box_w/2

# ============================================================================
# STEP 1: RAW DATA
# ============================================================================
y1 = 12.5
h1 = 1.0

rect1 = mpatches.Rectangle((box_left, y1), box_w, h1,
                           facecolor=c_raw, edgecolor='#C62828', linewidth=2.5)
ax.add_patch(rect1)

ax.text(center_x, y1 + h1/2 + 0.25, 'STEP 1: RAW DATA',
        ha='center', va='center', fontsize=11, fontweight='bold', color='#C62828')
ax.text(center_x, y1 + h1/2 - 0.08, 'autism_3d_dataset.rar (808 MB)',
        ha='center', va='center', fontsize=9.5)
ax.text(center_x, y1 + h1/2 - 0.35, '109 children: Typical(50) | ASD(50) | Severe(9)',
        ha='center', va='center', fontsize=9)

# Arrow 1
ax.annotate('', xy=(center_x, y1), xytext=(center_x, y1 - 0.6),
            arrowprops=dict(arrowstyle='->', lw=2.5, color='black'))

# ============================================================================
# STEP 2: EXTRACT & READ
# ============================================================================
y2 = y1 - 0.6 - 1.6
h2 = 1.6

rect2 = mpatches.Rectangle((box_left, y2), box_w, h2,
                           facecolor=c_process, edgecolor='#1565C0', linewidth=2.5)
ax.add_patch(rect2)

ax.text(center_x, y2 + h2 - 0.2, 'STEP 2: EXTRACT & READ EXCEL FILES',
        ha='center', va='center', fontsize=11, fontweight='bold', color='#1565C0')

# Two columns
left_col = box_left + 0.4
right_col = center_x + 0.2
detail_y = y2 + h2 - 0.55

ax.text(left_col, detail_y, '• Each child folder:', fontsize=9, fontweight='bold')
ax.text(left_col + 0.1, detail_y - 0.25, 'video/8features.xlsx', fontsize=8.5)
ax.text(left_col + 0.1, detail_y - 0.47, '463 features per child', fontsize=8.5)
ax.text(left_col + 0.1, detail_y - 0.69, '25 joints × 3D + gait', fontsize=8.5)

ax.text(right_col, detail_y, '• Processing:', fontsize=9, fontweight='bold')
ax.text(right_col + 0.1, detail_y - 0.25, 'Read first row only', fontsize=8.5)
ax.text(right_col + 0.1, detail_y - 0.47, 'Skip timestamp column', fontsize=8.5)
ax.text(right_col + 0.1, detail_y - 0.69, 'Extract 463 numerics', fontsize=8.5)

ax.text(center_x, y2 + 0.28, 'Output: 109 samples × 463 features',
        ha='center', va='center', fontsize=8.5, style='italic', color='#0D47A1')

# Arrow 2
ax.annotate('', xy=(center_x, y2), xytext=(center_x, y2 - 0.6),
            arrowprops=dict(arrowstyle='->', lw=2.5, color='black'))

# ============================================================================
# STEP 3: COMBINE & LABEL
# ============================================================================
y3 = y2 - 0.6 - 1.2
h3 = 1.2

rect3 = mpatches.Rectangle((box_left, y3), box_w, h3,
                           facecolor=c_process, edgecolor='#1565C0', linewidth=2.5)
ax.add_patch(rect3)

ax.text(center_x, y3 + h3 - 0.2, 'STEP 3: COMBINE & LABEL',
        ha='center', va='center', fontsize=11, fontweight='bold', color='#1565C0')

ax.text(center_x, y3 + h3/2 - 0.05, '• Merge all samples → DataFrame (109 × 466)',
        ha='center', fontsize=9)
ax.text(center_x, y3 + h3/2 - 0.32, '• Add labels: Typical=0, ASD=1, Severe=2',
        ha='center', fontsize=9)
ax.text(center_x, y3 + h3/2 - 0.59, '• Add metadata: child_id, class_name',
        ha='center', fontsize=9)

# Arrow 3
ax.annotate('', xy=(center_x, y3), xytext=(center_x, y3 - 0.6),
            arrowprops=dict(arrowstyle='->', lw=2.5, color='black'))

# ============================================================================
# STEP 4: STRATIFIED SPLIT
# ============================================================================
y4 = y3 - 0.6 - 1.5
h4 = 1.5

rect4 = mpatches.Rectangle((box_left, y4), box_w, h4,
                           facecolor=c_split, edgecolor='#E65100', linewidth=2.5)
ax.add_patch(rect4)

ax.text(center_x, y4 + h4 - 0.2, 'STEP 4: STRATIFIED SPLIT',
        ha='center', va='center', fontsize=11, fontweight='bold', color='#E65100')

# Three equal boxes
split_y = y4 + h4 - 0.6
box_w_small = 2.0
gap = 0.3

# Train
train_x = box_left + 0.4
train_box = mpatches.Rectangle((train_x, split_y - 0.55), box_w_small, 0.5,
                                facecolor='#C8E6C9', edgecolor='black', linewidth=1.5)
ax.add_patch(train_box)
ax.text(train_x + box_w_small/2, split_y - 0.15, 'TRAIN', ha='center', fontweight='bold', fontsize=9)
ax.text(train_x + box_w_small/2, split_y - 0.35, '65 (60%)', ha='center', fontsize=8)
ax.text(train_x + box_w_small/2, split_y - 0.5, '30+30+5', ha='center', fontsize=7)

# Test
test_x = train_x + box_w_small + gap
test_box = mpatches.Rectangle((test_x, split_y - 0.55), box_w_small, 0.5,
                               facecolor='#FFE082', edgecolor='black', linewidth=1.5)
ax.add_patch(test_box)
ax.text(test_x + box_w_small/2, split_y - 0.15, 'TEST', ha='center', fontweight='bold', fontsize=9)
ax.text(test_x + box_w_small/2, split_y - 0.35, '22 (20%)', ha='center', fontsize=8)
ax.text(test_x + box_w_small/2, split_y - 0.5, '10+10+2', ha='center', fontsize=7)

# External
ext_x = test_x + box_w_small + gap
ext_box = mpatches.Rectangle((ext_x, split_y - 0.55), box_w_small, 0.5,
                              facecolor='#E1BEE7', edgecolor='black', linewidth=1.5)
ax.add_patch(ext_box)
ax.text(ext_x + box_w_small/2, split_y - 0.15, 'EXTERNAL', ha='center', fontweight='bold', fontsize=9)
ax.text(ext_x + box_w_small/2, split_y - 0.35, '22 (20%)', ha='center', fontsize=8)
ax.text(ext_x + box_w_small/2, split_y - 0.5, '10+10+2', ha='center', fontsize=7)

ax.text(center_x, y4 + 0.23, 'Stratified to maintain class balance',
        ha='center', va='center', fontsize=8.5, style='italic', color='#BF360C')

# Arrow 4
ax.annotate('', xy=(center_x, y4), xytext=(center_x, y4 - 0.6),
            arrowprops=dict(arrowstyle='->', lw=2.5, color='black'))

# ============================================================================
# STEP 5: NORMALIZATION
# ============================================================================
y5 = y4 - 0.6 - 1.0
h5 = 1.0

rect5 = mpatches.Rectangle((box_left, y5), box_w, h5,
                           facecolor=c_process, edgecolor='#1565C0', linewidth=2.5)
ax.add_patch(rect5)

ax.text(center_x, y5 + h5 - 0.2, 'STEP 5: STANDARDIZATION',
        ha='center', va='center', fontsize=11, fontweight='bold', color='#1565C0')

ax.text(center_x, y5 + h5/2 - 0.05, '• StandardScaler: (X - μ) / σ  →  μ=0, σ=1',
        ha='center', fontsize=9)
ax.text(center_x, y5 + h5/2 - 0.32, '• Fit on TRAIN only, transform all sets',
        ha='center', fontsize=9)

# Arrow 5
ax.annotate('', xy=(center_x, y5), xytext=(center_x, y5 - 0.6),
            arrowprops=dict(arrowstyle='->', lw=2.5, color='black'))

# ============================================================================
# STEP 6: SAVE FINAL DATA
# ============================================================================
y6 = y5 - 0.6 - 2.0
h6 = 2.0

rect6 = mpatches.Rectangle((box_left, y6), box_w, h6,
                           facecolor=c_final, edgecolor='#2E7D32', linewidth=3)
ax.add_patch(rect6)

ax.text(center_x, y6 + h6 - 0.2, 'STEP 6: SAVE MODEL-READY DATA',
        ha='center', va='center', fontsize=11, fontweight='bold', color='#2E7D32')

# Files in two columns
file_y = y6 + h6 - 0.6
left_files = [
    ('X_train.npy', '65 × 463'),
    ('y_train.npy', '65 × 1'),
    ('X_test.npy', '22 × 463'),
]
right_files = [
    ('y_test.npy', '22 × 1'),
    ('X_external.npy', '22 × 463'),
    ('y_external.npy', '22 × 1'),
]

for i, (fname, shape) in enumerate(left_files):
    ax.text(box_left + 0.5, file_y - i * 0.28, f'• {fname}', fontsize=8.5, fontweight='bold')
    ax.text(box_left + 1.7, file_y - i * 0.28, shape, fontsize=8, color='#1565C0')

for i, (fname, shape) in enumerate(right_files):
    ax.text(center_x + 0.6, file_y - i * 0.28, f'• {fname}', fontsize=8.5, fontweight='bold')
    ax.text(center_x + 1.8, file_y - i * 0.28, shape, fontsize=8, color='#1565C0')

ax.text(center_x, y6 + 0.3, '+ CSV files (with column names) + metadata.json',
        ha='center', va='center', fontsize=8, style='italic', color='#1B5E20')

# ============================================================================
# FINAL DATA STRUCTURE BOX
# ============================================================================
y_struct = y6 - 1.0
struct_h = 1.0

struct_box = mpatches.Rectangle((box_left + 0.3, y_struct - struct_h), box_w - 0.6, struct_h,
                                facecolor='#FFFDE7', edgecolor='#F57F17',
                                linewidth=2, linestyle='--')
ax.add_patch(struct_box)

ax.text(center_x, y_struct - 0.18, 'FINAL DATA STRUCTURE FOR MODEL',
        ha='center', va='center', fontsize=10, fontweight='bold', color='#F57F17')

ax.text(center_x, y_struct - 0.45, 'X: (n_samples, 463) - float64, normalized (μ=0, σ=1)',
        ha='center', fontsize=8.5, family='monospace')
ax.text(center_x, y_struct - 0.68, 'y: (n_samples,) - int (0=Typical, 1=ASD, 2=Severe)',
        ha='center', fontsize=8.5, family='monospace')
ax.text(center_x, y_struct - 0.88, 'Ready for sklearn / TensorFlow / PyTorch',
        ha='center', fontsize=8, style='italic', color='#E65100')

# Save
output_path = FIGURES_DIR / 'Data_Preparation_Flowchart.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white', pad_inches=0.3)
plt.close()

print(f"✅ Saved: {output_path}")
print(f"   Size: {output_path.stat().st_size / 1024:.1f} KB")
print(f"   Perfectly aligned flowchart!")

