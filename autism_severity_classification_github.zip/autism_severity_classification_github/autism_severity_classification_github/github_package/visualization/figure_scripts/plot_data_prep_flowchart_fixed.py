#!/usr/bin/env python3
"""
Data Preparation Flowchart - Enhanced Readability Version (300 DPI)
Improvements:
- Larger fonts for better readability
- Increased spacing between elements
- Better contrast and colors
- Cleaner layout
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from pathlib import Path

print("Creating Enhanced Data Preparation Flowchart (300 DPI)...")

FIGURES_DIR = Path("figures")
FIGURES_DIR.mkdir(exist_ok=True)

# Create figure with larger size for better readability
fig = plt.figure(figsize=(12, 16), dpi=300)
ax = fig.add_subplot(111)
ax.set_xlim(0, 12)
ax.set_ylim(0, 16)
ax.axis('off')

# Enhanced colors with better contrast
c_raw = '#FFEBEE'
c_process = '#E3F2FD'
c_split = '#FFF3E0'
c_final = '#E8F5E9'

# Constants
box_w = 8.5
center_x = 6
box_left = center_x - box_w/2

# ============================================================================
# STEP 1: RAW DATA
# ============================================================================
y1 = 14.5
h1 = 1.2

rect1 = mpatches.Rectangle((box_left, y1), box_w, h1,
                           facecolor=c_raw, edgecolor='#C62828', linewidth=3)
ax.add_patch(rect1)

ax.text(center_x, y1 + h1/2 + 0.3, 'STEP 1: RAW DATA',
        ha='center', va='center', fontsize=14, fontweight='bold', color='#C62828')
ax.text(center_x, y1 + h1/2 - 0.05, 'autism_3d_dataset.rar (808 MB)',
        ha='center', va='center', fontsize=11)
ax.text(center_x, y1 + h1/2 - 0.4, '109 children: Typical(50) | ASD(50) | Severe(9)',
        ha='center', va='center', fontsize=10.5)

# Arrow 1
ax.annotate('', xy=(center_x, y1), xytext=(center_x, y1 - 0.7),
            arrowprops=dict(arrowstyle='->', lw=3, color='black'))

# ============================================================================
# STEP 2: EXTRACT & READ
# ============================================================================
y2 = y1 - 0.7 - 1.9
h2 = 1.9

rect2 = mpatches.Rectangle((box_left, y2), box_w, h2,
                           facecolor=c_process, edgecolor='#1565C0', linewidth=3)
ax.add_patch(rect2)

ax.text(center_x, y2 + h2 - 0.25, 'STEP 2: EXTRACT & READ EXCEL FILES',
        ha='center', va='center', fontsize=14, fontweight='bold', color='#1565C0')

# Two columns with better spacing
left_col = box_left + 0.6
right_col = center_x + 0.4
detail_y = y2 + h2 - 0.7

ax.text(left_col, detail_y, '• Each child folder:', fontsize=10.5, fontweight='bold')
ax.text(left_col + 0.15, detail_y - 0.3, 'video/8features.xlsx', fontsize=10)
ax.text(left_col + 0.15, detail_y - 0.57, '463 features per child', fontsize=10)
ax.text(left_col + 0.15, detail_y - 0.84, '25 joints × 3D + gait', fontsize=10)

ax.text(right_col, detail_y, '• Processing:', fontsize=10.5, fontweight='bold')
ax.text(right_col + 0.15, detail_y - 0.3, 'Read first row only', fontsize=10)
ax.text(right_col + 0.15, detail_y - 0.57, 'Skip timestamp column', fontsize=10)
ax.text(right_col + 0.15, detail_y - 0.84, 'Extract 463 numerics', fontsize=10)

ax.text(center_x, y2 + 0.35, 'Output: 109 samples × 463 features',
        ha='center', va='center', fontsize=10, style='italic', color='#0D47A1')

# Arrow 2
ax.annotate('', xy=(center_x, y2), xytext=(center_x, y2 - 0.7),
            arrowprops=dict(arrowstyle='->', lw=3, color='black'))

# ============================================================================
# STEP 3: COMBINE & LABEL
# ============================================================================
y3 = y2 - 0.7 - 1.4
h3 = 1.4

rect3 = mpatches.Rectangle((box_left, y3), box_w, h3,
                           facecolor=c_process, edgecolor='#1565C0', linewidth=3)
ax.add_patch(rect3)

ax.text(center_x, y3 + h3 - 0.25, 'STEP 3: COMBINE & LABEL',
        ha='center', va='center', fontsize=14, fontweight='bold', color='#1565C0')

ax.text(center_x, y3 + h3/2 - 0.05, '• Merge all samples → DataFrame (109 × 466)',
        ha='center', fontsize=10.5)
ax.text(center_x, y3 + h3/2 - 0.38, '• Add labels: Typical=0, ASD=1, Severe=2',
        ha='center', fontsize=10.5)
ax.text(center_x, y3 + h3/2 - 0.71, '• Add metadata: child_id, class_name',
        ha='center', fontsize=10.5)

# Arrow 3
ax.annotate('', xy=(center_x, y3), xytext=(center_x, y3 - 0.7),
            arrowprops=dict(arrowstyle='->', lw=3, color='black'))

# ============================================================================
# STEP 4: STRATIFIED SPLIT
# ============================================================================
y4 = y3 - 0.7 - 1.7
h4 = 1.7

rect4 = mpatches.Rectangle((box_left, y4), box_w, h4,
                           facecolor=c_split, edgecolor='#E65100', linewidth=3)
ax.add_patch(rect4)

ax.text(center_x, y4 + h4 - 0.25, 'STEP 4: STRATIFIED SPLIT',
        ha='center', va='center', fontsize=14, fontweight='bold', color='#E65100')

# Three equal boxes with better spacing
split_y = y4 + h4 - 0.7
box_w_small = 2.3
gap = 0.4

# Train
train_x = box_left + 0.6
train_box = mpatches.Rectangle((train_x, split_y - 0.65), box_w_small, 0.6,
                                facecolor='#C8E6C9', edgecolor='black', linewidth=2)
ax.add_patch(train_box)
ax.text(train_x + box_w_small/2, split_y - 0.18, 'TRAIN', ha='center', fontweight='bold', fontsize=11)
ax.text(train_x + box_w_small/2, split_y - 0.4, '65 (60%)', ha='center', fontsize=10)
ax.text(train_x + box_w_small/2, split_y - 0.58, '30+30+5', ha='center', fontsize=8.5)

# Test
test_x = train_x + box_w_small + gap
test_box = mpatches.Rectangle((test_x, split_y - 0.65), box_w_small, 0.6,
                               facecolor='#FFE082', edgecolor='black', linewidth=2)
ax.add_patch(test_box)
ax.text(test_x + box_w_small/2, split_y - 0.18, 'TEST', ha='center', fontweight='bold', fontsize=11)
ax.text(test_x + box_w_small/2, split_y - 0.4, '22 (20%)', ha='center', fontsize=10)
ax.text(test_x + box_w_small/2, split_y - 0.58, '10+10+2', ha='center', fontsize=8.5)

# External
ext_x = test_x + box_w_small + gap
ext_box = mpatches.Rectangle((ext_x, split_y - 0.65), box_w_small, 0.6,
                              facecolor='#E1BEE7', edgecolor='black', linewidth=2)
ax.add_patch(ext_box)
ax.text(ext_x + box_w_small/2, split_y - 0.18, 'EXTERNAL', ha='center', fontweight='bold', fontsize=11)
ax.text(ext_x + box_w_small/2, split_y - 0.4, '22 (20%)', ha='center', fontsize=10)
ax.text(ext_x + box_w_small/2, split_y - 0.58, '10+10+2', ha='center', fontsize=8.5)

ax.text(center_x, y4 + 0.28, 'Stratified to maintain class balance',
        ha='center', va='center', fontsize=10, style='italic', color='#BF360C')

# Arrow 4
ax.annotate('', xy=(center_x, y4), xytext=(center_x, y4 - 0.7),
            arrowprops=dict(arrowstyle='->', lw=3, color='black'))

# ============================================================================
# STEP 5: STANDARDIZATION
# ============================================================================
y5 = y4 - 0.7 - 1.2
h5 = 1.2

rect5 = mpatches.Rectangle((box_left, y5), box_w, h5,
                           facecolor=c_process, edgecolor='#1565C0', linewidth=3)
ax.add_patch(rect5)

ax.text(center_x, y5 + h5 - 0.25, 'STEP 5: STANDARDIZATION',
        ha='center', va='center', fontsize=14, fontweight='bold', color='#1565C0')

ax.text(center_x, y5 + h5/2 - 0.05, '• StandardScaler: (X - μ) / σ  →  μ=0, σ=1',
        ha='center', fontsize=10.5)
ax.text(center_x, y5 + h5/2 - 0.4, '• Fit on TRAIN only, transform all sets',
        ha='center', fontsize=10.5)

# Arrow 5
ax.annotate('', xy=(center_x, y5), xytext=(center_x, y5 - 0.7),
            arrowprops=dict(arrowstyle='->', lw=3, color='black'))

# ============================================================================
# STEP 6: SAVE MODEL-READY DATA
# ============================================================================
y6 = y5 - 0.7 - 2.3
h6 = 2.3

rect6 = mpatches.Rectangle((box_left, y6), box_w, h6,
                           facecolor=c_final, edgecolor='#2E7D32', linewidth=3.5)
ax.add_patch(rect6)

ax.text(center_x, y6 + h6 - 0.25, 'STEP 6: SAVE MODEL-READY DATA',
        ha='center', va='center', fontsize=14, fontweight='bold', color='#2E7D32')

# Files in two columns with better spacing
file_y = y6 + h6 - 0.7
left_files = [
    ('X_train.npy', '65 × 463'),
    ('y_train.npy', '65 × 1'),
    ('X_test.npy', '22 × 463'),
]
right_files = [
    ('y_test.npy', '22 × 1'),
    ('X_external.npy', '22 × 463'),
    ('y_external.npy', '22 × 1'),
]

for i, (fname, shape) in enumerate(left_files):
    ax.text(box_left + 0.6, file_y - i * 0.33, f'• {fname}', fontsize=10, fontweight='bold')
    ax.text(box_left + 2.1, file_y - i * 0.33, shape, fontsize=9.5, color='#1565C0')

for i, (fname, shape) in enumerate(right_files):
    ax.text(center_x + 0.8, file_y - i * 0.33, f'• {fname}', fontsize=10, fontweight='bold')
    ax.text(center_x + 2.3, file_y - i * 0.33, shape, fontsize=9.5, color='#1565C0')

ax.text(center_x, y6 + 0.38, '+ CSV files (with column names) + metadata.json',
        ha='center', va='center', fontsize=9.5, style='italic', color='#1B5E20')

# ============================================================================
# FINAL DATA STRUCTURE BOX
# ============================================================================
y_struct = y6 - 1.15
struct_h = 1.15

struct_box = mpatches.Rectangle((box_left + 0.4, y_struct - struct_h), box_w - 0.8, struct_h,
                                facecolor='#FFFDE7', edgecolor='#F57F17',
                                linewidth=2.5, linestyle='--')
ax.add_patch(struct_box)

ax.text(center_x, y_struct - 0.22, 'FINAL DATA STRUCTURE FOR MODEL',
        ha='center', va='center', fontsize=12, fontweight='bold', color='#F57F17')

ax.text(center_x, y_struct - 0.53, 'X: (n_samples, 463) - float64, normalized (μ=0, σ=1)',
        ha='center', fontsize=10, family='monospace')
ax.text(center_x, y_struct - 0.79, 'y: (n_samples,) - int (0=Typical, 1=ASD, 2=Severe)',
        ha='center', fontsize=10, family='monospace')
ax.text(center_x, y_struct - 1.02, 'Ready for sklearn / TensorFlow / PyTorch',
        ha='center', fontsize=9.5, style='italic', color='#E65100')

# Save
output_path = FIGURES_DIR / 'Data_Preparation_Flowchart_Enhanced.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white', pad_inches=0.4)
plt.close()

print(f"✅ Saved: {output_path}")
print(f"   Size: {output_path.stat().st_size / 1024:.1f} KB")
print(f"   Resolution: 300 DPI")
print(f"   Enhanced readability with larger fonts and better spacing!")

