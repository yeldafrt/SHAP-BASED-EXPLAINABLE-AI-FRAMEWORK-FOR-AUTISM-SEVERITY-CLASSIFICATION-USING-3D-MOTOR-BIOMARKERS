import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pickle
import shap

# Set style
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['xtick.labelsize'] = 9
plt.rcParams['ytick.labelsize'] = 9

print("Loading data and model...")

# Load data
X_external = np.load("prepared_dataset_v2/X_external.npy")
y_external = np.load("prepared_dataset_v2/y_external.npy")

with open("model_results/scaler.pkl", "rb") as f:
    scaler = pickle.load(f)
X_external_scaled = scaler.transform(X_external)

with open("model_results/RandomForest_model.pkl", "rb") as f:
    rf_model = pickle.load(f)

# Load feature names
feature_names_df = pd.read_csv("prepared_dataset_v2/feature_names.csv")
feature_names = feature_names_df['feature_name'].tolist()

print("Computing SHAP values...")
explainer = shap.TreeExplainer(rf_model)
shap_values = explainer.shap_values(X_external_scaled)

# Extract severe class SHAP
shap_severe = shap_values[:, :, 2]

# Calculate mean absolute SHAP
mean_abs_shap = np.abs(shap_severe).mean(axis=0)

# Get top 20
top_20_indices = np.argsort(mean_abs_shap)[::-1][:20]
top_20_features = [feature_names[i] for i in top_20_indices]
top_20_values = mean_abs_shap[top_20_indices]

# Get severe samples
severe_mask = y_external == 2
severe_indices = np.where(severe_mask)[0]

print(f"Creating combined figure with 3 panels...")

# Create figure with 3 panels
fig = plt.figure(figsize=(18, 6))

# Panel (a): Bar Plot - Top 20 Features
ax1 = plt.subplot(1, 3, 1)

# Reverse order for horizontal bar plot
colors = plt.cm.RdYlGn_r(np.linspace(0.3, 0.9, 20))[::-1]

bars = ax1.barh(range(20), top_20_values[::-1], color=colors, edgecolor='black', linewidth=0.5)

# Add values
for i, (bar, val) in enumerate(zip(bars, top_20_values[::-1])):
    ax1.text(val + 0.0002, i, f'{val:.4f}', va='center', fontsize=8)

ax1.set_yticks(range(20))
ax1.set_yticklabels(top_20_features[::-1], fontsize=9)
ax1.set_xlabel('Mean |SHAP value| for Severe Class', fontsize=11, fontweight='bold')
ax1.set_title('(a) Top 20 Feature Importance', fontsize=12, fontweight='bold', loc='left')
ax1.grid(axis='x', alpha=0.3, linestyle='--')
ax1.set_xlim(0, max(top_20_values) * 1.15)

# Panel (b): Summary Plot - Top 20 Features (SEVERE SAMPLES ONLY)
ax2 = plt.subplot(1, 3, 2)

# For each feature, plot SHAP values
for i, feat_idx in enumerate(top_20_indices):
    # Get SHAP values for SEVERE samples only
    shap_vals = shap_severe[severe_mask, feat_idx]
    feat_vals = X_external_scaled[severe_mask, feat_idx]
    
    # Normalize feature values for coloring (0-1)
    if feat_vals.max() != feat_vals.min():
        feat_vals_norm = (feat_vals - feat_vals.min()) / (feat_vals.max() - feat_vals.min())
    else:
        feat_vals_norm = np.ones_like(feat_vals) * 0.5
    
    # Plot each point
    scatter = ax2.scatter(shap_vals, [i]*len(shap_vals), 
                         c=feat_vals_norm, cmap='coolwarm', 
                         s=50, alpha=0.7, edgecolors='black', linewidth=0.5,
                         vmin=0, vmax=1)

ax2.set_yticks(range(20))
ax2.set_yticklabels(top_20_features, fontsize=9)
ax2.set_xlabel('SHAP Value (Impact on Severe Prediction)', fontsize=11, fontweight='bold')
ax2.set_title('(b) SHAP Summary Plot', fontsize=12, fontweight='bold', loc='left')
ax2.axvline(x=0, color='black', linestyle='-', linewidth=0.8, alpha=0.5)
ax2.grid(axis='x', alpha=0.3, linestyle='--')

# Add colorbar
cbar = plt.colorbar(scatter, ax=ax2, pad=0.01)
cbar.set_label('Feature Value', fontsize=9, fontweight='bold')
cbar.set_ticks([0, 0.5, 1])
cbar.set_ticklabels(['Low', 'Medium', 'High'], fontsize=8)

# Panel (c): Waterfall Plot - Example Severe Case
ax3 = plt.subplot(1, 3, 3)

if len(severe_indices) > 0:
    sample_idx = severe_indices[0]
    sample_shap = shap_severe[sample_idx]
    base_value = explainer.expected_value[2]
    
    # Get top contributing features (positive and negative)
    top_contrib_indices = np.argsort(np.abs(sample_shap))[::-1][:14]
    
    # Calculate cumulative sum
    cumsum = base_value
    positions = [cumsum]
    
    feature_labels = []
    feature_values = []
    shap_contribs = []
    
    for idx in top_contrib_indices:
        feat_name = feature_names[idx]
        feat_val = X_external_scaled[sample_idx, idx]
        shap_val = sample_shap[idx]
        
        feature_labels.append(f"{feat_name} = {feat_val:.3f}")
        feature_values.append(feat_val)
        shap_contribs.append(shap_val)
        
        cumsum += shap_val
        positions.append(cumsum)
    
    # Add "other features"
    other_shap = sample_shap.sum() - sum(shap_contribs)
    feature_labels.append(f"449 other features")
    shap_contribs.append(other_shap)
    cumsum += other_shap
    positions.append(cumsum)
    
    # Plot waterfall
    y_pos = range(len(feature_labels) + 1)
    
    # Plot base value
    ax3.barh(0, base_value, left=0, height=0.8, 
            color='lightgray', edgecolor='black', linewidth=1)
    ax3.text(base_value/2, 0, f'E[f(X)]={base_value:.3f}', 
            ha='center', va='center', fontsize=8, fontweight='bold')
    
    # Plot contributions
    for i, (label, contrib) in enumerate(zip(feature_labels, shap_contribs), 1):
        color = '#FF6B6B' if contrib > 0 else '#4ECDC4'
        
        ax3.barh(i, contrib, left=positions[i-1], height=0.8,
                color=color, edgecolor='black', linewidth=0.5, alpha=0.8)
        
        # Add text
        if abs(contrib) > 0.01:
            ax3.text(positions[i-1] + contrib/2, i, f'{contrib:+.3f}',
                    ha='center', va='center', fontsize=7, fontweight='bold')
    
    # Add final prediction
    final_pred = positions[-1]
    ax3.text(final_pred + 0.02, len(feature_labels), f'f(x)={final_pred:.3f}',
            ha='left', va='center', fontsize=9, fontweight='bold',
            bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.5))
    
    # Set labels
    ax3.set_yticks(range(len(feature_labels) + 1))
    ax3.set_yticklabels(['Base value'] + feature_labels, fontsize=8)
    ax3.set_xlabel('Model Output (Severe Probability)', fontsize=11, fontweight='bold')
    ax3.set_title('(c) SHAP Waterfall Plot (Example Severe Case)', fontsize=12, fontweight='bold', loc='left')
    ax3.grid(axis='x', alpha=0.3, linestyle='--')
    ax3.set_xlim(0, 1)
    
    # Add legend
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor='#FF6B6B', edgecolor='black', label='Positive contribution'),
        Patch(facecolor='#4ECDC4', edgecolor='black', label='Negative contribution')
    ]
    ax3.legend(handles=legend_elements, loc='lower right', fontsize=8)

plt.tight_layout()

# Save
output_path = "figures/SHAP_Combined_Analysis.png"
plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
print(f"\n✓ Combined SHAP figure saved: {output_path}")

plt.close()

print("\n" + "="*80)
print("COMBINED SHAP FIGURE CREATED SUCCESSFULLY!")
print("="*80)
print(f"\nOutput: {output_path}")
print(f"Resolution: 300 DPI")
print(f"Format: PNG")
print(f"Panels: 3 (a, b, c)")

