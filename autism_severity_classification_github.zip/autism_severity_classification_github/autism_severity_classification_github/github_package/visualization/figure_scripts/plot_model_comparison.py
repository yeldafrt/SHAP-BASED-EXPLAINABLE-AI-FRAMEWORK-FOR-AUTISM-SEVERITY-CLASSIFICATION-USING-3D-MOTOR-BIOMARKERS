#!/usr/bin/env python3
"""
Model Performance Comparison (4 panels)
(a) Test Accuracy Comparison
(b) Cross-Validation Scores
(c) Per-Class F1-Scores
(d) Training Time Comparison
"""

import numpy as np
import matplotlib.pyplot as plt
import pickle
import time
from pathlib import Path
from sklearn.metrics import f1_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
import xgboost as xgb
import warnings
warnings.filterwarnings('ignore')

# Publication settings
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 9

print("Creating Model Performance Comparison...")

# Load data
DATA_DIR = Path("prepared_dataset_v2")
RESULTS_DIR = Path("model_results")
FIGURES_DIR = Path("figures")

X_train = np.load(DATA_DIR / "X_train.npy")
y_train = np.load(DATA_DIR / "y_train.npy")
X_test = np.load(DATA_DIR / "X_test.npy")
y_test = np.load(DATA_DIR / "y_test.npy")

# Load scaler
with open(RESULTS_DIR / "scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

X_train_scaled = scaler.transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Load CV results
with open(RESULTS_DIR / "cv_results.pkl", "rb") as f:
    cv_results = pickle.load(f)

# Load models
with open(RESULTS_DIR / "RandomForest_model.pkl", "rb") as f:
    rf_model = pickle.load(f)
with open(RESULTS_DIR / "XGBoost_model.pkl", "rb") as f:
    xgb_model = pickle.load(f)
with open(RESULTS_DIR / "SVM_model.pkl", "rb") as f:
    svm_model = pickle.load(f)

models = {
    'RF': rf_model,
    'XGBoost': xgb_model,
    'SVM': svm_model
}

class_names = ['Typical', 'ASD', 'Severe']
model_names = ['RF', 'XGBoost', 'SVM']

# ============================================================================
# COMPUTE METRICS
# ============================================================================

print("  Computing metrics for all models...")

# Test accuracies
test_accuracies = {}
per_class_f1 = {}

for name, model in models.items():
    y_pred = model.predict(X_test_scaled)
    acc = np.mean(y_pred == y_test)
    test_accuracies[name] = acc
    
    # Per-class F1
    f1_scores = f1_score(y_test, y_pred, average=None, labels=[0, 1, 2], zero_division=0)
    per_class_f1[name] = f1_scores

# ============================================================================
# MEASURE TRAINING TIME
# ============================================================================

print("  Measuring training time...")

training_times = {}

# Random Forest
start = time.time()
rf_temp = RandomForestClassifier(n_estimators=200, max_depth=15, 
                                 min_samples_split=10, min_samples_leaf=4,
                                 random_state=42, n_jobs=-1)
rf_temp.fit(X_train_scaled, y_train)
training_times['RF'] = time.time() - start

# XGBoost
start = time.time()
xgb_temp = xgb.XGBClassifier(n_estimators=200, max_depth=6, learning_rate=0.05,
                             random_state=42, use_label_encoder=False, 
                             eval_metric='mlogloss')
xgb_temp.fit(X_train_scaled, y_train, verbose=False)
training_times['XGBoost'] = time.time() - start

# SVM
start = time.time()
svm_temp = SVC(C=1.0, kernel='rbf', random_state=42)
svm_temp.fit(X_train_scaled, y_train)
training_times['SVM'] = time.time() - start

# ============================================================================
# CREATE FIGURE
# ============================================================================

fig = plt.figure(figsize=(14, 10))
gs = fig.add_gridspec(2, 2, hspace=0.3, wspace=0.3)

colors = ['#2E86AB', '#F77F00', '#06A77D']

# ============================================================================
# PANEL A: TEST ACCURACY COMPARISON
# ============================================================================

print("  [1/4] Creating test accuracy comparison...")

ax1 = fig.add_subplot(gs[0, 0])

models_list = list(test_accuracies.keys())
accuracies = list(test_accuracies.values())

bars = ax1.bar(models_list, accuracies, color=colors, alpha=0.8, edgecolor='black', linewidth=1.5)

ax1.set_ylabel('Test Accuracy', fontweight='bold')
ax1.set_ylim([0, 1.0])
ax1.grid(axis='y', alpha=0.3, linestyle='--')
ax1.set_title('(a) Test Accuracy Comparison', fontweight='bold', loc='left', pad=10)

# Add values on bars
for bar, acc in zip(bars, accuracies):
    height = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2., height + 0.02,
            f'{acc:.3f}', ha='center', va='bottom', fontsize=10, fontweight='bold')

# ============================================================================
# PANEL B: CROSS-VALIDATION SCORES
# ============================================================================

print("  [2/4] Creating cross-validation comparison...")

ax2 = fig.add_subplot(gs[0, 1])

cv_data = [cv_results['RandomForest'], cv_results['XGBoost'], cv_results['SVM']]
positions = [1, 2, 3]

bp = ax2.boxplot(cv_data, positions=positions, widths=0.6, patch_artist=True,
                 labels=['RF', 'XGBoost', 'SVM'],
                 boxprops=dict(linewidth=1.5),
                 medianprops=dict(linewidth=2, color='red'),
                 whiskerprops=dict(linewidth=1.5),
                 capprops=dict(linewidth=1.5))

for patch, color in zip(bp['boxes'], colors):
    patch.set_facecolor(color)
    patch.set_alpha(0.7)

ax2.set_ylabel('Cross-Validation Accuracy', fontweight='bold')
ax2.set_ylim([0.5, 1.0])
ax2.grid(axis='y', alpha=0.3, linestyle='--')
ax2.set_title('(b) 5-Fold Cross-Validation Scores', fontweight='bold', loc='left', pad=10)

# Add mean values
for i, data in enumerate(cv_data):
    mean_val = np.mean(data)
    ax2.text(i+1, mean_val, f'{mean_val:.3f}', ha='center', va='bottom', 
            fontsize=9, fontweight='bold', bbox=dict(boxstyle='round', 
            facecolor='white', alpha=0.8))

# ============================================================================
# PANEL C: PER-CLASS F1-SCORES
# ============================================================================

print("  [3/4] Creating per-class F1-scores...")

ax3 = fig.add_subplot(gs[1, 0])

x = np.arange(len(class_names))
width = 0.25

for i, (model_name, color) in enumerate(zip(model_names, colors)):
    f1_scores = per_class_f1[model_name]
    offset = (i - 1) * width
    bars = ax3.bar(x + offset, f1_scores, width, label=model_name, 
                   color=color, alpha=0.8, edgecolor='black', linewidth=1)

ax3.set_ylabel('F1-Score', fontweight='bold')
ax3.set_xticks(x)
ax3.set_xticklabels(class_names, fontweight='bold')
ax3.legend(loc='lower right', frameon=True, fancybox=True, shadow=True)
ax3.set_ylim([0, 1.1])
ax3.grid(axis='y', alpha=0.3, linestyle='--')
ax3.set_title('(c) Per-Class F1-Scores (Test Set)', fontweight='bold', loc='left', pad=10)

# ============================================================================
# PANEL D: TRAINING TIME COMPARISON
# ============================================================================

print("  [4/4] Creating training time comparison...")

ax4 = fig.add_subplot(gs[1, 1])

models_list = list(training_times.keys())
times = list(training_times.values())

bars = ax4.bar(models_list, times, color=colors, alpha=0.8, edgecolor='black', linewidth=1.5)

ax4.set_ylabel('Training Time (seconds)', fontweight='bold')
ax4.grid(axis='y', alpha=0.3, linestyle='--')
ax4.set_title('(d) Training Time Comparison', fontweight='bold', loc='left', pad=10)

# Add values on bars
for bar, t in zip(bars, times):
    height = bar.get_height()
    ax4.text(bar.get_x() + bar.get_width()/2., height + max(times)*0.02,
            f'{t:.2f}s', ha='center', va='bottom', fontsize=10, fontweight='bold')

# Save figure
output_path = FIGURES_DIR / 'Model_Performance_Comparison.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight')
plt.close()

print(f"\n✅ Figure saved: {output_path}")
print(f"   Size: {output_path.stat().st_size / 1024:.1f} KB")
print(f"   Resolution: 300 DPI")
print(f"   Panels: 4 (a, b, c, d)")

# Print summary
print(f"\n📊 SUMMARY:")
print(f"\nTest Accuracies:")
for name, acc in test_accuracies.items():
    print(f"   {name:10s}: {acc:.3f}")

print(f"\nTraining Times:")
for name, t in training_times.items():
    print(f"   {name:10s}: {t:.2f}s")

print(f"\nPer-Class F1-Scores:")
for name in model_names:
    print(f"   {name}:")
    for i, class_name in enumerate(class_names):
        print(f"      {class_name:10s}: {per_class_f1[name][i]:.3f}")

