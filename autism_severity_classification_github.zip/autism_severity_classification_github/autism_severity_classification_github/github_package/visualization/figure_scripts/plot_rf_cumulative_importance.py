#!/usr/bin/env python3
"""
Random Forest - Cumulative Feature Importance
Shows how test accuracy changes with number of top features used
"""

import numpy as np
import matplotlib.pyplot as plt
import pickle
from pathlib import Path
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import warnings
warnings.filterwarnings('ignore')

# Publication settings
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 9

print("Creating Cumulative Feature Importance...")

# Load data
DATA_DIR = Path("prepared_dataset_v2")
RESULTS_DIR = Path("model_results")
FIGURES_DIR = Path("figures")

X_train = np.load(DATA_DIR / "X_train.npy")
y_train = np.load(DATA_DIR / "y_train.npy")
X_test = np.load(DATA_DIR / "X_test.npy")
y_test = np.load(DATA_DIR / "y_test.npy")

# Load scaler
with open(RESULTS_DIR / "scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

X_train_scaled = scaler.transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Load column names
with open(DATA_DIR / "column_names.txt", "r") as f:
    column_names = f.read().splitlines()

print("  Training Random Forest to get feature importances...")

# Train RF to get feature importances
rf = RandomForestClassifier(
    n_estimators=200,
    max_depth=15,
    min_samples_split=10,
    min_samples_leaf=4,
    random_state=42,
    n_jobs=-1
)
rf.fit(X_train_scaled, y_train)

# Get feature importances
importances = rf.feature_importances_
indices = np.argsort(importances)[::-1]

print("  Computing accuracy with top N features...")

# Test with different numbers of top features
n_features_range = [1, 2, 3, 5, 10, 15, 20, 30, 50, 75, 100, 150, 200, 300, 463]
accuracies = []
cumulative_importances = []

for n_features in n_features_range:
    # Select top N features
    top_indices = indices[:n_features]
    X_train_subset = X_train_scaled[:, top_indices]
    X_test_subset = X_test_scaled[:, top_indices]
    
    # Train model with subset
    rf_subset = RandomForestClassifier(
        n_estimators=200,
        max_depth=15,
        min_samples_split=10,
        min_samples_leaf=4,
        random_state=42,
        n_jobs=-1
    )
    rf_subset.fit(X_train_subset, y_train)
    
    # Test accuracy
    y_pred = rf_subset.predict(X_test_subset)
    acc = accuracy_score(y_test, y_pred)
    accuracies.append(acc)
    
    # Cumulative importance
    cum_imp = np.sum(importances[top_indices])
    cumulative_importances.append(cum_imp)
    
    print(f"    Top {n_features:3d} features: Accuracy={acc:.3f}, Cumulative Importance={cum_imp:.3f}")

# Create figure
fig, ax1 = plt.subplots(figsize=(12, 6))

# Plot accuracy
color1 = '#2E86AB'
ax1.plot(n_features_range, accuracies, 'o-', color=color1, 
         linewidth=2.5, markersize=8, label='Test Accuracy')
ax1.set_xlabel('Number of Top Features', fontweight='bold')
ax1.set_ylabel('Test Accuracy', fontweight='bold', color=color1)
ax1.tick_params(axis='y', labelcolor=color1)
ax1.set_ylim([0, 1.05])
ax1.grid(alpha=0.3, linestyle='--')

# Plot cumulative importance on secondary y-axis
ax2 = ax1.twinx()
color2 = '#F77F00'
ax2.plot(n_features_range, cumulative_importances, 's-', color=color2, 
         linewidth=2.5, markersize=8, label='Cumulative Importance', alpha=0.7)
ax2.set_ylabel('Cumulative Feature Importance', fontweight='bold', color=color2)
ax2.tick_params(axis='y', labelcolor=color2)
ax2.set_ylim([0, 1.05])

# Mark optimal point (highest accuracy)
optimal_idx = np.argmax(accuracies)
optimal_n = n_features_range[optimal_idx]
optimal_acc = accuracies[optimal_idx]

ax1.axvline(x=optimal_n, color='red', linestyle='--', linewidth=2, alpha=0.5)
ax1.plot(optimal_n, optimal_acc, 'r*', markersize=20, 
         label=f'Optimal: {optimal_n} features (Acc={optimal_acc:.3f})')

# Mark 90% importance threshold
threshold_90_idx = np.argmin(np.abs(np.array(cumulative_importances) - 0.9))
threshold_90_n = n_features_range[threshold_90_idx]
ax1.axvline(x=threshold_90_n, color='orange', linestyle=':', linewidth=2, alpha=0.5,
           label=f'90% Importance: {threshold_90_n} features')

# Combine legends
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, 
          loc='lower right', frameon=True, fancybox=True, shadow=True)

ax1.set_title('Cumulative Feature Importance vs Test Accuracy', 
             fontweight='bold', pad=15)

# Save figure
output_path = FIGURES_DIR / 'RandomForest_CumulativeImportance.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight')
plt.close()

print(f"\n✅ Figure saved: {output_path}")
print(f"   Size: {output_path.stat().st_size / 1024:.1f} KB")
print(f"   Resolution: 300 DPI")

print(f"\n📊 Key Findings:")
print(f"   Optimal features: {optimal_n} (Accuracy: {optimal_acc:.3f})")
print(f"   90% importance: {threshold_90_n} features")
print(f"   All features (463): Accuracy: {accuracies[-1]:.3f}")

