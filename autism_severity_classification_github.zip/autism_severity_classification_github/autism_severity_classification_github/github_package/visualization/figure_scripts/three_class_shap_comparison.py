#!/usr/bin/env python3
"""
Three-Class SHAP Comparison Analysis
Compares Typical Development, Moderate ASD, and Severe ASD SHAP analyses
"""

import pandas as pd
import numpy as np
from pathlib import Path

print("="*80)
print("THREE-CLASS SHAP COMPARISON ANALYSIS")
print("="*80)

# Load the three corrected SHAP CSV files
print("\n1. Loading SHAP CSV files...")
typical_df = pd.read_csv("/home/ubuntu/figures/typical_feature_importance_shap.csv")
moderate_df = pd.read_csv("/home/ubuntu/upload/moderate_asd_feature_importance_shap.csv")
severe_df = pd.read_csv("/home/ubuntu/upload/severe_asd_feature_importance_shap.csv")

print(f"   Typical: {len(typical_df)} features")
print(f"   Moderate: {len(moderate_df)} features")
print(f"   Severe: {len(severe_df)} features")

# Rename columns for consistency
typical_df.columns = ['feature', 'shap_value']
moderate_df.columns = ['feature', 'shap_value']
severe_df.columns = ['feature', 'shap_value']

# Get top 20 for each class
typical_top20 = typical_df.head(20)
moderate_top20 = moderate_df.head(20)
severe_top20 = severe_df.head(20)

print("\n2. Top 5 biomarkers for each class:")
print("\nTypical Development:")
for i, row in typical_df.head(5).iterrows():
    print(f"   {i+1}. {row['feature']}: {row['shap_value']:.4f}")

print("\nModerate ASD:")
for i, row in moderate_df.head(5).iterrows():
    print(f"   {i+1}. {row['feature']}: {row['shap_value']:.4f}")

print("\nSevere ASD:")
for i, row in severe_df.head(5).iterrows():
    print(f"   {i+1}. {row['feature']}: {row['shap_value']:.4f}")

# Analyze axis distribution (X, Y, Z)
def count_axis(df, top_n=20):
    """Count features by axis in top N"""
    top_features = df.head(top_n)['feature'].values
    x_count = sum(1 for f in top_features if f.endswith('_X'))
    y_count = sum(1 for f in top_features if f.endswith('_Y'))
    z_count = sum(1 for f in top_features if f.endswith('_Z'))
    return x_count, y_count, z_count

print("\n3. Axis distribution in top 20:")
typical_x, typical_y, typical_z = count_axis(typical_df, 20)
moderate_x, moderate_y, moderate_z = count_axis(moderate_df, 20)
severe_x, severe_y, severe_z = count_axis(severe_df, 20)

print(f"   Typical:  X={typical_x} ({typical_x/20*100:.0f}%), Y={typical_y} ({typical_y/20*100:.0f}%), Z={typical_z} ({typical_z/20*100:.0f}%)")
print(f"   Moderate: X={moderate_x} ({moderate_x/20*100:.0f}%), Y={moderate_y} ({moderate_y/20*100:.0f}%), Z={moderate_z} ({moderate_z/20*100:.0f}%)")
print(f"   Severe:   X={severe_x} ({severe_x/20*100:.0f}%), Y={severe_y} ({severe_y/20*100:.0f}%), Z={severe_z} ({severe_z/20*100:.0f}%)")

# Analyze feature types
def classify_feature_type(feature_name):
    """Classify feature into categories"""
    if feature_name.startswith('Rom'):
        return 'ROM'
    elif feature_name.startswith('Fo') or feature_name.startswith('El') or feature_name.startswith('An'):
        return 'Distance'
    elif feature_name.startswith('Wrist') or feature_name.startswith('Knee') or feature_name.startswith('Hand') or feature_name.startswith('Hip'):
        return 'Position'
    else:
        return 'Other'

def count_feature_types(df, top_n=20):
    """Count feature types in top N"""
    top_features = df.head(top_n)['feature'].values
    rom_count = sum(1 for f in top_features if classify_feature_type(f) == 'ROM')
    distance_count = sum(1 for f in top_features if classify_feature_type(f) == 'Distance')
    position_count = sum(1 for f in top_features if classify_feature_type(f) == 'Position')
    other_count = sum(1 for f in top_features if classify_feature_type(f) == 'Other')
    return rom_count, distance_count, position_count, other_count

print("\n4. Feature type distribution in top 20:")
typical_rom, typical_dist, typical_pos, typical_other = count_feature_types(typical_df, 20)
moderate_rom, moderate_dist, moderate_pos, moderate_other = count_feature_types(moderate_df, 20)
severe_rom, severe_dist, severe_pos, severe_other = count_feature_types(severe_df, 20)

print(f"   Typical:  ROM={typical_rom} ({typical_rom/20*100:.0f}%), Distance={typical_dist} ({typical_dist/20*100:.0f}%), Position={typical_pos} ({typical_pos/20*100:.0f}%), Other={typical_other}")
print(f"   Moderate: ROM={moderate_rom} ({moderate_rom/20*100:.0f}%), Distance={moderate_dist} ({moderate_dist/20*100:.0f}%), Position={moderate_pos} ({moderate_pos/20*100:.0f}%), Other={moderate_other}")
print(f"   Severe:   ROM={severe_rom} ({severe_rom/20*100:.0f}%), Distance={severe_dist} ({severe_dist/20*100:.0f}%), Position={severe_pos} ({severe_pos/20*100:.0f}%), Other={severe_other}")

# Find common features in top 5
print("\n5. Common features in top 5:")
typical_top5 = set(typical_df.head(5)['feature'].values)
moderate_top5 = set(moderate_df.head(5)['feature'].values)
severe_top5 = set(severe_df.head(5)['feature'].values)

severe_moderate = severe_top5.intersection(moderate_top5)
severe_typical = severe_top5.intersection(typical_top5)
moderate_typical = moderate_top5.intersection(typical_top5)
all_three = severe_top5.intersection(moderate_top5).intersection(typical_top5)

print(f"   Severe ∩ Moderate: {severe_moderate} ({len(severe_moderate)}/5)")
print(f"   Severe ∩ Typical: {severe_typical} ({len(severe_typical)}/5)")
print(f"   Moderate ∩ Typical: {moderate_typical} ({len(moderate_typical)}/5)")
print(f"   All three: {all_three} ({len(all_three)}/5)")

# Find common features in top 20
print("\n6. Common features in top 20:")
typical_top20_set = set(typical_df.head(20)['feature'].values)
moderate_top20_set = set(moderate_df.head(20)['feature'].values)
severe_top20_set = set(severe_df.head(20)['feature'].values)

severe_moderate_20 = severe_top20_set.intersection(moderate_top20_set)
severe_typical_20 = severe_top20_set.intersection(typical_top20_set)
moderate_typical_20 = moderate_top20_set.intersection(typical_top20_set)
all_three_20 = severe_top20_set.intersection(moderate_top20_set).intersection(typical_top20_set)

print(f"   Severe ∩ Moderate: {len(severe_moderate_20)}/20")
print(f"   Severe ∩ Typical: {len(severe_typical_20)}/20")
print(f"   Moderate ∩ Typical: {len(moderate_typical_20)}/20")
print(f"   All three: {len(all_three_20)}/20")

# Create comparison table
print("\n7. Creating comparison tables...")

# Main comparison table
comparison_data = {
    'Metric': [
        'Top 1 Biomarker',
        'Top 1 SHAP Value',
        'Top 5 Average SHAP',
        'Y-Axis Ratio (Top 20)',
        'X-Axis Ratio (Top 20)',
        'Position Features (Top 20)',
        'Distance Features (Top 20)',
        'ROM Features (Top 20)',
    ],
    'Typical': [
        typical_df.iloc[0]['feature'],
        f"{typical_df.iloc[0]['shap_value']:.4f}",
        f"{typical_df.head(5)['shap_value'].mean():.4f}",
        f"{typical_y}/20 ({typical_y/20*100:.0f}%)",
        f"{typical_x}/20 ({typical_x/20*100:.0f}%)",
        f"{typical_pos}/20 ({typical_pos/20*100:.0f}%)",
        f"{typical_dist}/20 ({typical_dist/20*100:.0f}%)",
        f"{typical_rom}/20 ({typical_rom/20*100:.0f}%)",
    ],
    'Moderate ASD': [
        moderate_df.iloc[0]['feature'],
        f"{moderate_df.iloc[0]['shap_value']:.4f}",
        f"{moderate_df.head(5)['shap_value'].mean():.4f}",
        f"{moderate_y}/20 ({moderate_y/20*100:.0f}%)",
        f"{moderate_x}/20 ({moderate_x/20*100:.0f}%)",
        f"{moderate_pos}/20 ({moderate_pos/20*100:.0f}%)",
        f"{moderate_dist}/20 ({moderate_dist/20*100:.0f}%)",
        f"{moderate_rom}/20 ({moderate_rom/20*100:.0f}%)",
    ],
    'Severe ASD': [
        severe_df.iloc[0]['feature'],
        f"{severe_df.iloc[0]['shap_value']:.4f}",
        f"{severe_df.head(5)['shap_value'].mean():.4f}",
        f"{severe_y}/20 ({severe_y/20*100:.0f}%)",
        f"{severe_x}/20 ({severe_x/20*100:.0f}%)",
        f"{severe_pos}/20 ({severe_pos/20*100:.0f}%)",
        f"{severe_dist}/20 ({severe_dist/20*100:.0f}%)",
        f"{severe_rom}/20 ({severe_rom/20*100:.0f}%)",
    ],
    'Trend': [
        'Different motor patterns',
        'Similar range',
        'Similar range',
        f'Severity ↑ → Decreasing ({typical_y/20*100:.0f}%→{moderate_y/20*100:.0f}%→{severe_y/20*100:.0f}%)',
        f'Severity ↑ → Increasing ({typical_x/20*100:.0f}%→{moderate_x/20*100:.0f}%→{severe_x/20*100:.0f}%)',
        f'Severity ↑ → Decreasing ({typical_pos/20*100:.0f}%→{moderate_pos/20*100:.0f}%→{severe_pos/20*100:.0f}%)',
        f'Severity ↑ → Increasing ({typical_dist/20*100:.0f}%→{moderate_dist/20*100:.0f}%→{severe_dist/20*100:.0f}%)',
        f'ROM features ({typical_rom/20*100:.0f}%→{moderate_rom/20*100:.0f}%→{severe_rom/20*100:.0f}%)',
    ]
}

comparison_df = pd.DataFrame(comparison_data)
comparison_df.to_csv('/home/ubuntu/figures/three_class_main_comparison.csv', index=False)
print(f"   Saved: three_class_main_comparison.csv")

# Top 5 detailed comparison
top5_data = []
for i in range(5):
    top5_data.append({
        'Rank': i+1,
        'Typical_Feature': typical_df.iloc[i]['feature'],
        'Typical_SHAP': f"{typical_df.iloc[i]['shap_value']:.4f}",
        'Moderate_Feature': moderate_df.iloc[i]['feature'],
        'Moderate_SHAP': f"{moderate_df.iloc[i]['shap_value']:.4f}",
        'Severe_Feature': severe_df.iloc[i]['feature'],
        'Severe_SHAP': f"{severe_df.iloc[i]['shap_value']:.4f}",
    })

top5_df = pd.DataFrame(top5_data)
top5_df.to_csv('/home/ubuntu/figures/three_class_top5_detailed.csv', index=False)
print(f"   Saved: three_class_top5_detailed.csv")

# Common features table
common_features_data = {
    'Comparison': [
        'Severe ∩ Moderate (Top 5)',
        'Severe ∩ Typical (Top 5)',
        'Moderate ∩ Typical (Top 5)',
        'All Three (Top 5)',
        'Severe ∩ Moderate (Top 20)',
        'Severe ∩ Typical (Top 20)',
        'Moderate ∩ Typical (Top 20)',
        'All Three (Top 20)',
    ],
    'Count': [
        f"{len(severe_moderate)}/5",
        f"{len(severe_typical)}/5",
        f"{len(moderate_typical)}/5",
        f"{len(all_three)}/5",
        f"{len(severe_moderate_20)}/20",
        f"{len(severe_typical_20)}/20",
        f"{len(moderate_typical_20)}/20",
        f"{len(all_three_20)}/20",
    ],
    'Percentage': [
        f"{len(severe_moderate)/5*100:.0f}%",
        f"{len(severe_typical)/5*100:.0f}%",
        f"{len(moderate_typical)/5*100:.0f}%",
        f"{len(all_three)/5*100:.0f}%",
        f"{len(severe_moderate_20)/20*100:.0f}%",
        f"{len(severe_typical_20)/20*100:.0f}%",
        f"{len(moderate_typical_20)/20*100:.0f}%",
        f"{len(all_three_20)/20*100:.0f}%",
    ],
    'Features': [
        ', '.join(severe_moderate) if severe_moderate else 'None',
        ', '.join(severe_typical) if severe_typical else 'None',
        ', '.join(moderate_typical) if moderate_typical else 'None',
        ', '.join(all_three) if all_three else 'None',
        f"{len(severe_moderate_20)} features",
        f"{len(severe_typical_20)} features",
        f"{len(moderate_typical_20)} features",
        f"{len(all_three_20)} features",
    ]
}

common_df = pd.DataFrame(common_features_data)
common_df.to_csv('/home/ubuntu/figures/three_class_common_features.csv', index=False)
print(f"   Saved: three_class_common_features.csv")

print("\n" + "="*80)
print("COMPARISON ANALYSIS COMPLETED!")
print("="*80)
print("\nKey Findings:")
print(f"1. Y-axis features: Typical {typical_y/20*100:.0f}% → Moderate {moderate_y/20*100:.0f}% → Severe {severe_y/20*100:.0f}% (Decreasing)")
print(f"2. X-axis features: Typical {typical_x/20*100:.0f}% → Moderate {moderate_x/20*100:.0f}% → Severe {severe_x/20*100:.0f}% (Increasing)")
print(f"3. Position features: Typical {typical_pos/20*100:.0f}% → Moderate {moderate_pos/20*100:.0f}% → Severe {severe_pos/20*100:.0f}% (Decreasing)")
print(f"4. Distance features: Typical {typical_dist/20*100:.0f}% → Moderate {moderate_dist/20*100:.0f}% → Severe {severe_dist/20*100:.0f}% (Increasing)")
print(f"5. Common features (Top 5): Severe-Moderate {len(severe_moderate)}/5, Severe-Typical {len(severe_typical)}/5, Moderate-Typical {len(moderate_typical)}/5")

print("\n✓ Analysis complete!")

