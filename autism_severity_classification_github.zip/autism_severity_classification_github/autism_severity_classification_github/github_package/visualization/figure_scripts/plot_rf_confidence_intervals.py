#!/usr/bin/env python3
"""
Random Forest - Confidence Intervals (Test Set)
(a) Overall Metrics with 95% Confidence Intervals
(b) Per-Class Metrics with 95% Confidence Intervals
"""

import numpy as np
import matplotlib.pyplot as plt
import pickle
from pathlib import Path
from sklearn.metrics import precision_score, recall_score, f1_score
import warnings
warnings.filterwarnings('ignore')

# Publication settings
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 9

print("Creating Random Forest Confidence Intervals (Test Set)...")

# Load data
DATA_DIR = Path("prepared_dataset_v2")
RESULTS_DIR = Path("model_results")
FIGURES_DIR = Path("figures")

X_test = np.load(DATA_DIR / "X_test.npy")
y_test = np.load(DATA_DIR / "y_test.npy")

# Load scaler and model
with open(RESULTS_DIR / "scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

with open(RESULTS_DIR / "RandomForest_model.pkl", "rb") as f:
    rf_model = pickle.load(f)

X_test_scaled = scaler.transform(X_test)
y_pred = rf_model.predict(X_test_scaled)

class_names = ['Typical', 'ASD', 'Severe']

# ============================================================================
# BOOTSTRAP CONFIDENCE INTERVALS
# ============================================================================

def bootstrap_ci(y_true, y_pred, metric_func, n_bootstrap=1000, ci=95):
    """Calculate bootstrap confidence intervals"""
    scores = []
    n_samples = len(y_true)
    
    np.random.seed(42)
    for _ in range(n_bootstrap):
        indices = np.random.choice(n_samples, n_samples, replace=True)
        score = metric_func(y_true[indices], y_pred[indices])
        scores.append(score)
    
    scores = np.array(scores)
    alpha = (100 - ci) / 2
    ci_lower = np.percentile(scores, alpha)
    ci_upper = np.percentile(scores, 100 - alpha)
    mean = np.mean(scores)
    
    return mean, ci_lower, ci_upper

print("  Computing bootstrap confidence intervals (n=1000)...")

# ============================================================================
# PANEL A: OVERALL METRICS
# ============================================================================

print("  [1/2] Overall metrics with CI...")

# Weighted average metrics
overall_metrics = {
    'Precision': lambda y_true, y_pred: precision_score(y_true, y_pred, average='weighted', zero_division=0),
    'Recall': lambda y_true, y_pred: recall_score(y_true, y_pred, average='weighted', zero_division=0),
    'F1-Score': lambda y_true, y_pred: f1_score(y_true, y_pred, average='weighted', zero_division=0)
}

overall_results = {}
for metric_name, metric_func in overall_metrics.items():
    mean, ci_lower, ci_upper = bootstrap_ci(y_test, y_pred, metric_func)
    overall_results[metric_name] = (mean, ci_lower, ci_upper)

# ============================================================================
# PANEL B: PER-CLASS METRICS
# ============================================================================

print("  [2/2] Per-class metrics with CI...")

# Per-class metrics
perclass_results = {class_name: {} for class_name in class_names}

for i, class_name in enumerate(class_names):
    # Binary classification for each class
    y_test_binary = (y_test == i).astype(int)
    y_pred_binary = (y_pred == i).astype(int)
    
    # Precision
    mean, ci_lower, ci_upper = bootstrap_ci(
        y_test_binary, y_pred_binary,
        lambda y_true, y_pred: precision_score(y_true, y_pred, zero_division=0)
    )
    perclass_results[class_name]['Precision'] = (mean, ci_lower, ci_upper)
    
    # Recall
    mean, ci_lower, ci_upper = bootstrap_ci(
        y_test_binary, y_pred_binary,
        lambda y_true, y_pred: recall_score(y_true, y_pred, zero_division=0)
    )
    perclass_results[class_name]['Recall'] = (mean, ci_lower, ci_upper)
    
    # F1-Score
    mean, ci_lower, ci_upper = bootstrap_ci(
        y_test_binary, y_pred_binary,
        lambda y_true, y_pred: f1_score(y_true, y_pred, zero_division=0)
    )
    perclass_results[class_name]['F1-Score'] = (mean, ci_lower, ci_upper)

# ============================================================================
# CREATE FIGURE
# ============================================================================

fig = plt.figure(figsize=(14, 6))
gs = fig.add_gridspec(1, 2, wspace=0.3)

# ============================================================================
# PANEL A: OVERALL METRICS
# ============================================================================

ax1 = fig.add_subplot(gs[0, 0])

metrics = list(overall_results.keys())
means = [overall_results[m][0] for m in metrics]
ci_lowers = [overall_results[m][1] for m in metrics]
ci_uppers = [overall_results[m][2] for m in metrics]
errors_lower = [means[i] - ci_lowers[i] for i in range(len(metrics))]
errors_upper = [ci_uppers[i] - means[i] for i in range(len(metrics))]

x_pos = np.arange(len(metrics))
bars = ax1.bar(x_pos, means, yerr=[errors_lower, errors_upper], 
               capsize=10, color='#2E86AB', alpha=0.8, 
               error_kw={'linewidth': 2, 'ecolor': '#333'})

ax1.set_xticks(x_pos)
ax1.set_xticklabels(metrics, fontweight='bold')
ax1.set_ylabel('Score', fontweight='bold')
ax1.set_ylim([0, 1.1])
ax1.grid(axis='y', alpha=0.3, linestyle='--')
ax1.set_title('(a) Overall Metrics with 95% Confidence Intervals', 
              fontweight='bold', loc='left', pad=10)

# Add values with CI
for i, (m, lower, upper) in enumerate(zip(means, ci_lowers, ci_uppers)):
    ax1.text(i, m + errors_upper[i] + 0.03, 
            f'{m:.3f}\n[{lower:.3f}, {upper:.3f}]',
            ha='center', va='bottom', fontsize=9, fontweight='bold')

# ============================================================================
# PANEL B: PER-CLASS METRICS
# ============================================================================

ax2 = fig.add_subplot(gs[0, 1])

metrics = ['Precision', 'Recall', 'F1-Score']
x = np.arange(len(metrics))
width = 0.25

colors = ['#06A77D', '#F77F00', '#D62828']

for i, (class_name, color) in enumerate(zip(class_names, colors)):
    means = [perclass_results[class_name][m][0] for m in metrics]
    ci_lowers = [perclass_results[class_name][m][1] for m in metrics]
    ci_uppers = [perclass_results[class_name][m][2] for m in metrics]
    errors_lower = [means[j] - ci_lowers[j] for j in range(len(metrics))]
    errors_upper = [ci_uppers[j] - means[j] for j in range(len(metrics))]
    
    offset = (i - 1) * width
    bars = ax2.bar(x + offset, means, width, 
                   yerr=[errors_lower, errors_upper],
                   label=class_name, color=color, alpha=0.8,
                   capsize=5, error_kw={'linewidth': 1.5})

ax2.set_ylabel('Score', fontweight='bold')
ax2.set_xticks(x)
ax2.set_xticklabels(metrics, fontweight='bold')
ax2.legend(loc='lower right', frameon=True, fancybox=True, shadow=True)
ax2.set_ylim([0, 1.15])
ax2.grid(axis='y', alpha=0.3, linestyle='--')
ax2.set_title('(b) Per-Class Metrics with 95% Confidence Intervals', 
              fontweight='bold', loc='left', pad=10)

# Save figure
output_path = FIGURES_DIR / 'RandomForest_ConfidenceIntervals.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight')
plt.close()

print(f"\n✅ Figure saved: {output_path}")
print(f"   Size: {output_path.stat().st_size / 1024:.1f} KB")
print(f"   Resolution: 300 DPI")
print(f"   Panels: 2 (a, b)")

# Print results
print(f"\n📊 Overall Metrics (Test Set, n=1000 bootstrap):")
for metric_name, (mean, ci_lower, ci_upper) in overall_results.items():
    print(f"   {metric_name:12s}: {mean:.3f} [95% CI: {ci_lower:.3f}, {ci_upper:.3f}]")

print(f"\n📊 Per-Class Metrics (Test Set, n=1000 bootstrap):")
for class_name in class_names:
    print(f"\n   {class_name}:")
    for metric_name in ['Precision', 'Recall', 'F1-Score']:
        mean, ci_lower, ci_upper = perclass_results[class_name][metric_name]
        print(f"      {metric_name:12s}: {mean:.3f} [95% CI: {ci_lower:.3f}, {ci_upper:.3f}]")

