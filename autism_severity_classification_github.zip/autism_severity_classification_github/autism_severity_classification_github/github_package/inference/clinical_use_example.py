#!/usr/bin/env python3
"""
Clinical Deployment Example for Autism Severity Classification
================================================================

This script demonstrates how to use the trained model in a clinical setting
to classify children based on their 3D gait and body movement data.

Usage:
    python clinical_use_example.py --input patient_data.csv
    python clinical_use_example.py --features feature_vector.npy

Author: Autism Severity Classification Research Team
"""

import numpy as np
import pandas as pd
import pickle
import argparse
import os
import sys
from pathlib import Path

# Class labels mapping
CLASS_LABELS = {
    0: "Typical Development",
    1: "ASD (Autism Spectrum Disorder)",
    2: "Severe ASD"
}

# Severity interpretation
SEVERITY_DESCRIPTION = {
    0: "Normal development - No intervention required",
    1: "Mild to moderate autism - Early intervention recommended",
    2: "Severe autism - Intensive intervention required"
}


def load_model_and_scaler(model_path, scaler_path):
    """
    Load the trained model and scaler from disk.
    
    Parameters:
    -----------
    model_path : str
        Path to the trained model (.pkl file)
    scaler_path : str
        Path to the fitted scaler (.pkl file)
    
    Returns:
    --------
    model : sklearn model
        Trained classification model
    scaler : sklearn.preprocessing.StandardScaler
        Fitted scaler for feature normalization
    """
    try:
        with open(model_path, 'rb') as f:
            model = pickle.load(f)
        print(f"✓ Model loaded from: {model_path}")
        
        with open(scaler_path, 'rb') as f:
            scaler = pickle.load(f)
        print(f"✓ Scaler loaded from: {scaler_path}")
        
        return model, scaler
    except Exception as e:
        print(f"✗ Error loading model or scaler: {e}")
        sys.exit(1)


def preprocess_features(features, scaler):
    """
    Preprocess input features using the fitted scaler.
    
    Parameters:
    -----------
    features : np.ndarray
        Raw feature vector (shape: (463,) or (n_samples, 463))
    scaler : sklearn.preprocessing.StandardScaler
        Fitted scaler
    
    Returns:
    --------
    features_normalized : np.ndarray
        Normalized features ready for prediction
    """
    # Ensure 2D shape
    if features.ndim == 1:
        features = features.reshape(1, -1)
    
    # Normalize
    features_normalized = scaler.transform(features)
    
    return features_normalized


def predict_single_patient(model, scaler, features):
    """
    Predict autism severity for a single patient.
    
    Parameters:
    -----------
    model : sklearn model
        Trained classification model
    scaler : sklearn.preprocessing.StandardScaler
        Fitted scaler
    features : np.ndarray
        Raw feature vector (463 features)
    
    Returns:
    --------
    result : dict
        Dictionary containing prediction results
    """
    # Preprocess
    features_normalized = preprocess_features(features, scaler)
    
    # Predict
    prediction = model.predict(features_normalized)[0]
    probabilities = model.predict_proba(features_normalized)[0]
    
    # Prepare result
    result = {
        'prediction': int(prediction),
        'label': CLASS_LABELS[prediction],
        'severity': SEVERITY_DESCRIPTION[prediction],
        'confidence': float(probabilities[prediction]),
        'probabilities': {
            'Typical': float(probabilities[0]),
            'ASD': float(probabilities[1]),
            'Severe': float(probabilities[2])
        }
    }
    
    return result


def predict_batch(model, scaler, features_array, patient_ids=None):
    """
    Predict autism severity for multiple patients.
    
    Parameters:
    -----------
    model : sklearn model
        Trained classification model
    scaler : sklearn.preprocessing.StandardScaler
        Fitted scaler
    features_array : np.ndarray
        Feature matrix (n_patients, 463)
    patient_ids : list, optional
        List of patient IDs
    
    Returns:
    --------
    results : pd.DataFrame
        DataFrame containing predictions for all patients
    """
    # Preprocess
    features_normalized = preprocess_features(features_array, scaler)
    
    # Predict
    predictions = model.predict(features_normalized)
    probabilities = model.predict_proba(features_normalized)
    
    # Create results dataframe
    if patient_ids is None:
        patient_ids = [f"Patient_{i+1}" for i in range(len(predictions))]
    
    results = pd.DataFrame({
        'Patient_ID': patient_ids,
        'Prediction': [CLASS_LABELS[p] for p in predictions],
        'Severity_Level': predictions,
        'Confidence': [probabilities[i, p] for i, p in enumerate(predictions)],
        'Prob_Typical': probabilities[:, 0],
        'Prob_ASD': probabilities[:, 1],
        'Prob_Severe': probabilities[:, 2],
        'Clinical_Recommendation': [SEVERITY_DESCRIPTION[p] for p in predictions]
    })
    
    return results


def print_clinical_report(result, patient_id="Unknown"):
    """
    Print a formatted clinical report for a single patient.
    
    Parameters:
    -----------
    result : dict
        Prediction result dictionary
    patient_id : str
        Patient identifier
    """
    print("\n" + "="*70)
    print("AUTISM SEVERITY CLASSIFICATION - CLINICAL REPORT")
    print("="*70)
    print(f"\nPatient ID: {patient_id}")
    print(f"\nPrediction: {result['label']}")
    print(f"Confidence: {result['confidence']:.1%}")
    print(f"\nClinical Interpretation:")
    print(f"  {result['severity']}")
    print(f"\nProbability Distribution:")
    print(f"  • Typical Development: {result['probabilities']['Typical']:.1%}")
    print(f"  • ASD (Mild-Moderate): {result['probabilities']['ASD']:.1%}")
    print(f"  • Severe ASD:          {result['probabilities']['Severe']:.1%}")
    print("\n" + "="*70)
    
    # Warning for low confidence
    if result['confidence'] < 0.7:
        print("\n⚠ WARNING: Low confidence prediction. Consider additional assessment.")
        print("="*70)


def main():
    """Main function for clinical deployment."""
    parser = argparse.ArgumentParser(
        description="Clinical Autism Severity Classification System"
    )
    parser.add_argument(
        '--input',
        type=str,
        help='Input file: CSV with 463 features or NPY array'
    )
    parser.add_argument(
        '--model',
        type=str,
        default='../models/trained_models/final_model.pkl',
        help='Path to trained model (default: ../models/trained_models/final_model.pkl)'
    )
    parser.add_argument(
        '--scaler',
        type=str,
        default='../models/trained_models/scaler.pkl',
        help='Path to fitted scaler (default: ../models/trained_models/scaler.pkl)'
    )
    parser.add_argument(
        '--output',
        type=str,
        help='Output CSV file for batch predictions (optional)'
    )
    parser.add_argument(
        '--patient-id',
        type=str,
        default='Unknown',
        help='Patient ID for single prediction'
    )
    
    args = parser.parse_args()
    
    # Get script directory for relative paths
    script_dir = Path(__file__).parent
    model_path = script_dir / args.model
    scaler_path = script_dir / args.scaler
    
    # Load model and scaler
    print("\n" + "="*70)
    print("LOADING MODEL AND SCALER")
    print("="*70)
    model, scaler = load_model_and_scaler(model_path, scaler_path)
    
    # If no input provided, run example
    if args.input is None:
        print("\n" + "="*70)
        print("RUNNING EXAMPLE PREDICTION")
        print("="*70)
        print("\nNo input file provided. Running with example data...")
        
        # Create example feature vector (463 features, all zeros as placeholder)
        example_features = np.random.randn(463) * 0.5  # Random example
        
        result = predict_single_patient(model, scaler, example_features)
        print_clinical_report(result, patient_id="EXAMPLE_001")
        
        print("\n" + "="*70)
        print("To use with real data:")
        print("  python clinical_use_example.py --input patient_data.csv")
        print("  python clinical_use_example.py --input features.npy --patient-id P001")
        print("="*70 + "\n")
        
        return
    
    # Load input data
    print("\n" + "="*70)
    print("LOADING INPUT DATA")
    print("="*70)
    
    if args.input.endswith('.npy'):
        # Load numpy array
        features = np.load(args.input)
        print(f"✓ Loaded features from: {args.input}")
        print(f"  Shape: {features.shape}")
        
        if features.ndim == 1:
            # Single patient
            result = predict_single_patient(model, scaler, features)
            print_clinical_report(result, patient_id=args.patient_id)
        else:
            # Multiple patients
            results = predict_batch(model, scaler, features)
            print(f"\n✓ Predictions completed for {len(results)} patients")
            print(results)
            
            if args.output:
                results.to_csv(args.output, index=False)
                print(f"\n✓ Results saved to: {args.output}")
    
    elif args.input.endswith('.csv'):
        # Load CSV
        df = pd.read_csv(args.input)
        print(f"✓ Loaded data from: {args.input}")
        print(f"  Shape: {df.shape}")
        
        # Check if patient IDs exist
        if 'patient_id' in df.columns or 'Patient_ID' in df.columns:
            patient_ids = df.get('patient_id', df.get('Patient_ID')).tolist()
            features = df.drop(columns=['patient_id', 'Patient_ID'], errors='ignore').values
        else:
            patient_ids = None
            features = df.values
        
        if features.shape[0] == 1:
            # Single patient
            result = predict_single_patient(model, scaler, features[0])
            pid = patient_ids[0] if patient_ids else args.patient_id
            print_clinical_report(result, patient_id=pid)
        else:
            # Multiple patients
            results = predict_batch(model, scaler, features, patient_ids)
            print(f"\n✓ Predictions completed for {len(results)} patients")
            print(results)
            
            if args.output:
                results.to_csv(args.output, index=False)
                print(f"\n✓ Results saved to: {args.output}")
    
    else:
        print(f"✗ Unsupported file format: {args.input}")
        print("  Supported formats: .npy, .csv")
        sys.exit(1)


if __name__ == "__main__":
    main()

