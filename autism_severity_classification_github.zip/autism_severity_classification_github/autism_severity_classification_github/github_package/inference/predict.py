#!/usr/bin/env python3
"""
Clinical Prediction Script
For real-world use with new patient data
"""

import numpy as np
import pickle
from pathlib import Path
import sys

class AutismSeverityPredictor:
    """
    Autism Severity Classifier for Clinical Use
    
    Classes:
        0 = Typical (Normal development, no autism)
        1 = ASD (Autism Spectrum Disorder, mild-moderate)
        2 = Severe (Severe autism, high support needs)
    """
    
    def __init__(self, model_path="model_results/final_model.pkl", 
                 scaler_path="model_results/scaler.pkl"):
        """Load trained model and scaler"""
        
        self.model_path = Path(model_path)
        self.scaler_path = Path(scaler_path)
        
        # Load model
        with open(self.model_path, "rb") as f:
            self.model = pickle.load(f)
        
        # Load scaler
        with open(self.scaler_path, "rb") as f:
            self.scaler = pickle.load(f)
        
        self.class_names = ['Typical', 'ASD', 'Severe']
        
        print("✅ Model loaded successfully!")
        print(f"   Model: {self.model_path}")
        print(f"   Scaler: {self.scaler_path}")
    
    def predict(self, features):
        """
        Predict autism severity for new patient
        
        Args:
            features: numpy array of shape (463,) or (n_samples, 463)
        
        Returns:
            dict with prediction, probability, and interpretation
        """
        
        # Ensure 2D array
        if features.ndim == 1:
            features = features.reshape(1, -1)
        
        # Check feature count
        if features.shape[1] != 463:
            raise ValueError(f"Expected 463 features, got {features.shape[1]}")
        
        # Normalize
        features_scaled = self.scaler.transform(features)
        
        # Predict
        prediction = self.model.predict(features_scaled)[0]
        probabilities = self.model.predict_proba(features_scaled)[0]
        
        # Interpretation
        result = {
            'prediction': int(prediction),
            'class_name': self.class_names[prediction],
            'probabilities': {
                'Typical': float(probabilities[0]),
                'ASD': float(probabilities[1]),
                'Severe': float(probabilities[2])
            },
            'confidence': float(probabilities[prediction]),
            'interpretation': self._interpret(prediction, probabilities)
        }
        
        return result
    
    def _interpret(self, prediction, probabilities):
        """Generate clinical interpretation"""
        
        confidence = probabilities[prediction]
        class_name = self.class_names[prediction]
        
        if prediction == 0:  # Typical
            if confidence > 0.8:
                return f"Low autism risk. Child shows typical development patterns (confidence: {confidence:.1%})."
            else:
                return f"Likely typical development, but consider follow-up assessment (confidence: {confidence:.1%})."
        
        elif prediction == 1:  # ASD
            if confidence > 0.8:
                return f"Autism spectrum disorder detected. Recommend comprehensive diagnostic evaluation (confidence: {confidence:.1%})."
            else:
                return f"Possible ASD. Further clinical assessment recommended (confidence: {confidence:.1%})."
        
        else:  # Severe
            if confidence > 0.8:
                return f"High autism severity detected. Immediate intervention recommended (confidence: {confidence:.1%})."
            else:
                return f"Significant autism indicators. Urgent clinical evaluation needed (confidence: {confidence:.1%})."
    
    def batch_predict(self, features_array):
        """Predict for multiple patients"""
        
        results = []
        for i, features in enumerate(features_array):
            result = self.predict(features)
            result['patient_id'] = i + 1
            results.append(result)
        
        return results
    
    def print_result(self, result):
        """Pretty print prediction result"""
        
        print("\n" + "=" * 60)
        print("AUTISM SEVERITY PREDICTION RESULT")
        print("=" * 60)
        print(f"\n🎯 Prediction: {result['class_name']}")
        print(f"   Confidence: {result['confidence']:.1%}")
        print(f"\n📊 Probabilities:")
        for class_name, prob in result['probabilities'].items():
            bar = "█" * int(prob * 30)
            print(f"   {class_name:10s} {prob:.1%} {bar}")
        print(f"\n💡 Interpretation:")
        print(f"   {result['interpretation']}")
        print("=" * 60)


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    
    print("=" * 60)
    print("AUTISM SEVERITY PREDICTOR - CLINICAL USE")
    print("=" * 60)
    
    # Initialize predictor
    predictor = AutismSeverityPredictor()
    
    # Example 1: Load test data
    print("\n[Example] Predicting on test data...")
    
    X_external = np.load("prepared_dataset_v2/X_external.npy")
    y_external = np.load("prepared_dataset_v2/y_external.npy")
    
    # Predict first patient
    result = predictor.predict(X_external[0])
    predictor.print_result(result)
    
    print(f"\n   True label: {['Typical', 'ASD', 'Severe'][y_external[0]]}")
    print(f"   Correct: {'✅ Yes' if result['prediction'] == y_external[0] else '❌ No'}")
    
    # Example 2: Batch prediction
    print("\n\n[Example] Batch prediction (first 5 patients)...")
    
    results = predictor.batch_predict(X_external[:5])
    
    print("\n" + "=" * 80)
    print(f"{'ID':<5} {'Predicted':<12} {'Confidence':<12} {'True Label':<12} {'Correct'}")
    print("=" * 80)
    
    for i, result in enumerate(results):
        true_label = ['Typical', 'ASD', 'Severe'][y_external[i]]
        correct = "✅" if result['prediction'] == y_external[i] else "❌"
        print(f"{i+1:<5} {result['class_name']:<12} {result['confidence']:<12.1%} "
              f"{true_label:<12} {correct}")
    
    print("=" * 80)
    
    # Example 3: New patient (custom features)
    print("\n\n[Example] New patient prediction...")
    print("(Using random features for demonstration)")
    
    # In real use, load actual patient features from Kinect data
    new_patient_features = np.random.randn(463)  # Replace with real data
    
    result = predictor.predict(new_patient_features)
    predictor.print_result(result)
    
    print("\n✅ Predictor ready for clinical use!")
    print("=" * 60)

