#!/usr/bin/env python3
"""
Autism Severity Classification - Model Training
Real training, NO simulation, NO overfitting
"""

import numpy as np
import pandas as pd
import pickle
import json
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# ML Libraries
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.metrics import (accuracy_score, precision_recall_fscore_support,
                            confusion_matrix, classification_report, roc_auc_score)
import xgboost as xgb

# Deep Learning
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, regularizers
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint

# Set random seeds
np.random.seed(42)
tf.random.set_seed(42)

print("=" * 80)
print("AUTISM SEVERITY CLASSIFICATION - MODEL TRAINING")
print("Real Training | No Simulation | No Overfitting")
print("=" * 80)

# ============================================================================
# 1. LOAD DATA
# ============================================================================

print("\n[1/10] Loading data...")

DATA_DIR = Path("prepared_dataset_v2")
OUTPUT_DIR = Path("model_results")
OUTPUT_DIR.mkdir(exist_ok=True)

X_train = np.load(DATA_DIR / "X_train.npy")
y_train = np.load(DATA_DIR / "y_train.npy")
X_test = np.load(DATA_DIR / "X_test.npy")
y_test = np.load(DATA_DIR / "y_test.npy")
X_external = np.load(DATA_DIR / "X_external.npy")
y_external = np.load(DATA_DIR / "y_external.npy")

print(f"  Training: {X_train.shape}, Labels: {y_train.shape}")
print(f"  Test: {X_test.shape}, Labels: {y_test.shape}")
print(f"  External: {X_external.shape}, Labels: {y_external.shape}")

# Class distribution
print(f"\n  Class distribution:")
print(f"    Train: Typical={np.sum(y_train==0)}, ASD={np.sum(y_train==1)}, Severe={np.sum(y_train==2)}")
print(f"    Test: Typical={np.sum(y_test==0)}, ASD={np.sum(y_test==1)}, Severe={np.sum(y_test==2)}")
print(f"    External: Typical={np.sum(y_external==0)}, ASD={np.sum(y_external==1)}, Severe={np.sum(y_external==2)}")

# ============================================================================
# 2. NORMALIZATION
# ============================================================================

print("\n[2/10] Normalizing data...")

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
X_external_scaled = scaler.transform(X_external)

# Save scaler
with open(OUTPUT_DIR / "scaler.pkl", "wb") as f:
    pickle.dump(scaler, f)

print(f"  ✅ Normalization complete")
print(f"  Mean: {X_train_scaled.mean():.6f}, Std: {X_train_scaled.std():.6f}")

# ============================================================================
# 3. CLASS WEIGHTS (for imbalanced data)
# ============================================================================

print("\n[3/10] Calculating class weights...")

from sklearn.utils.class_weight import compute_class_weight

class_weights_array = compute_class_weight(
    class_weight='balanced',
    classes=np.unique(y_train),
    y=y_train
)

class_weights = {i: class_weights_array[i] for i in range(len(class_weights_array))}
print(f"  Class weights: {class_weights}")

# ============================================================================
# 4. BASELINE MODELS
# ============================================================================

print("\n[4/10] Training baseline models...")

models = {}
results = {}

# Random Forest
print("\n  [4.1] Random Forest...")
rf_model = RandomForestClassifier(
    n_estimators=200,
    max_depth=15,
    min_samples_split=10,
    min_samples_leaf=4,
    class_weight=class_weights,
    random_state=42,
    n_jobs=-1
)
rf_model.fit(X_train_scaled, y_train)
models['RandomForest'] = rf_model

y_pred_rf = rf_model.predict(X_test_scaled)
acc_rf = accuracy_score(y_test, y_pred_rf)
print(f"    Test Accuracy: {acc_rf:.4f}")
results['RandomForest'] = {'test_accuracy': acc_rf}

# XGBoost
print("\n  [4.2] XGBoost...")
xgb_model = xgb.XGBClassifier(
    n_estimators=200,
    max_depth=6,
    learning_rate=0.05,
    subsample=0.8,
    colsample_bytree=0.8,
    reg_alpha=0.1,
    reg_lambda=1.0,
    scale_pos_weight=class_weights[2],
    random_state=42,
    use_label_encoder=False,
    eval_metric='mlogloss'
)

xgb_model.fit(
    X_train_scaled, y_train,
    eval_set=[(X_test_scaled, y_test)],
    verbose=False
)
models['XGBoost'] = xgb_model

y_pred_xgb = xgb_model.predict(X_test_scaled)
acc_xgb = accuracy_score(y_test, y_pred_xgb)
print(f"    Test Accuracy: {acc_xgb:.4f}")
results['XGBoost'] = {'test_accuracy': acc_xgb}

# SVM
print("\n  [4.3] SVM...")
svm_model = SVC(
    C=1.0,
    kernel='rbf',
    gamma='scale',
    class_weight=class_weights,
    random_state=42,
    probability=True
)
svm_model.fit(X_train_scaled, y_train)
models['SVM'] = svm_model

y_pred_svm = svm_model.predict(X_test_scaled)
acc_svm = accuracy_score(y_test, y_pred_svm)
print(f"    Test Accuracy: {acc_svm:.4f}")
results['SVM'] = {'test_accuracy': acc_svm}

# ============================================================================
# 5. DEEP LEARNING MODEL (Keras)
# ============================================================================

print("\n[5/10] Building Deep Learning model...")

def create_dnn_model(input_dim, num_classes):
    """Create DNN with regularization to prevent overfitting"""
    model = keras.Sequential([
        # Input layer
        layers.Input(shape=(input_dim,)),
        
        # Layer 1
        layers.Dense(256, kernel_regularizer=regularizers.l2(0.01)),
        layers.BatchNormalization(),
        layers.Activation('relu'),
        layers.Dropout(0.4),
        
        # Layer 2
        layers.Dense(128, kernel_regularizer=regularizers.l2(0.01)),
        layers.BatchNormalization(),
        layers.Activation('relu'),
        layers.Dropout(0.3),
        
        # Layer 3
        layers.Dense(64, kernel_regularizer=regularizers.l2(0.01)),
        layers.BatchNormalization(),
        layers.Activation('relu'),
        layers.Dropout(0.3),
        
        # Layer 4
        layers.Dense(32, kernel_regularizer=regularizers.l2(0.01)),
        layers.BatchNormalization(),
        layers.Activation('relu'),
        layers.Dropout(0.2),
        
        # Output layer
        layers.Dense(num_classes, activation='softmax')
    ])
    
    return model

# Create model
dnn_model = create_dnn_model(X_train_scaled.shape[1], 3)

# Compile
dnn_model.compile(
    optimizer=keras.optimizers.Adam(learning_rate=0.001),
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

print(f"  Model architecture:")
dnn_model.summary()

# Callbacks to prevent overfitting
callbacks = [
    EarlyStopping(
        monitor='val_loss',
        patience=20,
        restore_best_weights=True,
        verbose=1
    ),
    ReduceLROnPlateau(
        monitor='val_loss',
        factor=0.5,
        patience=10,
        min_lr=1e-6,
        verbose=1
    ),
    ModelCheckpoint(
        OUTPUT_DIR / 'best_model.h5',
        monitor='val_loss',
        save_best_only=True,
        verbose=1
    )
]

# Train
print("\n  Training DNN...")
history = dnn_model.fit(
    X_train_scaled, y_train,
    validation_data=(X_test_scaled, y_test),
    epochs=200,
    batch_size=16,
    class_weight=class_weights,
    callbacks=callbacks,
    verbose=1
)

# Save history
with open(OUTPUT_DIR / "training_history.pkl", "wb") as f:
    pickle.dump(history.history, f)

# Evaluate
y_pred_dnn = np.argmax(dnn_model.predict(X_test_scaled), axis=1)
acc_dnn = accuracy_score(y_test, y_pred_dnn)
print(f"\n  DNN Test Accuracy: {acc_dnn:.4f}")
results['DNN'] = {'test_accuracy': acc_dnn}

models['DNN'] = dnn_model

# ============================================================================
# 6. K-FOLD CROSS VALIDATION
# ============================================================================

print("\n[6/10] K-Fold Cross Validation (5-fold)...")

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

cv_results = {}

# Random Forest CV
print("  Random Forest CV...")
rf_cv_scores = cross_val_score(rf_model, X_train_scaled, y_train, cv=cv, scoring='accuracy', n_jobs=-1)
cv_results['RandomForest'] = rf_cv_scores
print(f"    CV Accuracy: {rf_cv_scores.mean():.4f} (+/- {rf_cv_scores.std():.4f})")

# XGBoost CV
print("  XGBoost CV...")
xgb_cv_scores = cross_val_score(xgb_model, X_train_scaled, y_train, cv=cv, scoring='accuracy', n_jobs=-1)
cv_results['XGBoost'] = xgb_cv_scores
print(f"    CV Accuracy: {xgb_cv_scores.mean():.4f} (+/- {xgb_cv_scores.std():.4f})")

# SVM CV
print("  SVM CV...")
svm_cv_scores = cross_val_score(svm_model, X_train_scaled, y_train, cv=cv, scoring='accuracy', n_jobs=-1)
cv_results['SVM'] = svm_cv_scores
print(f"    CV Accuracy: {svm_cv_scores.mean():.4f} (+/- {svm_cv_scores.std():.4f})")

# Save CV results
with open(OUTPUT_DIR / "cv_results.pkl", "wb") as f:
    pickle.dump(cv_results, f)

# ============================================================================
# 7. SELECT BEST MODEL
# ============================================================================

print("\n[7/10] Selecting best model...")

best_model_name = max(results, key=lambda x: results[x]['test_accuracy'])
best_model = models[best_model_name]
best_accuracy = results[best_model_name]['test_accuracy']

print(f"  Best model: {best_model_name}")
print(f"  Test accuracy: {best_accuracy:.4f}")

# ============================================================================
# 8. RETRAIN WITH TRAIN + TEST (for final model)
# ============================================================================

print("\n[8/10] Retraining best model with Train + Test...")

X_train_all = np.vstack([X_train_scaled, X_test_scaled])
y_train_all = np.concatenate([y_train, y_test])

if best_model_name == 'DNN':
    # Retrain DNN
    final_model = create_dnn_model(X_train_all.shape[1], 3)
    final_model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=0.001),
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )
    
    final_history = final_model.fit(
        X_train_all, y_train_all,
        epochs=100,
        batch_size=16,
        class_weight=class_weights,
        verbose=1
    )
    
    # Save final model (H5 format)
    final_model.save(OUTPUT_DIR / "final_model.h5")
    print(f"  ✅ Model saved: final_model.h5")
    
else:
    # Retrain sklearn model
    final_model = best_model.__class__(**best_model.get_params())
    final_model.fit(X_train_all, y_train_all)
    
    # Save final model (Pickle)
    with open(OUTPUT_DIR / "final_model.pkl", "wb") as f:
        pickle.dump(final_model, f)
    print(f"  ✅ Model saved: final_model.pkl")

# ============================================================================
# 9. EXTERNAL TEST EVALUATION
# ============================================================================

print("\n[9/10] External test evaluation...")

y_pred_external = final_model.predict(X_external_scaled)
if best_model_name == 'DNN':
    y_pred_external = np.argmax(y_pred_external, axis=1)

# Metrics
acc_external = accuracy_score(y_external, y_pred_external)
precision, recall, f1, support = precision_recall_fscore_support(
    y_external, y_pred_external, average=None, labels=[0, 1, 2]
)

print(f"\n  External Test Results:")
print(f"    Accuracy: {acc_external:.4f}")
print(f"\n    Per-class metrics:")
print(f"      Typical  - Precision: {precision[0]:.4f}, Recall: {recall[0]:.4f}, F1: {f1[0]:.4f}")
print(f"      ASD      - Precision: {precision[1]:.4f}, Recall: {recall[1]:.4f}, F1: {f1[1]:.4f}")
print(f"      Severe   - Precision: {precision[2]:.4f}, Recall: {recall[2]:.4f}, F1: {f1[2]:.4f}")

# Confusion matrix
cm_external = confusion_matrix(y_external, y_pred_external)
print(f"\n    Confusion Matrix:")
print(cm_external)

# Classification report
report_external = classification_report(
    y_external, y_pred_external,
    target_names=['Typical', 'ASD', 'Severe'],
    digits=4
)
print(f"\n    Classification Report:")
print(report_external)

# Save external results
external_results = {
    'accuracy': float(acc_external),
    'precision': precision.tolist(),
    'recall': recall.tolist(),
    'f1': f1.tolist(),
    'support': support.tolist(),
    'confusion_matrix': cm_external.tolist(),
    'classification_report': report_external
}

with open(OUTPUT_DIR / "external_results.json", "w") as f:
    json.dump(external_results, f, indent=2)

# ============================================================================
# 10. SAVE ALL RESULTS
# ============================================================================

print("\n[10/10] Saving all results...")

# Save all models
for name, model in models.items():
    if name == 'DNN':
        model.save(OUTPUT_DIR / f"{name}_model.h5")
    else:
        with open(OUTPUT_DIR / f"{name}_model.pkl", "wb") as f:
            pickle.dump(model, f)

# Save metadata
metadata = {
    'best_model': best_model_name,
    'test_accuracy': float(best_accuracy),
    'external_accuracy': float(acc_external),
    'class_weights': {str(k): float(v) for k, v in class_weights.items()},
    'n_features': int(X_train.shape[1]),
    'n_classes': 3,
    'class_names': ['Typical', 'ASD', 'Severe']
}

with open(OUTPUT_DIR / "metadata.json", "w") as f:
    json.dump(metadata, f, indent=2)

print(f"\n  ✅ All results saved to: {OUTPUT_DIR}")

# ============================================================================
# SUMMARY
# ============================================================================

print("\n" + "=" * 80)
print("TRAINING COMPLETE!")
print("=" * 80)

print(f"\n📊 MODEL COMPARISON:")
for name in results:
    print(f"  {name:15s} - Test Accuracy: {results[name]['test_accuracy']:.4f}")

print(f"\n🏆 BEST MODEL: {best_model_name}")
print(f"  Test Accuracy: {best_accuracy:.4f}")
print(f"  External Accuracy: {acc_external:.4f}")

print(f"\n📁 SAVED FILES:")
print(f"  • final_model.h5 or final_model.pkl")
print(f"  • scaler.pkl")
print(f"  • training_history.pkl")
print(f"  • cv_results.pkl")
print(f"  • external_results.json")
print(f"  • metadata.json")

print("\n✅ Ready for clinical use!")
print("=" * 80)

