"""
External Test Evaluation Script
Evaluate the final model on external test set
"""

import numpy as np
import pickle
from pathlib import Path
from sklearn.metrics import (accuracy_score, precision_recall_fscore_support,
                            confusion_matrix, classification_report)

print("="*80)
print("EXTERNAL TEST EVALUATION")
print("="*80)

# Paths
DATA_DIR = Path("../prepared_dataset_v2")
MODEL_DIR = Path("trained_models")

# Load data
print("\n[1/4] Loading external test data...")
X_external = np.load(DATA_DIR / "X_external.npy")
y_external = np.load(DATA_DIR / "y_external.npy")

print(f"  External test: {X_external.shape}, Labels: {y_external.shape}")
print(f"  Class distribution: Typical={np.sum(y_external==0)}, ASD={np.sum(y_external==1)}, Severe={np.sum(y_external==2)}")

# Load model and scaler
print("\n[2/4] Loading model and scaler...")
with open(MODEL_DIR / "final_model.pkl", "rb") as f:
    model = pickle.load(f)

with open(MODEL_DIR / "scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

print(f"  ✓ Model loaded: {type(model).__name__}")

# Normalize
print("\n[3/4] Normalizing data...")
X_external_scaled = scaler.transform(X_external)
print(f"  ✓ Normalization complete")

# Predict
print("\n[4/4] Evaluating on external test...")
y_pred = model.predict(X_external_scaled)
y_proba = model.predict_proba(X_external_scaled)

# Metrics
accuracy = accuracy_score(y_external, y_pred)
precision, recall, f1, support = precision_recall_fscore_support(
    y_external, y_pred, labels=[0, 1, 2], zero_division=0
)
cm = confusion_matrix(y_external, y_pred, labels=[0, 1, 2])

# Results
print("\n" + "="*80)
print("EXTERNAL TEST RESULTS")
print("="*80)

print(f"\n✓ Overall Accuracy: {accuracy:.1%}")

print("\n✓ Per-Class Metrics:")
class_names = ['Typical', 'ASD', 'Severe']
for i, name in enumerate(class_names):
    print(f"  {name}:")
    print(f"    Precision: {precision[i]:.3f}")
    print(f"    Recall:    {recall[i]:.3f}")
    print(f"    F1-Score:  {f1[i]:.3f}")
    print(f"    Support:   {support[i]}")

print("\n✓ Confusion Matrix:")
print("         Predicted")
print("Actual   Typ  ASD  Sev")
for i, name in enumerate(['Typical', 'ASD', 'Severe']):
    print(f"{name:8s} {cm[i][0]:3d}  {cm[i][1]:3d}  {cm[i][2]:3d}")

print("\n✓ Classification Report:")
print(classification_report(y_external, y_pred, 
                          target_names=class_names, 
                          zero_division=0))

# Save results
print("\n" + "="*80)
print("Saving results...")
print("="*80)

results = {
    'accuracy': accuracy,
    'precision': precision,
    'recall': recall,
    'f1_score': f1,
    'support': support,
    'confusion_matrix': cm,
    'predictions': y_pred,
    'probabilities': y_proba,
    'true_labels': y_external
}

with open(MODEL_DIR / "external_test_results.pkl", "wb") as f:
    pickle.dump(results, f)

print("✓ Results saved to: trained_models/external_test_results.pkl")
print("\n" + "="*80)
print("EVALUATION COMPLETE!")
print("="*80)

