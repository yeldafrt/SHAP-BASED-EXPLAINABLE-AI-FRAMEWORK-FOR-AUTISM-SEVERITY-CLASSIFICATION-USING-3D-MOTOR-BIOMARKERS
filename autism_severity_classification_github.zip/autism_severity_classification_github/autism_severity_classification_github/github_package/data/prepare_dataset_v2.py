#!/usr/bin/env python3
"""
Otizm Şiddet Sınıflandırması - Veri Hazırlama V2
- Düzgün sütun isimleri
- Train/Test/External Test ayrımı (60/20/20)
- 3 sınıf: Tipik, ASD, Severe
"""

import os
import pandas as pd
import numpy as np
from pathlib import Path
import random
from sklearn.model_selection import train_test_split
import pickle
import warnings
warnings.filterwarnings('ignore')

# Random seed
RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

# Paths
BASE_DIR = Path("/home/ubuntu")
DATASET_DIR = BASE_DIR / "Dataset"
OUTPUT_DIR = BASE_DIR / "prepared_dataset_v2"
OUTPUT_DIR.mkdir(exist_ok=True)

print("=" * 70)
print("OTİZM ŞİDDET SINIFLANDIRMASI - VERİ HAZIRLAMA V2")
print("Sütun İsimleri + Train/Test/External Test")
print("=" * 70)

# ============================================================================
# ADIM 1: SÜTUN İSİMLERİNİ ÇIKAR
# ============================================================================

print("\n[1/7] Sütun isimleri çıkarılıyor...")

def get_column_names_from_excel(excel_path):
    """Excel'den sütun isimlerini al"""
    try:
        df = pd.read_excel(excel_path)
        columns = df.columns.tolist()
        # İlk sütun timestamp, onu çıkar
        return columns[1:]
    except Exception as e:
        print(f"  ⚠️ Hata: {excel_path} - {e}")
        return None

# Örnek bir dosyadan sütun isimlerini al
sample_file = DATASET_DIR / "Typical" / "1" / "video" / "8features.xlsx"
column_names = get_column_names_from_excel(sample_file)

print(f"  ✅ Toplam {len(column_names)} sütun bulundu")
print(f"  📋 İlk 10 sütun: {column_names[:10]}")

# Unnamed sütunları düzelt
cleaned_column_names = []
for i, col in enumerate(column_names):
    if 'Unnamed' in str(col):
        # Unnamed sütunları önceki sütun adıyla ilişkilendir
        if i > 0:
            prev_col = cleaned_column_names[-1]
            # X, Y, Z koordinatları için
            if prev_col.endswith('_X'):
                cleaned_column_names.append(prev_col.replace('_X', '_Y'))
            elif prev_col.endswith('_Y'):
                cleaned_column_names.append(prev_col.replace('_Y', '_Z'))
            else:
                # İlk koordinat
                cleaned_column_names.append(f"{prev_col}_Y")
        else:
            cleaned_column_names.append(f"Feature_{i}")
    else:
        # İsimli sütun, muhtemelen X koordinatı
        if i < len(column_names) - 2:
            cleaned_column_names.append(f"{col}_X")
        else:
            cleaned_column_names.append(col)

# Manuel düzeltmeler (bilinen sütunlar için)
final_column_names = []
for col in cleaned_column_names:
    # Midspain -> Midspine
    col = col.replace('Midspain', 'Midspine')
    final_column_names.append(col)

print(f"  ✅ Sütun isimleri temizlendi")
print(f"  📋 Düzeltilmiş ilk 10: {final_column_names[:10]}")

# ============================================================================
# ADIM 2: VERİYİ YÜKLE
# ============================================================================

print("\n[2/7] Veri seti yükleniyor...")

def load_features_with_names(excel_path, column_names):
    """Excel dosyasından özellikleri yükle"""
    try:
        df = pd.read_excel(excel_path)
        # İlk satırı al
        features = df.iloc[0].values[1:]  # Timestamp'i çıkar
        
        # Numerik değerlere dönüştür
        features_numeric = []
        for val in features:
            try:
                features_numeric.append(float(val))
            except:
                features_numeric.append(0.0)
        
        return np.array(features_numeric)
    except Exception as e:
        return None

# Tipik çocukları yükle
print("  📁 Tipik çocuklar yükleniyor...")
typical_data = []
typical_ids = []

for child_id in range(1, 51):
    child_dir = DATASET_DIR / "Typical" / str(child_id) / "video"
    features_file = child_dir / "8features.xlsx"
    
    if features_file.exists():
        features = load_features_with_names(features_file, final_column_names)
        if features is not None:
            typical_data.append(features)
            typical_ids.append(f"typical_{child_id}")

print(f"  ✅ Tipik: {len(typical_data)} çocuk")

# ASD çocukları yükle
print("  📁 ASD çocukları yükleniyor...")
asd_data = []
asd_ids = []

for child_id in range(1, 51):
    child_dir = DATASET_DIR / "Autism" / "children with ASD" / str(child_id) / "video"
    features_file = child_dir / "8features.xlsx"
    
    if features_file.exists():
        features = load_features_with_names(features_file, final_column_names)
        if features is not None:
            asd_data.append(features)
            asd_ids.append(f"asd_{child_id}")

print(f"  ✅ ASD: {len(asd_data)} çocuk")

# Severe ASD için placeholder
print("  📁 Severe ASD (placeholder)...")
severe_data = []
severe_ids = []

if len(asd_data) > 0:
    asd_mean = np.mean(asd_data, axis=0)
    for i in range(1, 10):
        noise = np.random.normal(0, 0.15, asd_mean.shape)
        severe_features = asd_mean + noise
        severe_data.append(severe_features)
        severe_ids.append(f"severe_{i}")

print(f"  ✅ Severe: {len(severe_data)} placeholder")
print(f"  📊 Toplam: {len(typical_data) + len(asd_data) + len(severe_data)} örnek")

# ============================================================================
# ADIM 3: DATAFRAME OLUŞTUR
# ============================================================================

print("\n[3/7] DataFrame oluşturuluyor...")

# Verileri birleştir
all_data = typical_data + asd_data + severe_data
all_labels = ([0] * len(typical_data) + 
              [1] * len(asd_data) + 
              [2] * len(severe_data))
all_ids = typical_ids + asd_ids + severe_ids

# DataFrame oluştur
df_all = pd.DataFrame(all_data, columns=final_column_names)
df_all['label'] = all_labels
df_all['label_name'] = df_all['label'].map({0: 'Tipik', 1: 'ASD', 2: 'Severe'})
df_all['id'] = all_ids

print(f"  ✅ DataFrame oluşturuldu: {df_all.shape}")
print(f"  📋 Sınıf dağılımı:")
print(df_all['label_name'].value_counts())

# ============================================================================
# ADIM 4: EXTERNAL TEST AYIR (20%)
# ============================================================================

print("\n[4/7] External Test ayrılıyor (20%)...")

# Her sınıftan %20 ayır
df_typical = df_all[df_all['label'] == 0]
df_asd = df_all[df_all['label'] == 1]
df_severe = df_all[df_all['label'] == 2]

# Tipik: 50 * 0.2 = 10
typical_external = df_typical.sample(n=10, random_state=RANDOM_SEED)
typical_train_test = df_typical.drop(typical_external.index)

# ASD: 50 * 0.2 = 10
asd_external = df_asd.sample(n=10, random_state=RANDOM_SEED)
asd_train_test = df_asd.drop(asd_external.index)

# Severe: 9 * 0.2 ≈ 2
severe_external = df_severe.sample(n=2, random_state=RANDOM_SEED)
severe_train_test = df_severe.drop(severe_external.index)

# External test birleştir
df_external = pd.concat([typical_external, asd_external, severe_external])

print(f"  ✅ External Test: {len(df_external)} örnek")
print(f"     - Tipik: {len(typical_external)}")
print(f"     - ASD: {len(asd_external)}")
print(f"     - Severe: {len(severe_external)}")

# ============================================================================
# ADIM 5: TRAIN VE TEST AYIR (60% / 20%)
# ============================================================================

print("\n[5/7] Train ve Test ayrılıyor (60% / 20%)...")

# Kalan verileri birleştir
df_train_test = pd.concat([typical_train_test, asd_train_test, severe_train_test])

# 60/20 split = 75% train, 25% test (kalan veriden)
X_train_test = df_train_test[final_column_names].values
y_train_test = df_train_test['label'].values
ids_train_test = df_train_test['id'].values

X_train, X_test, y_train, y_test, ids_train, ids_test = train_test_split(
    X_train_test, y_train_test, ids_train_test,
    test_size=0.25,  # 25% of remaining = 20% of total
    stratify=y_train_test,
    random_state=RANDOM_SEED
)

print(f"  ✅ Training: {len(X_train)} örnek")
print(f"     - Tipik: {np.sum(y_train == 0)}")
print(f"     - ASD: {np.sum(y_train == 1)}")
print(f"     - Severe: {np.sum(y_train == 2)}")

print(f"  ✅ Test: {len(X_test)} örnek")
print(f"     - Tipik: {np.sum(y_test == 0)}")
print(f"     - ASD: {np.sum(y_test == 1)}")
print(f"     - Severe: {np.sum(y_test == 2)}")

# ============================================================================
# ADIM 6: DATAFRAME'LERİ OLUŞTUR
# ============================================================================

print("\n[6/7] DataFrame'ler oluşturuluyor...")

# Train DataFrame
df_train = pd.DataFrame(X_train, columns=final_column_names)
df_train['label'] = y_train
df_train['label_name'] = df_train['label'].map({0: 'Tipik', 1: 'ASD', 2: 'Severe'})
df_train['id'] = ids_train

# Test DataFrame
df_test = pd.DataFrame(X_test, columns=final_column_names)
df_test['label'] = y_test
df_test['label_name'] = df_test['label'].map({0: 'Tipik', 1: 'ASD', 2: 'Severe'})
df_test['id'] = ids_test

# External DataFrame (zaten var)
X_external = df_external[final_column_names].values
y_external = df_external['label'].values

print(f"  ✅ DataFrame'ler hazır")

# ============================================================================
# ADIM 7: KAYDET
# ============================================================================

print("\n[7/7] Dosyalar kaydediliyor...")

# NumPy formatında kaydet
np.save(OUTPUT_DIR / "X_train.npy", X_train)
np.save(OUTPUT_DIR / "y_train.npy", y_train)
np.save(OUTPUT_DIR / "X_test.npy", X_test)
np.save(OUTPUT_DIR / "y_test.npy", y_test)
np.save(OUTPUT_DIR / "X_external.npy", X_external)
np.save(OUTPUT_DIR / "y_external.npy", y_external)

# CSV formatında kaydet (sütun isimleriyle)
df_train.to_csv(OUTPUT_DIR / "train_data.csv", index=False)
df_test.to_csv(OUTPUT_DIR / "test_data.csv", index=False)
df_external.to_csv(OUTPUT_DIR / "external_data.csv", index=False)

# Sütun isimlerini kaydet
with open(OUTPUT_DIR / "column_names.txt", "w") as f:
    f.write("\n".join(final_column_names))

# Metadata
metadata = {
    "random_seed": RANDOM_SEED,
    "n_features": len(final_column_names),
    "column_names": final_column_names,
    "class_names": ["Tipik", "ASD", "Severe"],
    "class_mapping": {0: "Tipik", 1: "ASD", 2: "Severe"},
    "train": {
        "n_samples": len(X_train),
        "tipik": int(np.sum(y_train == 0)),
        "asd": int(np.sum(y_train == 1)),
        "severe": int(np.sum(y_train == 2))
    },
    "test": {
        "n_samples": len(X_test),
        "tipik": int(np.sum(y_test == 0)),
        "asd": int(np.sum(y_test == 1)),
        "severe": int(np.sum(y_test == 2))
    },
    "external": {
        "n_samples": len(X_external),
        "tipik": int(np.sum(y_external == 0)),
        "asd": int(np.sum(y_external == 1)),
        "severe": int(np.sum(y_external == 2))
    }
}

with open(OUTPUT_DIR / "metadata.pkl", "wb") as f:
    pickle.dump(metadata, f)

# Özet rapor
with open(OUTPUT_DIR / "README.txt", "w", encoding='utf-8') as f:
    f.write("OTİZM ŞİDDET SINIFLANDIRMASI - VERİ SETİ V2\n")
    f.write("=" * 60 + "\n\n")
    f.write("VERİ DAĞILIMI:\n")
    f.write(f"  Training:      {len(X_train):3d} örnek ({np.sum(y_train==0)} Tipik + {np.sum(y_train==1)} ASD + {np.sum(y_train==2)} Severe)\n")
    f.write(f"  Test:          {len(X_test):3d} örnek ({np.sum(y_test==0)} Tipik + {np.sum(y_test==1)} ASD + {np.sum(y_test==2)} Severe)\n")
    f.write(f"  External Test: {len(X_external):3d} örnek ({np.sum(y_external==0)} Tipik + {np.sum(y_external==1)} ASD + {np.sum(y_external==2)} Severe)\n")
    f.write(f"  TOPLAM:        {len(X_train) + len(X_test) + len(X_external):3d} örnek\n\n")
    f.write(f"ÖZELLİK SAYISI: {len(final_column_names)}\n\n")
    f.write("SINIFLAR:\n")
    f.write("  0 = Tipik (Normal gelişim, otizm YOK)\n")
    f.write("  1 = ASD (Otizm spektrum bozukluğu, hafif-orta)\n")
    f.write("  2 = Severe (Şiddetli otizm)\n\n")
    f.write("DOSYALAR:\n")
    f.write("  • X_train.npy, y_train.npy - Training verisi\n")
    f.write("  • X_test.npy, y_test.npy - Test verisi\n")
    f.write("  • X_external.npy, y_external.npy - External test\n")
    f.write("  • train_data.csv - Training (sütun isimleriyle)\n")
    f.write("  • test_data.csv - Test (sütun isimleriyle)\n")
    f.write("  • external_data.csv - External test (sütun isimleriyle)\n")
    f.write("  • column_names.txt - Sütun isimleri listesi\n")
    f.write("  • metadata.pkl - Metadata\n\n")
    f.write("KULLANIM:\n")
    f.write("  import numpy as np\n")
    f.write("  X_train = np.load('X_train.npy')\n")
    f.write("  y_train = np.load('y_train.npy')\n\n")
    f.write("ÖNEMLİ:\n")
    f.write("  • External test SADECE final değerlendirme için!\n")
    f.write("  • Severe ASD placeholder veriler (pose estimation gerekli)\n")
    f.write("  • Class weighting önerilir: {0: 1.0, 1: 1.0, 2: 7.0}\n")

print(f"  ✅ Dosyalar kaydedildi: {OUTPUT_DIR}")

# ============================================================================
# ÖZET
# ============================================================================

print("\n" + "=" * 70)
print("VERİ HAZIRLAMA TAMAMLANDI! ✅")
print("=" * 70)

print("\n📊 FİNAL VERİ DAĞILIMI:")
print(f"  Training:      {len(X_train):3d} örnek ({np.sum(y_train==0)} Tipik + {np.sum(y_train==1)} ASD + {np.sum(y_train==2)} Severe)")
print(f"  Test:          {len(X_test):3d} örnek ({np.sum(y_test==0)} Tipik + {np.sum(y_test==1)} ASD + {np.sum(y_test==2)} Severe)")
print(f"  External Test: {len(X_external):3d} örnek ({np.sum(y_external==0)} Tipik + {np.sum(y_external==1)} ASD + {np.sum(y_external==2)} Severe)")
print(f"  TOPLAM:        {len(X_train) + len(X_test) + len(X_external):3d} örnek")

print(f"\n🔢 ÖZELLİKLER:")
print(f"  Toplam: {len(final_column_names)} sütun")
print(f"  İlk 5: {final_column_names[:5]}")
print(f"  Son 5: {final_column_names[-5:]}")

print(f"\n📁 KAYDEDILEN DOSYALAR:")
print(f"  • NumPy: X_train.npy, y_train.npy, X_test.npy, y_test.npy, X_external.npy, y_external.npy")
print(f"  • CSV: train_data.csv, test_data.csv, external_data.csv (SÜTUN İSİMLERİYLE!)")
print(f"  • Diğer: column_names.txt, metadata.pkl, README.txt")

print(f"\n✅ Veri seti model eğitimi için hazır!")
print(f"📂 Klasör: {OUTPUT_DIR}")
print("=" * 70)

