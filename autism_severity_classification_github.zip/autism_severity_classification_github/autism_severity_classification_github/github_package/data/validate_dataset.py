#!/usr/bin/env python3
"""
Veri Seti Doğrulama ve Kontrol Scripti
Orijinal veri seti ile hazırlanan veri setini karşılaştırır
"""

import numpy as np
import pandas as pd
import pickle
from pathlib import Path

print("=" * 70)
print("VERİ SETİ DOĞRULAMA VE KONTROL")
print("=" * 70)

# Paths
PREPARED_DIR = Path("/home/ubuntu/prepared_dataset_v2")
DATASET_DIR = Path("/home/ubuntu/Dataset")

# ============================================================================
# 1. DOSYA VARLIĞI KONTROLÜ
# ============================================================================

print("\n[1/6] Dosya varlığı kontrolü...")

required_files = [
    "X_train.npy", "y_train.npy",
    "X_test.npy", "y_test.npy",
    "X_external.npy", "y_external.npy",
    "train_data.csv", "test_data.csv", "external_data.csv",
    "column_names.txt", "metadata.pkl", "README.txt"
]

missing_files = []
for file in required_files:
    if not (PREPARED_DIR / file).exists():
        missing_files.append(file)

if missing_files:
    print(f"  ❌ Eksik dosyalar: {missing_files}")
else:
    print(f"  ✅ Tüm dosyalar mevcut ({len(required_files)} dosya)")

# ============================================================================
# 2. VERİ BOYUTU KONTROLÜ
# ============================================================================

print("\n[2/6] Veri boyutu kontrolü...")

X_train = np.load(PREPARED_DIR / "X_train.npy")
y_train = np.load(PREPARED_DIR / "y_train.npy")
X_test = np.load(PREPARED_DIR / "X_test.npy")
y_test = np.load(PREPARED_DIR / "y_test.npy")
X_external = np.load(PREPARED_DIR / "X_external.npy")
y_external = np.load(PREPARED_DIR / "y_external.npy")

print(f"  Training:      {X_train.shape} features, {y_train.shape} labels")
print(f"  Test:          {X_test.shape} features, {y_test.shape} labels")
print(f"  External Test: {X_external.shape} features, {y_external.shape} labels")

# Boyut kontrolü
issues = []
if X_train.shape[0] != y_train.shape[0]:
    issues.append("Training: X ve y boyutları eşleşmiyor")
if X_test.shape[0] != y_test.shape[0]:
    issues.append("Test: X ve y boyutları eşleşmiyor")
if X_external.shape[0] != y_external.shape[0]:
    issues.append("External: X ve y boyutları eşleşmiyor")

if X_train.shape[1] != X_test.shape[1] or X_train.shape[1] != X_external.shape[1]:
    issues.append("Özellik sayıları farklı!")

if issues:
    print(f"  ❌ Sorunlar: {issues}")
else:
    print(f"  ✅ Tüm boyutlar tutarlı")

# ============================================================================
# 3. TOPLAM VERİ SAYISI KONTROLÜ
# ============================================================================

print("\n[3/6] Toplam veri sayısı kontrolü...")

total_samples = len(X_train) + len(X_test) + len(X_external)
print(f"  Hazırlanan veri: {total_samples} örnek")
print(f"    - Training: {len(X_train)}")
print(f"    - Test: {len(X_test)}")
print(f"    - External: {len(X_external)}")

# Orijinal veri sayısını kontrol et
typical_count = len(list((DATASET_DIR / "Typical").glob("*/")))
asd_count = len(list((DATASET_DIR / "Autism" / "children with ASD").glob("*/")))
severe_count = len(list((DATASET_DIR / "Autism" / "Severe level of ASD").glob("*/")))
original_total = typical_count + asd_count + severe_count

print(f"\n  Orijinal veri: {original_total} örnek")
print(f"    - Tipik: {typical_count}")
print(f"    - ASD: {asd_count}")
print(f"    - Severe: {severe_count}")

if total_samples == original_total:
    print(f"  ✅ Toplam veri sayısı eşleşiyor!")
else:
    print(f"  ⚠️ Fark: {abs(total_samples - original_total)} örnek")

# ============================================================================
# 4. SINIF DAĞILIMI KONTROLÜ
# ============================================================================

print("\n[4/6] Sınıf dağılımı kontrolü...")

def count_classes(y):
    return {
        'Tipik': int(np.sum(y == 0)),
        'ASD': int(np.sum(y == 1)),
        'Severe': int(np.sum(y == 2))
    }

train_dist = count_classes(y_train)
test_dist = count_classes(y_test)
external_dist = count_classes(y_external)

print(f"  Training:      {train_dist}")
print(f"  Test:          {test_dist}")
print(f"  External Test: {external_dist}")

total_dist = {
    'Tipik': train_dist['Tipik'] + test_dist['Tipik'] + external_dist['Tipik'],
    'ASD': train_dist['ASD'] + test_dist['ASD'] + external_dist['ASD'],
    'Severe': train_dist['Severe'] + test_dist['Severe'] + external_dist['Severe']
}

print(f"\n  Toplam dağılım: {total_dist}")

if total_dist['Tipik'] == typical_count and \
   total_dist['ASD'] == asd_count and \
   total_dist['Severe'] == severe_count:
    print(f"  ✅ Sınıf dağılımı orijinal ile eşleşiyor!")
else:
    print(f"  ⚠️ Sınıf dağılımı farklı:")
    print(f"    Beklenen: Tipik={typical_count}, ASD={asd_count}, Severe={severe_count}")
    print(f"    Bulunan:  Tipik={total_dist['Tipik']}, ASD={total_dist['ASD']}, Severe={total_dist['Severe']}")

# ============================================================================
# 5. CSV VE NUMPY TUTARLILIĞI
# ============================================================================

print("\n[5/6] CSV ve NumPy tutarlılığı kontrolü...")

df_train = pd.read_csv(PREPARED_DIR / "train_data.csv")
df_test = pd.read_csv(PREPARED_DIR / "test_data.csv")
df_external = pd.read_csv(PREPARED_DIR / "external_data.csv")

# CSV'den features çıkar (son 3 sütun: label, label_name, id)
X_train_csv = df_train.iloc[:, :-3].values
y_train_csv = df_train['label'].values

X_test_csv = df_test.iloc[:, :-3].values
y_test_csv = df_test['label'].values

X_external_csv = df_external.iloc[:, :-3].values
y_external_csv = df_external['label'].values

# Karşılaştır
csv_numpy_match = True

if not np.allclose(X_train, X_train_csv, rtol=1e-5):
    print(f"  ❌ Training: CSV ve NumPy farklı!")
    csv_numpy_match = False

if not np.array_equal(y_train, y_train_csv):
    print(f"  ❌ Training labels: CSV ve NumPy farklı!")
    csv_numpy_match = False

if not np.allclose(X_test, X_test_csv, rtol=1e-5):
    print(f"  ❌ Test: CSV ve NumPy farklı!")
    csv_numpy_match = False

if not np.array_equal(y_test, y_test_csv):
    print(f"  ❌ Test labels: CSV ve NumPy farklı!")
    csv_numpy_match = False

if not np.allclose(X_external, X_external_csv, rtol=1e-5):
    print(f"  ❌ External: CSV ve NumPy farklı!")
    csv_numpy_match = False

if not np.array_equal(y_external, y_external_csv):
    print(f"  ❌ External labels: CSV ve NumPy farklı!")
    csv_numpy_match = False

if csv_numpy_match:
    print(f"  ✅ CSV ve NumPy dosyaları tamamen eşleşiyor!")

# ============================================================================
# 6. SÜTUN İSİMLERİ KONTROLÜ
# ============================================================================

print("\n[6/6] Sütun isimleri kontrolü...")

with open(PREPARED_DIR / "column_names.txt", "r") as f:
    column_names = f.read().splitlines()

csv_columns = df_train.columns[:-3].tolist()  # Son 3 çıkar

if column_names == csv_columns:
    print(f"  ✅ Sütun isimleri eşleşiyor! ({len(column_names)} sütun)")
else:
    print(f"  ❌ Sütun isimleri farklı!")
    print(f"    column_names.txt: {len(column_names)} sütun")
    print(f"    CSV: {len(csv_columns)} sütun")

# Unnamed kontrolü
unnamed_count = sum(1 for col in column_names if 'Unnamed' in col)
if unnamed_count > 0:
    print(f"  ⚠️ {unnamed_count} adet 'Unnamed' sütun var!")
else:
    print(f"  ✅ Hiç 'Unnamed' sütun yok!")

# ============================================================================
# METADATA KONTROLÜ
# ============================================================================

print("\n[BONUS] Metadata kontrolü...")

with open(PREPARED_DIR / "metadata.pkl", "rb") as f:
    metadata = pickle.load(f)

print(f"  Random Seed: {metadata['random_seed']}")
print(f"  Özellik Sayısı: {metadata['n_features']}")
print(f"  Sınıflar: {metadata['class_names']}")
print(f"  Training: {metadata['train']}")
print(f"  Test: {metadata['test']}")
print(f"  External: {metadata['external']}")

# ============================================================================
# ÖZET RAPOR
# ============================================================================

print("\n" + "=" * 70)
print("DOĞRULAMA SONUÇLARI")
print("=" * 70)

all_checks = []

# Check 1: Dosya varlığı
all_checks.append(("Dosya varlığı", len(missing_files) == 0))

# Check 2: Boyut tutarlılığı
all_checks.append(("Boyut tutarlılığı", len(issues) == 0))

# Check 3: Toplam veri sayısı
all_checks.append(("Toplam veri sayısı", total_samples == original_total))

# Check 4: Sınıf dağılımı
class_match = (total_dist['Tipik'] == typical_count and 
               total_dist['ASD'] == asd_count and 
               total_dist['Severe'] == severe_count)
all_checks.append(("Sınıf dağılımı", class_match))

# Check 5: CSV-NumPy tutarlılığı
all_checks.append(("CSV-NumPy tutarlılığı", csv_numpy_match))

# Check 6: Sütun isimleri
all_checks.append(("Sütun isimleri", column_names == csv_columns))

# Check 7: Unnamed kontrolü
all_checks.append(("Unnamed sütun yok", unnamed_count == 0))

print("\n📋 KONTROL LİSTESİ:")
for check_name, passed in all_checks:
    status = "✅" if passed else "❌"
    print(f"  {status} {check_name}")

passed_count = sum(1 for _, passed in all_checks if passed)
total_count = len(all_checks)

print(f"\n📊 SONUÇ: {passed_count}/{total_count} kontrol başarılı")

if passed_count == total_count:
    print("\n🎉 VERİ SETİ TAMAMEN DOĞRU VE HAZIR!")
    print("   Model eğitimine başlayabilirsiniz!")
else:
    print("\n⚠️ Bazı sorunlar var, yukarıdaki detayları inceleyin.")

print("=" * 70)

# ============================================================================
# EK BİLGİLER
# ============================================================================

print("\n📌 EK BİLGİLER:")
print(f"  • Toplam örnek: {total_samples}")
print(f"  • Özellik sayısı: {X_train.shape[1]}")
print(f"  • Sınıf sayısı: 3 (Tipik, ASD, Severe)")
print(f"  • Train/Test/External: {len(X_train)}/{len(X_test)}/{len(X_external)}")
print(f"  • Veri tipi: {X_train.dtype}")
print(f"  • NaN kontrolü: {np.isnan(X_train).sum() + np.isnan(X_test).sum() + np.isnan(X_external).sum()} NaN değer")

# Özellik istatistikleri
print(f"\n📈 ÖZELLİK İSTATİSTİKLERİ (Training):")
print(f"  • Min: {X_train.min():.4f}")
print(f"  • Max: {X_train.max():.4f}")
print(f"  • Mean: {X_train.mean():.4f}")
print(f"  • Std: {X_train.std():.4f}")

print("\n✅ Doğrulama tamamlandı!")

