# Shap-Based Explainable AI Framework for Autism Severity Classification Using 3D Motor Biomarkers

This repository contains the official code, models, and supplementary materials for the research paper, **"Shap-Based Explainable AI Framework for Autism Severity Classification Using 3D Motor Biomarkers"**. 

The project presents a machine learning system to classify the severity of Autism Spectrum Disorder (ASD) in children using 3D motor movement data captured by a Microsoft Kinect V2 sensor. A Random Forest model is trained on 463 motor features from 109 children to distinguish between Typical, Moderate ASD, and Severe ASD classes. The model's predictions are interpreted using SHAP (Shapley Additive Explanations) to identify key motor biomarkers associated with each class.

## Key Highlights

- **High Performance:** The model achieves **86.4% accuracy** on both internal and external test sets.
- **Clinical Significance:** Achieves **100% accuracy** in detecting Severe ASD cases, a critical requirement for clinical applications.
- **Explainability:** Utilizes SHAP to provide a transparent and interpretable model, identifying the top motor features that drive classification decisions.

---

## Repository Structure

This repository is organized to ensure reproducibility of the research findings. Below is an overview of the key directories:

```
autism_severity_classification_github/
├── data/                     # Scripts to download and prepare the dataset.
├── models/                   # Model training scripts and trained model files (.pkl).
│   └── trained_models/       # Final trained RF, XGBoost, SVM models and the scaler.
├── inference/                # Scripts to run predictions on new data.
├── results/
│   ├── figures/              # All figures and plots generated for the paper.
│   └── tables/               # Performance metrics and results in CSV format.
├── visualization/            # Scripts to generate all figures, including SHAP plots.
│   └── figure_scripts/       # Individual Python scripts for each figure.
├── shap_analysis_supplementary/ # Detailed SHAP value outputs and supplementary CSV files.
└── requirements.txt        # Required Python packages to run the code.
```

---

## Getting Started

To replicate the environment and run the analyses, please follow these steps.

### Prerequisites

- Python 3.9+
- Pip package manager

### Installation

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/your-username/autism-severity-classification.git
    cd autism-severity-classification
    ```

2.  **Install the required packages:**
    A `requirements.txt` file is provided to install all necessary dependencies.
    ```bash
    pip install -r requirements.txt
    ```

---

## Usage

The project is structured into distinct steps, from data preparation to model evaluation.

### 1. Data Preparation

The raw dataset must be processed before use. The script handles the extraction, cleaning, and structuring of the data into a model-ready format.

```bash
python data/prepare_dataset_v2.py
```
This will create the **processed dataset** (`prepared_dataset_v2/`) containing the training, test, and external validation sets (`X_train.npy`, `y_train.npy`, etc.).

### 2. Model Training

To train the Random Forest, XGBoost, and SVM models from scratch, run the training script:

```bash
python models/train_models.py
```
This will save the trained models and the `scaler.pkl` to the `models/trained_models/` directory.

### 3. Generating Figures and Results

All figures and performance tables from the paper can be reproduced by running the scripts in the `visualization/figure_scripts/` directory. For example, to generate the main model comparison figure:

```bash
python visualization/figure_scripts/plot_model_comparison.py
```

### 4. Running Inference

To make a prediction on a new data sample, use the inference script. Ensure the new data has 463 features.

```bash
python inference/predict.py --input_data /path/to/your/data.csv
```

